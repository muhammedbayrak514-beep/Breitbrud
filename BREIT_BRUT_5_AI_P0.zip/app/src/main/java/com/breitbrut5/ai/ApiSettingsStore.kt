package com.breitbrut5.ai

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Explicit choice between on-device inference and a user-configured OpenAI-compatible API. */
internal enum class AiBackendMode(val label: String, val description: String) {
    LOCAL("Cihazda • API anahtarsız", "İndirilen .litertlm modeli cihazda çalışır; sohbet sağlayıcıya gönderilmez."),
    API("API ile • anahtarlı", "Mesajların ve ekli belge bağlamının seçtiğin HTTPS API uç noktasına gönderilir.");

    companion object {
        fun fromStored(value: String?): AiBackendMode = entries.firstOrNull { it.name == value } ?: LOCAL
    }
}

/**
 * User settings for an OpenAI Chat Completions-compatible endpoint.
 * The API key is encrypted at rest with an Android Keystore AES/GCM key. This protects the saved
 * value at rest; it cannot make a client-side API key impossible to extract from a compromised
 * device or from the running app. No API key is compiled into the application.
 */
internal class ApiSettingsStore(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("breit_brut_api_settings", Context.MODE_PRIVATE)

    fun loadMode(): AiBackendMode = AiBackendMode.fromStored(prefs.getString(KEY_MODE, null))
    fun saveMode(mode: AiBackendMode) { prefs.edit().putString(KEY_MODE, mode.name).apply() }

    fun loadEndpoint(): String = prefs.getString(KEY_ENDPOINT, DEFAULT_ENDPOINT) ?: DEFAULT_ENDPOINT
    fun loadModel(): String = prefs.getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL

    fun hasApiKey(): Boolean = !prefs.getString(KEY_ENCRYPTED_API_KEY, null).isNullOrBlank()

    @Synchronized
    fun saveConfiguration(endpoint: String, model: String, apiKey: String) {
        val cleanEndpoint = endpoint.trim()
        val cleanModel = model.trim()
        require(cleanEndpoint.length <= 500) { "API uç noktası çok uzun." }
        require(cleanModel.isNotBlank() && cleanModel.length <= 120) { "Model adı 1–120 karakter olmalı." }
        validateEndpoint(cleanEndpoint)

        // If the input is blank, preserve a previously stored key. Clearing is a separate action.
        val encryptedKey = if (apiKey.isNotBlank()) encrypt(apiKey.trim()) else null
        val editor = prefs.edit().putString(KEY_ENDPOINT, cleanEndpoint).putString(KEY_MODEL, cleanModel)
        if (encryptedKey != null) editor.putString(KEY_ENCRYPTED_API_KEY, encryptedKey)
        editor.apply()
    }

    @Synchronized
    fun readApiKey(): String? {
        val payload = prefs.getString(KEY_ENCRYPTED_API_KEY, null)?.takeIf { it.isNotBlank() } ?: return null
        return try {
            decrypt(payload)
        } catch (e: Exception) {
            throw IllegalStateException("Kayıtlı API anahtarı güvenli depodan okunamadı. Anahtarı yeniden kaydet.", e)
        }
    }

    @Synchronized
    fun clearApiKey() {
        prefs.edit().remove(KEY_ENCRYPTED_API_KEY).apply()
    }

    private fun validateEndpoint(raw: String) {
        val url = try { URL(raw) } catch (_: Exception) { throw IllegalArgumentException("Geçerli bir HTTPS tam API adresi gir. Örnek: https://api.openai.com/v1/chat/completions") }
        require(url.protocol.equals("https", ignoreCase = true)) { "API adresi güvenlik için HTTPS ile başlamalı." }
        require(!url.host.isNullOrBlank() && url.userInfo == null && url.ref == null && url.query == null) { "API adresinde geçerli bir sunucu adı olmalı; kullanıcı bilgisi, sorgu parametresi veya # bölümü ekleme." }
        require(url.path.endsWith("/chat/completions", ignoreCase = true)) { "Bu sürüm OpenAI uyumlu /chat/completions uç noktasını bekliyor." }
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv + ciphertext, Base64.NO_WRAP)
    }

    private fun decrypt(payload: String): String {
        val combined = Base64.decode(payload, Base64.NO_WRAP)
        require(combined.size > GCM_IV_BYTES + GCM_TAG_BYTES) { "Şifreli anahtar verisi eksik." }
        val iv = combined.copyOfRange(0, GCM_IV_BYTES)
        val ciphertext = combined.copyOfRange(GCM_IV_BYTES, combined.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext).toString(Charsets.UTF_8)
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        const val DEFAULT_ENDPOINT = "https://api.openai.com/v1/chat/completions"
        const val DEFAULT_MODEL = "gpt-4o-mini"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "breit.brut.api.key.aesgcm.v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_IV_BYTES = 12
        private const val GCM_TAG_BYTES = 16
        private const val KEY_MODE = "ai_backend_mode"
        private const val KEY_ENDPOINT = "api_endpoint"
        private const val KEY_MODEL = "api_model"
        private const val KEY_ENCRYPTED_API_KEY = "api_key_encrypted"
    }
}
