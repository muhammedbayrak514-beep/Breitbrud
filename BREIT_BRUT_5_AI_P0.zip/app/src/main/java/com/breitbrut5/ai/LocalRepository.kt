package com.breitbrut5.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Local-only chat persistence. Conversation payloads live in an atomic app-private file instead
 * of a large SharedPreferences string. Settings remain in SharedPreferences for compatibility.
 * Existing P2/P3 JSON is migrated on first read; the legacy value is removed only after a durable
 * file write succeeds.
 */
internal class LocalRepository(context: Context) : AutoCloseable {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("breit_brut_local_store", Context.MODE_PRIVATE)
    private val threadStore = AtomicTextFileStore(File(appContext.filesDir, "chat_store/threads.json"))
    private val saveExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "breit-brut-chat-storage").apply { isDaemon = true }
    }
    private val saveLock = Any()
    private val diskLock = Any()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingSnapshot: PendingSnapshot? = null
    private var drainScheduled = false
    private var generation = 0L
    private var closed = false

    @Volatile
    var lastStorageWarning: String? = null
        private set

    @Volatile
    private var storageErrorListener: ((String) -> Unit)? = null

    private data class PendingSnapshot(val generation: Long, val threads: List<ChatThread>)

    fun setStorageErrorListener(listener: ((String) -> Unit)?) {
        storageErrorListener = listener
        val warning = lastStorageWarning
        if (warning != null && listener != null) mainHandler.post { listener(warning) }
    }

    fun loadThreads(): List<ChatThread> {
        val storedRaw = try {
            threadStore.readTextOrNull()
        } catch (e: Exception) {
            setWarning("Sohbet geçmişi dosyası okunamadı. Kurtarma kopyası korunmaya çalışıldı. Ayrıntı: ${e.message ?: "dosya hatası"}")
            null
        }

        if (storedRaw != null) {
            val parsed = runCatching { parseThreads(storedRaw) }
            if (parsed.isSuccess) return parsed.getOrThrow()

            val recovery = runCatching { threadStore.preserveCorruptCopy() }.getOrNull()
            val legacyRaw = prefs.getString(KEY_THREADS, null)
            val legacyParsed = legacyRaw?.let { runCatching { parseThreads(it) } }
            if (legacyParsed?.isSuccess == true) {
                // Preserve the corrupt file first, then restore the older Preferences record.
                runCatching { threadStore.writeText(legacyRaw) }
                    .onSuccess { prefs.edit().remove(KEY_THREADS).commit() }
                setWarning("Sohbet geçmişinin yeni dosyası okunamadı; eski kayıt kurtarıldı. Kurtarma kopyası: ${recovery?.name ?: "oluşturulamadı"}.")
                return legacyParsed.getOrThrow()
            }
            setWarning("Sohbet geçmişi okunamadı. Eski dosya silinmedi; kurtarma kopyası: ${recovery?.name ?: "oluşturulamadı"}. Yeni sohbetler oluşturulursa bu kopya korunur.")
            return emptyList()
        }

        // One-time migration from the P2/P3 SharedPreferences JSON string.
        val legacyRaw = prefs.getString(KEY_THREADS, null) ?: return emptyList()
        val legacyThreads = runCatching { parseThreads(legacyRaw) }.getOrElse {
            setWarning("Eski sohbet kaydı okunamadı. Orijinal SharedPreferences kaydı değiştirilmedi.")
            return emptyList()
        }
        try {
            threadStore.writeText(legacyRaw)
            if (!prefs.edit().remove(KEY_THREADS).commit()) {
                setWarning("Sohbetler dosyaya aktarıldı; eski kayıt temizlenemedi. Veriler korunuyor.")
            }
        } catch (e: Exception) {
            setWarning("Eski sohbet kaydı yeni depolama alanına taşınamadı; eski kayıt korunuyor. Ayrıntı: ${e.message ?: "dosya hatası"}")
        }
        return legacyThreads
    }

    /** Coalesces rapid updates and performs JSON serialization + disk writes away from the UI thread. */
    fun saveThreads(threads: List<ChatThread>, activeId: String) {
        synchronized(saveLock) {
            if (closed) return
            prefs.edit().putString(KEY_ACTIVE_CHAT, activeId).apply()
            generation += 1L
            pendingSnapshot = PendingSnapshot(generation, threads.toList())
            if (!drainScheduled) {
                drainScheduled = true
                saveExecutor.execute(::drainPendingSaves)
            }
        }
    }

    /** Synchronous final flush used when the ViewModel is cleared. */
    fun saveThreadsNow(threads: List<ChatThread>, activeId: String) {
        synchronized(diskLock) {
            synchronized(saveLock) {
                generation += 1L
                pendingSnapshot = null
            }
            try {
                threadStore.writeText(serializeThreads(threads))
                if (!prefs.edit().putString(KEY_ACTIVE_CHAT, activeId).commit()) {
                    setWarning("Sohbetler diske kaydedildi ancak etkin sohbet seçimi kaydedilemedi.")
                } else {
                    clearWarning()
                }
            } catch (e: Exception) {
                setWarning("Sohbet geçmişi diske kaydedilemedi; son kayıt kurtarma için korunmuş olabilir. Ayrıntı: ${e.message ?: "yazma hatası"}")
                throw e
            }
        }
    }

    private fun drainPendingSaves() {
        while (true) {
            val item = synchronized(saveLock) {
                val next = pendingSnapshot
                if (next == null) {
                    drainScheduled = false
                    return
                }
                pendingSnapshot = null
                next
            }
            synchronized(diskLock) {
                val isCurrent = synchronized(saveLock) { item.generation == generation }
                if (isCurrent) {
                    try {
                        threadStore.writeText(serializeThreads(item.threads))
                        clearWarning()
                    } catch (e: Exception) {
                        setWarning("Sohbet geçmişi kaydedilemedi. Depolama alanını kontrol et; son güvenli kayıt korunmaya çalışılır. Ayrıntı: ${e.message ?: "yazma hatası"}")
                        Log.e(TAG, "Could not persist local chat history", e)
                    }
                }
            }
        }
    }

    private fun parseThreads(raw: String): List<ChatThread> {
        val array = JSONArray(raw)
        return buildList {
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val messagesArray = obj.optJSONArray("messages") ?: JSONArray()
                val messages = buildList {
                    for (j in 0 until messagesArray.length()) {
                        val msg = messagesArray.getJSONObject(j)
                        val references = msg.optJSONArray("sourceReferences") ?: JSONArray()
                        val sourceReferences = buildList {
                            for (k in 0 until references.length()) {
                                val ref = references.optJSONObject(k) ?: continue
                                add(LocalSourceReference(
                                    label = ref.optString("label", ""),
                                    documentId = ref.optString("documentId", ""),
                                    documentName = ref.optString("documentName", "Yerel belge"),
                                    sectionNumber = ref.optInt("sectionNumber", 0),
                                    startOffset = ref.optInt("startOffset", 0),
                                    endOffset = ref.optInt("endOffset", 0),
                                    excerpt = ref.optString("excerpt", "")
                                ))
                            }
                        }
                        val auditObject = msg.optJSONObject("citationAudit")
                        val citationAudit = auditObject?.let { audit ->
                            fun stringList(key: String): List<String> {
                                val values = audit.optJSONArray(key) ?: JSONArray()
                                return buildList { for (index in 0 until values.length()) add(values.optString(index)) }
                            }
                            val findingsArray = audit.optJSONArray("claimFindings") ?: JSONArray()
                            val findings = buildList {
                                for (findingIndex in 0 until findingsArray.length()) {
                                    val finding = findingsArray.optJSONObject(findingIndex) ?: continue
                                    fun findingStrings(key: String): List<String> {
                                        val values = finding.optJSONArray(key) ?: JSONArray()
                                        return buildList { for (entry in 0 until values.length()) add(values.optString(entry)) }
                                    }
                                    val evidenceStatus = ClaimEvidenceStatus.entries.firstOrNull {
                                        it.name == finding.optString("status")
                                    } ?: ClaimEvidenceStatus.NO_LEXICAL_MATCH
                                    add(ClaimEvidenceFinding(
                                        claimExcerpt = finding.optString("claimExcerpt", ""),
                                        citedLabels = findingStrings("citedLabels"),
                                        matchedLabels = findingStrings("matchedLabels"),
                                        bestLexicalOverlap = finding.optDouble("bestLexicalOverlap", 0.0).coerceIn(0.0, 1.0),
                                        status = evidenceStatus,
                                        unmatchedNumericValues = findingStrings("unmatchedNumericValues")
                                    ))
                                }
                            }
                            CitationAudit(
                                citedLabels = stringList("citedLabels"),
                                unknownLabels = stringList("unknownLabels"),
                                uncitedLabels = stringList("uncitedLabels"),
                                noMatchingSources = audit.optBoolean("noMatchingSources", false),
                                invalidSourceLabels = stringList("invalidSourceLabels"),
                                claimFindings = findings
                            )
                        }
                        add(ChatMessage(
                            id = msg.optString("id", UUID.randomUUID().toString()),
                            text = msg.optString("text", ""),
                            isUser = msg.optBoolean("isUser", false),
                            createdAt = msg.optLong("createdAt", System.currentTimeMillis()),
                            isError = msg.optBoolean("isError", false),
                            isInterrupted = msg.optBoolean("isInterrupted", false),
                            sourceReferences = sourceReferences,
                            citationAudit = citationAudit
                        ))
                    }
                }
                val documentsArray = obj.optJSONArray("documents") ?: JSONArray()
                val documents = buildList {
                    for (j in 0 until documentsArray.length()) {
                        val doc = documentsArray.optJSONObject(j) ?: continue
                        add(LocalDocument(
                            id = doc.optString("id", UUID.randomUUID().toString()),
                            displayName = doc.optString("displayName", "Yerel dosya"),
                            storedFileName = doc.optString("storedFileName", ""),
                            bytes = doc.optLong("bytes", 0L),
                            characterCount = doc.optInt("characterCount", 0),
                            importedAt = doc.optLong("importedAt", System.currentTimeMillis()),
                            contentHash = doc.optString("contentHash", ""),
                            mimeType = doc.optString("mimeType", "text/plain"),
                            pageCount = if (doc.isNull("pageCount")) null else doc.optInt("pageCount").takeIf { it > 0 },
                            sectionCount = if (doc.isNull("sectionCount")) null else doc.optInt("sectionCount").takeIf { it > 0 },
                            extractionMethod = doc.optString("extractionMethod", "utf8_text"),
                            extractionWarnings = buildList {
                                val warnings = doc.optJSONArray("extractionWarnings") ?: JSONArray()
                                for (warningIndex in 0 until warnings.length()) add(warnings.optString(warningIndex))
                            }
                        ))
                    }
                }
                add(ChatThread(
                    id = obj.optString("id", UUID.randomUUID().toString()),
                    title = obj.optString("title", "Yeni sohbet"),
                    updatedAt = obj.optLong("updatedAt", System.currentTimeMillis()),
                    messages = messages,
                    mode = AssistantMode.fromStored(obj.optString("mode", "GENERAL")),
                    documents = documents
                ))
            }
        }.sortedByDescending { it.updatedAt }
    }

    private fun serializeThreads(threads: List<ChatThread>): String {
        val array = JSONArray()
        threads.forEach { thread ->
            val messages = JSONArray()
            thread.messages.forEach { msg ->
                messages.put(JSONObject()
                    .put("id", msg.id)
                    .put("text", msg.text)
                    .put("isUser", msg.isUser)
                    .put("createdAt", msg.createdAt)
                    .put("isError", msg.isError)
                    .put("isInterrupted", msg.isInterrupted)
                    .put("sourceReferences", JSONArray().apply {
                        msg.sourceReferences.forEach { ref ->
                            put(JSONObject()
                                .put("label", ref.label)
                                .put("documentId", ref.documentId)
                                .put("documentName", ref.documentName)
                                .put("sectionNumber", ref.sectionNumber)
                                .put("startOffset", ref.startOffset)
                                .put("endOffset", ref.endOffset)
                                .put("excerpt", ref.excerpt))
                        }
                    })
                    .put("citationAudit", msg.citationAudit?.let { audit -> JSONObject()
                        .put("citedLabels", JSONArray(audit.citedLabels))
                        .put("unknownLabels", JSONArray(audit.unknownLabels))
                        .put("uncitedLabels", JSONArray(audit.uncitedLabels))
                        .put("noMatchingSources", audit.noMatchingSources)
                        .put("invalidSourceLabels", JSONArray(audit.invalidSourceLabels))
                        .put("claimFindings", JSONArray().apply {
                            audit.claimFindings.forEach { finding ->
                                put(JSONObject()
                                    .put("claimExcerpt", finding.claimExcerpt)
                                    .put("citedLabels", JSONArray(finding.citedLabels))
                                    .put("matchedLabels", JSONArray(finding.matchedLabels))
                                    .put("bestLexicalOverlap", finding.bestLexicalOverlap)
                                    .put("status", finding.status.name)
                                    .put("unmatchedNumericValues", JSONArray(finding.unmatchedNumericValues)))
                            }
                        })
                    })
                )
            }
            val documents = JSONArray()
            thread.documents.forEach { doc ->
                documents.put(JSONObject()
                    .put("id", doc.id)
                    .put("displayName", doc.displayName)
                    .put("storedFileName", doc.storedFileName)
                    .put("bytes", doc.bytes)
                    .put("characterCount", doc.characterCount)
                    .put("importedAt", doc.importedAt)
                    .put("contentHash", doc.contentHash)
                    .put("mimeType", doc.mimeType)
                    .put("pageCount", doc.pageCount ?: JSONObject.NULL)
                    .put("sectionCount", doc.sectionCount ?: JSONObject.NULL)
                    .put("extractionMethod", doc.extractionMethod)
                    .put("extractionWarnings", JSONArray(doc.extractionWarnings)))
            }
            array.put(JSONObject()
                .put("id", thread.id)
                .put("title", thread.title)
                .put("updatedAt", thread.updatedAt)
                .put("messages", messages)
                .put("mode", thread.mode.name)
                .put("documents", documents))
        }
        return array.toString()
    }

    fun loadActiveChatId(): String? = prefs.getString(KEY_ACTIVE_CHAT, null)
    fun loadActiveModelName(): String? = prefs.getString(KEY_ACTIVE_MODEL, null)
    fun saveActiveModelName(name: String?) { prefs.edit().putString(KEY_ACTIVE_MODEL, name).apply() }
    fun loadBackendPreference(): BackendPreference = BackendPreference.fromStored(prefs.getString(KEY_BACKEND, null))
    fun saveBackendPreference(value: BackendPreference) { prefs.edit().putString(KEY_BACKEND, value.name).apply() }
    fun loadMaxOutputTokens(): Int = prefs.getInt(KEY_MAX_TOKENS, 256).coerceIn(128, 1024)
    fun saveMaxOutputTokens(value: Int) { prefs.edit().putInt(KEY_MAX_TOKENS, value.coerceIn(128, 1024)).apply() }
    fun loadEmbeddingEnabled(): Boolean = prefs.getBoolean(KEY_EMBEDDING_ENABLED, false)
    fun saveEmbeddingEnabled(value: Boolean) { prefs.edit().putBoolean(KEY_EMBEDDING_ENABLED, value).apply() }

    private fun setWarning(message: String) {
        lastStorageWarning = message
        val listener = storageErrorListener ?: return
        mainHandler.post { listener(message) }
    }

    private fun clearWarning() { lastStorageWarning = null }

    override fun close() {
        synchronized(saveLock) { closed = true }
        saveExecutor.shutdown()
    }

    companion object {
        private const val TAG = "BREIT_BRUT_STORAGE"
        private const val KEY_THREADS = "threads_json"
        private const val KEY_ACTIVE_CHAT = "active_chat_id"
        private const val KEY_ACTIVE_MODEL = "active_model_name"
        private const val KEY_MAX_TOKENS = "max_output_tokens"
        private const val KEY_BACKEND = "backend_preference"
        private const val KEY_EMBEDDING_ENABLED = "local_embedding_enabled"
    }
}
