# P0 — Build and CI reliability

## Objective

Make the Android build reproducible, avoid mixing current and stale source files, and ensure CI reports success only when the required checks pass and a debug APK exists.

## Changes in P0

- The workflow supports two explicit source layouts: Android Gradle files checked into the repository root, or the exact `BREIT_BRUT_5_AI_APK_FIX_V9.zip` archive at the repository root.
- ZIP-only builds extract to a fresh runner-temporary directory; sources are never copied over the checkout. ZIP entries with absolute paths, parent traversal, symlinks, duplicate entries, corrupt content, too many entries or an excessive expanded size are rejected.
- The workflow records the selected source directory, source archive SHA-256, toolchain versions, dependency resolution, AAR metadata, unit-test and APK build logs.
- Test/build diagnostic steps preserve their exit codes so that logs can still be uploaded. A final status step fails the job when any required Gradle task fails or the APK is missing.
- The APK has a stable artifact name, and its SHA-256 is recorded. Diagnostic artifacts are uploaded even when a build fails.
- The Linux and Windows bootstrap scripts now agree on Gradle 8.14.4 and verify the official SHA-256 of the Gradle binary distribution before extracting it. `gradle-wrapper.properties` records the same checksum.
- `settings.gradle.kts` uses the normalized project name `BREIT_BRUT_5_AI`; CI output directories are ignored by Git.

## Build checks

The workflow runs:

1. Project preflight checks for required files and pinned toolchain settings.
2. Runtime dependency resolution for `debugRuntimeClasspath`.
3. `:app:checkDebugAarMetadata`.
4. `testDebugUnitTest`.
5. `assembleDebug`.

The job succeeds only if all four Gradle operations return zero and `app/build/outputs/apk/debug/app-debug.apk` exists and is non-empty.

## Usage

### Option A — repository contains source files

Commit `settings.gradle.kts`, `build.gradle.kts`, `app/`, `gradle/`, the bootstrap scripts, documentation and `.github/workflows/android-ci.yml` at the repository root.

### Option B — repository contains the ZIP

Commit `BREIT_BRUT_5_AI_P0.zip` at the root and copy the supplied workflow to `.github/workflows/android-ci.yml`. GitHub discovers workflow definitions from this path; a YAML file merely sitting at repository root will not start an Actions workflow.

## Outputs

- `BREIT_BRUT_5_AI-P0-debug-APK`: debug APK, uploaded only when an APK file exists.
- `BREIT_BRUT_5_AI-P0-build-diagnostics`: preflight record, Gradle logs, task exit codes and available test/build reports.

## Validation caveat

Static file, checksum-configuration and workflow-syntax checks can be run before commit. A genuine Android build still needs to run on GitHub Actions (with JDK 17, Android SDK 36 and dependency-network access). This local container does not have the Android SDK or Gradle installed, so the result of `testDebugUnitTest` and `assembleDebug` must be confirmed by the workflow run before the APK is considered verified.
