# P5 — Inference recovery and chat UX audit

## Investigation

The current runtime is LiteRT-LM Android `0.18.1`, with a Qwen3-0.6B INT4 model as the smallest bundled catalog choice. LiteRT-LM documents a `ThinkingConfig` API: reasoning-capable models may spend the output-token budget on a dedicated thought channel, and a thinking-token budget of `0` disables that mode. The prior app did not explicitly set this configuration and used a default output cap of 512 tokens. That is a plausible cause of very delayed or empty user-facing output on a small device, though the device's runtime log is still needed to distinguish model/template issues from a native runtime hang.

Official references reviewed:
- https://developers.google.com/edge/litert-lm/android
- https://developers.google.com/edge/litert-lm/api_overview
- https://github.com/google-ai-edge/LiteRT-LM/blob/main/kotlin/java/com/google/ai/edge/litertlm/Conversation.kt

## Changes in V8

- Use `ThinkingConfig(enableThinking = false, thinkingTokenBudget = 0)` in conversation config and each generation call by default.
- Replace the SDK Flow convenience overload with an app-owned `MessageCallback` / `callbackFlow` adapter, retaining single-threaded native engine access through the existing AI dispatcher.
- Show elapsed seconds and first-output status while generating.
- Automatically request native cancellation after 120 seconds without first output, or 300 seconds total. Timeout errors are displayed in chat and the conversation is rebuilt after cancellation. This remains a best-effort recovery; a native driver deadlock may still require an app restart.
- Add a model self-test button and a unit test for the direct-answer system prompt.
- Change first-install token cap from 512 to 256; saved token preferences are not overwritten.
- Raise the chat composer by increasing bottom spacing and add `windowSoftInputMode=adjustResize`.

## Validation performed

- ZIP integrity, source paths, expected dependency and workflow configuration are checked before packaging.
- Workflow checks assert the direct-thinking config, callback bridge, timeout, model test entry point, adjusted keyboard mode and the prior setter/test fixes exist.
- Unit tests and `assembleDebug` are configured in GitHub Actions and their diagnostics are uploaded even on failure.

## Remaining validation

This environment has no installed Gradle distribution/wrapper JAR and has not completed a real Android build. The V8 archive therefore must be built through GitHub Actions, then installed and tested on the tablet. On-device acceptance test: open Model Manager, tap **Modeli test et**, confirm the response contains `TEST_OK`, then send a short normal question. If the timeout fires, save the V8 build diagnostics and Android logcat from the inference failure.
