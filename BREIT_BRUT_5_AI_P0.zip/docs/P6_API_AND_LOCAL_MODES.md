# P6 — API + local hybrid modes

## Runtime contract

`AiBackendMode.LOCAL` is the default and only calls LiteRT-LM after a compatible model has been downloaded or imported. Switching modes is an explicit user action; there is no silent fallback from a failed API request to a local model or from local inference to a cloud service.

`AiBackendMode.API` accepts a user-owned endpoint implementing the OpenAI Chat Completions shape. Configure the full HTTPS endpoint ending in `/chat/completions`, a model ID and the user's key in the AI connection sheet. The current client deliberately requires HTTPS, rejects endpoint user-info/query/fragment fields, and disables automatic HTTP redirects so a bearer key is not forwarded to an unexpected host. It does not bundle provider credentials.

## Secret storage

The key is encrypted with AES/GCM/NoPadding using an AES key held in Android Keystore. SharedPreferences stores the ciphertext and IV only; the manifest sets `allowBackup=false`. Key rotation occurs by entering a new key and saving; the separate remove action deletes the ciphertext. Encryption at rest is defense-in-depth only: the key must be present in app memory to make a request and cannot be fully protected from a compromised device or client process. Production commercial use should prefer a server-side proxy that holds the provider key.

## Request and privacy behavior

- Requests use `Authorization: Bearer …`, JSON, a bounded `max_tokens` value and `stream=true` for chat output.
- SSE `data:` chunks are parsed incrementally; `[DONE]` ends the stream. Gateways that return a normal JSON completion despite `stream=true` get a fallback parser.
- API tests use a small non-streaming completion and don't append the test result to the user's conversation.
- The request includes bounded history and, when the user attached local documents, relevant local retrieval excerpts. These snippets leave the device only in API mode; the settings sheet warns about this before the user enables the mode.
- Connection timeout: 15 seconds; read timeout: 60 seconds; overall request/test timeout: 75 seconds. Response bodies are size-limited and errors don't include the Authorization header or key.
- HTTP 401/403 suggests key/permission issues; HTTP 429 suggests provider rate or billing limit; other failures keep a concise error status and allow retry.

## Release verification checklist

1. Build and run `testDebugUnitTest` and `assembleDebug` in GitHub Actions.
2. On device, install the debug APK, select local mode, download the smallest catalog model, and confirm `Modeli test et` returns `TEST_OK`.
3. Configure a user-owned HTTPS Chat Completions-compatible endpoint, model and key; save and run `Bağlantıyı test et`.
4. Send a short API message and verify text appears incrementally; press stop during generation and verify the partial answer remains.
5. Switch back to local mode and verify it uses the installed local model without sending requests to the configured API.
6. Remove the stored API key and verify API mode switches to local.

A static ZIP/YAML/source check does not prove a real APK build or provider connection. The GitHub Actions result and an on-device API test are required for runtime verification.
