@echo off
setlocal EnableExtensions EnableDelayedExpansion
set GRADLE_VERSION=8.14.4
set GRADLE_SHA256=f1771298a70f6db5a29daf62378c4e18a17fc33c9ba6b14362e0cdf40610380d
if not defined GRADLE_USER_HOME set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set GRADLE_HOME_BASE=%GRADLE_USER_HOME%\wrapper\dists\breit-brut-bootstrap
set GRADLE_HOME=%GRADLE_HOME_BASE%\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat
set TEMP_DIR=%GRADLE_HOME_BASE%\unpack
if not exist "%GRADLE_BIN%" (
  if not exist "%GRADLE_HOME_BASE%" mkdir "%GRADLE_HOME_BASE%"
  set ZIP=%GRADLE_HOME_BASE%\gradle-%GRADLE_VERSION%-bin.zip
  if not exist "!ZIP!" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '!ZIP!'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $actual=(Get-FileHash -Algorithm SHA256 -LiteralPath '!ZIP!').Hash.ToLowerInvariant(); if($actual -ne '%GRADLE_SHA256%'){Remove-Item -Force -LiteralPath '!ZIP!' -ErrorAction SilentlyContinue; throw 'Gradle distribution SHA-256 mismatch'}"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $tmp='%TEMP_DIR%'; if(Test-Path $tmp){Remove-Item -Recurse -Force $tmp}; New-Item -ItemType Directory -Force -Path $tmp | Out-Null; Expand-Archive -Force '!ZIP!' $tmp; if(Test-Path '%GRADLE_HOME%'){Remove-Item -Recurse -Force '%GRADLE_HOME%'}; Move-Item (Join-Path $tmp 'gradle-%GRADLE_VERSION%') '%GRADLE_HOME%'; Remove-Item -Recurse -Force $tmp"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" -p "%~dp0" %*
exit /b %ERRORLEVEL%
