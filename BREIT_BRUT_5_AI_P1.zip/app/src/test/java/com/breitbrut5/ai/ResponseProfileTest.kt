package com.breitbrut5.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResponseProfileTest {
    @Test fun allThreeProfilesHaveDistinctBudgets() {
        assertEquals(3, ResponseProfile.entries.size)
        assertTrue(ResponseProfile.FAST.defaultOutputTokens < ResponseProfile.BALANCED.defaultOutputTokens)
        assertTrue(ResponseProfile.BALANCED.defaultOutputTokens < ResponseProfile.DEEP.defaultOutputTokens)
    }

    @Test fun profileOutputLimitsStayWithinSupportedRange() {
        ResponseProfile.entries.forEach { profile ->
            assertTrue(profile.defaultOutputTokens in 128..1024)
            assertTrue(profile.maxOutputTokens in profile.defaultOutputTokens..1024)
            assertTrue(profile.temperature in 0.0..1.0)
            assertTrue(profile.historyMessageLimit > 0)
            assertTrue(profile.historyCharacterBudget > 0)
        }
    }

    @Test fun unknownStoredProfileFallsBackToBalanced() {
        assertEquals(ResponseProfile.BALANCED, ResponseProfile.fromStored("UNKNOWN"))
        assertEquals(ResponseProfile.BALANCED, ResponseProfile.fromStored(null))
    }

    @Test fun knownStoredProfileIsRestored() {
        assertEquals(ResponseProfile.DEEP, ResponseProfile.fromStored("DEEP"))
    }
}
