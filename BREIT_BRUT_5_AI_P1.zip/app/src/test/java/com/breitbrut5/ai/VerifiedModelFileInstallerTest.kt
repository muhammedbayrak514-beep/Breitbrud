package com.breitbrut5.ai

import java.io.File
import java.security.MessageDigest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.io.path.createTempDirectory

class VerifiedModelFileInstallerTest {
    @Test fun checksumMismatchDoesNotReplaceExistingModel() {
        val root = createTempDirectory(prefix = "breit-model-install-fail-").toFile()
        try {
            val existing = File(root, "model.litertlm").apply { writeText("known-good-old-model") }
            val partial = File(root, "model.litertlm.part").apply { writeText("untrusted-new-model") }
            val badHash = "0".repeat(64)
            var failed = false
            try {
                VerifiedModelFileInstaller.promoteVerified(partial, existing, badHash, minimumBytes = 1)
            } catch (_: IllegalArgumentException) {
                failed = true
            }
            assertTrue(failed)
            assertEquals("known-good-old-model", existing.readText())
            assertTrue(partial.isFile)
        } finally {
            root.deleteRecursively()
        }
    }

    @Test fun verifiedArtifactAtomicallyReplacesTargetAndWritesTrustedManifest() {
        val root = createTempDirectory(prefix = "breit-model-install-ok-").toFile()
        try {
            val existing = File(root, "model.litertlm").apply { writeText("old-model") }
            val partial = File(root, "model.litertlm.part").apply { writeText("verified-new-model") }
            val expected = sha256("verified-new-model")
            val actual = VerifiedModelFileInstaller.promoteVerified(partial, existing, expected, minimumBytes = 1)
            assertEquals(expected, actual)
            assertEquals("verified-new-model", existing.readText())
            assertFalse(partial.exists())
            assertTrue(ModelArtifactIntegrity.manifestFile(existing).isFile)
            assertTrue(ModelArtifactIntegrity.manifestFile(existing).readText().contains(expected))
            assertEquals(
                ModelArtifactIntegrity.Result.VERIFIED_EXISTING_FINGERPRINT,
                ModelArtifactIntegrity.verifyOrCreate(existing, expected)
            )
        } finally {
            root.deleteRecursively()
        }
    }

    @Test fun importedArtifactGetsOnlyLocalFingerprint() {
        val root = createTempDirectory(prefix = "breit-model-import-").toFile()
        try {
            val target = File(root, "imported.litertlm")
            val partial = File(root, "imported.litertlm.importing").apply { writeText("user-imported-model") }
            VerifiedModelFileInstaller.promoteImported(partial, target, minimumBytes = 1)
            val manifest = ModelArtifactIntegrity.manifestFile(target).readLines()
            assertEquals("v2", manifest[0])
            assertEquals("local", manifest[3])
        } finally {
            root.deleteRecursively()
        }
    }

    @Test fun incompleteDownloadCannotReplaceExistingModel() {
        val root = createTempDirectory(prefix = "breit-model-install-short-").toFile()
        try {
            val existing = File(root, "model.litertlm").apply { writeText("known-good") }
            val partial = File(root, "model.litertlm.part").apply { writeText("short") }
            val expected = sha256("short")
            var failed = false
            try {
                VerifiedModelFileInstaller.promoteVerified(partial, existing, expected, minimumBytes = 100)
            } catch (_: IllegalArgumentException) {
                failed = true
            }
            assertTrue(failed)
            assertEquals("known-good", existing.readText())
            assertTrue(partial.isFile)
        } finally {
            root.deleteRecursively()
        }
    }

    @Test fun cancellationAfterHashButBeforeAtomicPromotionPreservesExistingModel() {
        val root = createTempDirectory(prefix = "breit-model-install-cancel-").toFile()
        try {
            val existing = File(root, "model.litertlm").apply { writeText("known-good-old-model") }
            val partial = File(root, "model.litertlm.part").apply { writeText("fully-downloaded-new-model") }
            val expected = sha256("fully-downloaded-new-model")
            var cancelled = false
            try {
                VerifiedModelFileInstaller.promoteVerified(
                    partialFile = partial,
                    targetFile = existing,
                    expectedSha256 = expected,
                    minimumBytes = 1,
                    beforePromote = { throw java.util.concurrent.CancellationException("test cancel") }
                )
            } catch (_: java.util.concurrent.CancellationException) {
                cancelled = true
            }
            assertTrue(cancelled)
            assertEquals("known-good-old-model", existing.readText())
            assertTrue(partial.isFile)
        } finally {
            root.deleteRecursively()
        }
    }


    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }
}
