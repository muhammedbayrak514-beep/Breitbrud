package com.breitbrut5.ai

import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AiFailureDiagnosticsTest {
    @Test fun memoryPressureHasStableCodeAndActionableMessage() {
        val diagnostic = AiFailureDiagnostics.classify(OutOfMemoryError("allocation failed"))
        assertEquals("memory_pressure", diagnostic.code)
        assertTrue(diagnostic.userMessage.contains("RAM"))
        assertFalse(diagnostic.retryable)
    }

    @Test fun missingDnsIsNotAutomaticallyRetried() {
        val error = UnknownHostException("api.example.invalid")
        assertEquals("network_unavailable", AiFailureDiagnostics.classify(error).code)
        assertFalse(ApiRetryPolicy.shouldRetry(error, retryNumber = 0, hasPartialOutput = false))
    }

    @Test fun socketTimeoutCanBeRetriedBeforeAnyPartialOutput() {
        val error = SocketTimeoutException("read timed out")
        assertEquals("network_timeout", AiFailureDiagnostics.classify(error).code)
        assertTrue(ApiRetryPolicy.shouldRetry(error, retryNumber = 0, hasPartialOutput = false))
        assertFalse(ApiRetryPolicy.shouldRetry(error, retryNumber = 0, hasPartialOutput = true))
    }

    @Test fun serverFailureIsRetriedButAuthenticationFailureIsNot() {
        assertTrue(ApiRetryPolicy.shouldRetry(ApiHttpException(503, message = "HTTP 503"), 0, false))
        assertTrue(ApiRetryPolicy.shouldRetry(ApiHttpException(429, 1_200, "HTTP 429"), 1, false))
        assertFalse(ApiRetryPolicy.shouldRetry(ApiHttpException(401, message = "HTTP 401"), 0, false))
    }

    @Test fun retryBudgetIsBoundedAndDelayIsCapped() {
        assertEquals(2, ApiRetryPolicy.MAX_RETRIES)
        assertFalse(ApiRetryPolicy.shouldRetry(SocketTimeoutException(), 2, false))
        assertEquals(15_000L, ApiRetryPolicy.delayMillis(1, 30_000L))
        assertEquals(700L, ApiRetryPolicy.delayMillis(1))
        assertFalse(ApiRetryPolicy.shouldRetry(ApiHttpException(503, message = "HTTP 503"), 0, true))
    }

    @Test fun requestTimeoutStatusesHaveActionableTransientDiagnostic() {
        listOf(408, 425).forEach { code ->
            val error = ApiHttpException(code, message = "HTTP $code")
            val diagnostic = AiFailureDiagnostics.classify(error)
            assertEquals("api_transient_failure", diagnostic.code)
            assertTrue(diagnostic.retryable)
            assertTrue(ApiRetryPolicy.shouldRetry(error, retryNumber = 0, hasPartialOutput = false))
        }
    }

    @Test fun unsupportedApiRequestIsDiagnosedButNotRetried() {
        val error = ApiHttpException(404, message = "HTTP 404")
        val diagnostic = AiFailureDiagnostics.classify(error)
        assertEquals("api_request_rejected", diagnostic.code)
        assertFalse(diagnostic.retryable)
        assertFalse(ApiRetryPolicy.shouldRetry(error, retryNumber = 0, hasPartialOutput = false))
    }


    @Test fun arbitraryIoAndTlsErrorsAreNotRetried() {
        assertFalse(ApiRetryPolicy.shouldRetry(IOException("invalid request body"), 0, false))
        assertFalse(ApiRetryPolicy.shouldRetry(javax.net.ssl.SSLException("certificate rejected"), 0, false))
    }

    @Test fun retryAfterSupportsSecondsAndHttpDate() {
        assertEquals(2_000L, ApiRetryPolicy.parseRetryAfterMillis("2", nowMillis = 10_000L))
        val format = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("GMT")
        }
        val httpDate = format.format(java.util.Date(12_000L))
        assertEquals(2_000L, ApiRetryPolicy.parseRetryAfterMillis(httpDate, nowMillis = 10_000L))
    }

    @Test fun serverFailureHasStableDiagnosticAndRetryableFlag() {
        val diagnostic = AiFailureDiagnostics.classify(ApiHttpException(503, message = "service unavailable"))
        assertEquals("api_server_error", diagnostic.code)
        assertTrue(diagnostic.retryable)
    }
}
