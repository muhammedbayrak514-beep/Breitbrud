package com.breitbrut5.ai

import org.junit.Assert.assertEquals
import org.junit.Test

class ApiUsageMathTest {
    @Test fun estimatesZeroCharactersAsZeroTokens() {
        assertEquals(0L, ApiUsageMath.estimateTokens(0))
    }

    @Test fun roundsPartialFourCharacterGroupsUp() {
        assertEquals(1L, ApiUsageMath.estimateTokens(1))
        assertEquals(1L, ApiUsageMath.estimateTokens(4))
        assertEquals(2L, ApiUsageMath.estimateTokens(5))
        assertEquals(3L, ApiUsageMath.estimateTokens(9))
    }

    @Test fun negativeCharacterCountsAreClampedToZero() {
        assertEquals(0L, ApiUsageMath.estimateTokens(-20))
    }
}
