package com.breitbrut5.ai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatSearchTest {
    private val thread = ChatThread(
        title = "Strateji oyunu tasarımı",
        messages = listOf(
            ChatMessage(text = "Araç üretim zincirini planlayalım", isUser = true),
            ChatMessage(text = "Fabrikalar ve tedarikçiler arasında bağlantı kuralım.", isUser = false)
        ),
        documents = listOf(
            LocalDocument(displayName = "Ekonomi Taslağı.pdf", storedFileName = "economy.txt", bytes = 10, characterCount = 10)
        )
    )

    @Test fun matchesTitleCaseInsensitively() {
        assertTrue(ChatSearch.matches(thread, "STRATEJİ"))
    }

    @Test fun matchesMessageContent() {
        assertTrue(ChatSearch.matches(thread, "tedarikçiler"))
    }

    @Test fun matchesAttachedDocumentName() {
        assertTrue(ChatSearch.matches(thread, "ekonomi taslağı"))
    }

    @Test fun blankSearchMatchesAllThreads() {
        assertTrue(ChatSearch.matches(thread, "  "))
    }

    @Test fun unrelatedQueryDoesNotMatch() {
        assertFalse(ChatSearch.matches(thread, "basketbol"))
    }

    @Test fun matchingPreviewIsBoundedAndContainsMatch() {
        val preview = ChatSearch.matchingPreview(thread, "tedarikçiler")
        assertTrue(preview!!.contains("tedarikçiler"))
        assertTrue(preview.length <= 120)
    }
}
