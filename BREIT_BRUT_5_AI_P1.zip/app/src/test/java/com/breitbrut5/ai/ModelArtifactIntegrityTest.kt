package com.breitbrut5.ai

import java.io.File
import java.security.MessageDigest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.io.path.createTempDirectory

class ModelArtifactIntegrityTest {
    @Test fun firstLoadCreatesLocalFingerprintAndLaterVerificationSucceeds() {
        val root = createTempDirectory(prefix = "breit-model-integrity-").toFile()
        try {
            val model = File(root, "mock.litertlm").apply { writeText("model-bytes-for-test") }
            assertEquals(ModelArtifactIntegrity.Result.CREATED_FIRST_FINGERPRINT, ModelArtifactIntegrity.verifyOrCreate(model))
            assertTrue(ModelArtifactIntegrity.manifestFile(model).isFile)
            assertEquals(ModelArtifactIntegrity.Result.VERIFIED_EXISTING_FINGERPRINT, ModelArtifactIntegrity.verifyOrCreate(model))
        } finally { root.deleteRecursively() }
    }

    @Test fun changedModelSizeIsRejectedAgainstExistingFingerprint() {
        val root = createTempDirectory(prefix = "breit-model-change-").toFile()
        try {
            val model = File(root, "mock.litertlm").apply { writeText("first") }
            ModelArtifactIntegrity.initialize(model)
            model.writeText("changed-size")
            var failed = false
            try { ModelArtifactIntegrity.verifyOrCreate(model) } catch (_: IllegalArgumentException) { failed = true }
            assertTrue(failed)
        } finally { root.deleteRecursively() }
    }

    @Test fun sameLengthMutationIsDetectedAfterFingerprintCreation() {
        val root = createTempDirectory(prefix = "breit-model-same-length-").toFile()
        try {
            val model = File(root, "mock.litertlm").apply { writeText("first-bytes") }
            ModelArtifactIntegrity.initialize(model)
            model.writeText("other-bytes") // Same length, different content.
            model.setLastModified(System.currentTimeMillis() + 2_000L)
            var failed = false
            try { ModelArtifactIntegrity.verifyOrCreate(model) } catch (_: IllegalArgumentException) { failed = true }
            assertTrue(failed)
        } finally { root.deleteRecursively() }
    }

    @Test fun publisherChecksumIsRequiredForCatalogArtifact() {
        val root = createTempDirectory(prefix = "breit-model-publisher-").toFile()
        try {
            val bytes = "trusted model fixture"
            val expected = sha256(bytes)
            val model = File(root, "catalog.litertlm").apply { writeText(bytes) }
            assertEquals(ModelArtifactIntegrity.Result.CREATED_FIRST_FINGERPRINT, ModelArtifactIntegrity.verifyOrCreate(model, expected))
            assertEquals(expected, ModelArtifactIntegrity.manifestFile(model).readLines()[2])
            assertEquals(expected, ModelArtifactIntegrity.manifestFile(model).readLines()[3])
        } finally { root.deleteRecursively() }
    }

    @Test fun publisherChecksumMismatchIsRejectedOnFirstFingerprint() {
        val root = createTempDirectory(prefix = "breit-model-publisher-bad-").toFile()
        try {
            val model = File(root, "catalog.litertlm").apply { writeText("tampered model") }
            var failed = false
            try { ModelArtifactIntegrity.verifyOrCreate(model, "0".repeat(64)) } catch (_: IllegalArgumentException) { failed = true }
            assertTrue(failed)
            assertTrue(!ModelArtifactIntegrity.manifestFile(model).exists())
        } finally { root.deleteRecursively() }
    }

    @Test fun localManifestCannotOverridePublisherPinnedHash() {
        val root = createTempDirectory(prefix = "breit-model-local-vs-publisher-").toFile()
        try {
            val model = File(root, "catalog.litertlm").apply { writeText("wrong bytes") }
            ModelArtifactIntegrity.initialize(model)
            var failed = false
            try { ModelArtifactIntegrity.verifyOrCreate(model, "f".repeat(64)) } catch (_: IllegalArgumentException) { failed = true }
            assertTrue(failed)
        } finally { root.deleteRecursively() }
    }

    @Test fun oldLocalOnlyManifestIsUpgradedAfterPublisherHashMatches() {
        val root = createTempDirectory(prefix = "breit-model-upgrade-manifest-").toFile()
        try {
            val content = "trusted artifact bytes"
            val expected = sha256(content)
            val model = File(root, "catalog.litertlm").apply { writeText(content) }
            val oldDigest = sha256(content)
            ModelArtifactIntegrity.manifestFile(model).writeText("${model.length()}\n$oldDigest\n")
            assertEquals(ModelArtifactIntegrity.Result.CREATED_FIRST_FINGERPRINT, ModelArtifactIntegrity.verifyOrCreate(model, expected))
            val upgraded = ModelArtifactIntegrity.manifestFile(model).readLines()
            assertEquals("v2", upgraded[0])
            assertEquals(expected, upgraded[3])
        } finally { root.deleteRecursively() }
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }
}
