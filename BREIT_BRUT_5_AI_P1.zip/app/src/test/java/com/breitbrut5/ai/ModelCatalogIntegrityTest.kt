package com.breitbrut5.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelCatalogIntegrityTest {
    @Test fun everyAutomaticallyDownloadedModelHasPinnedSha256() {
        assertEquals(3, ModelCatalog.items.size)
        ModelCatalog.items.forEach { item ->
            assertTrue("${item.fileName} must have a 64-character SHA-256", item.expectedSha256.matches(Regex("[0-9a-f]{64}")))
            assertTrue(item.downloadUrl.startsWith("https://"))
        }
    }

    @Test fun catalogHashesMatchTheAuditedPublisherArtifacts() {
        val expected = mapOf(
            "qwen06-int4" to "03e7da1eb1108b50dffaa9bb52cc7bcbad2eb0c66ca990267f480c1e545d2856",
            "qwen06-int8" to "c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108",
            "qwen17-int4" to "2a72330b504a6596d53a2c00923c57173b10f1b83e6a541213ffec08d1fc5de8"
        )
        assertEquals(expected.keys, ModelCatalog.items.map { it.id }.toSet())
        ModelCatalog.items.forEach { item -> assertEquals(expected[item.id], item.expectedSha256) }
        assertEquals(
            "2d079ee2f6f066b1f368e8d7c819f55214eaef1d0513b312321901f30ab286fb",
            LocalEmbeddingModelCatalog.SHA256
        )
    }

    @Test fun expectedHashesAreUniqueForTheCatalogArtifacts() {
        assertEquals(ModelCatalog.items.size, ModelCatalog.items.map { it.expectedSha256 }.toSet().size)
    }

    @Test fun embeddingArtifactAlsoHasPublisherPinnedSha256() {
        assertTrue(LocalEmbeddingModelCatalog.SHA256.matches(Regex("[0-9a-f]{64}")))
        assertTrue(LocalEmbeddingModelCatalog.DOWNLOAD_URL.startsWith("https://"))
    }
}
