package com.breitbrut5.ai

/** User-facing answer depth presets. They tune budgets and style, not hidden reasoning display. */
internal enum class ResponseProfile(
    val label: String,
    val description: String,
    val defaultOutputTokens: Int,
    val maxOutputTokens: Int,
    val temperature: Double,
    val topK: Int,
    val topP: Double,
    val historyMessageLimit: Int,
    val historyCharacterBudget: Int,
    val instructions: String
) {
    FAST(
        label = "Hızlı",
        description = "Kısa, doğrudan ve düşük gecikmeli yanıtlar",
        defaultOutputTokens = 256,
        maxOutputTokens = 384,
        temperature = 0.40,
        topK = 16,
        topP = 0.85,
        historyMessageLimit = 6,
        historyCharacterBudget = 1_500,
        instructions = "Kısa ve doğrudan yanıt ver. Önce sonucu söyle; yalnızca gerekli ayrıntıları ve tek bir örneği ekle."
    ),
    BALANCED(
        label = "Dengeli",
        description = "Günlük kullanım için açıklama ve hız dengesi",
        defaultOutputTokens = 512,
        maxOutputTokens = 768,
        temperature = 0.65,
        topK = 20,
        topP = 0.90,
        historyMessageLimit = 10,
        historyCharacterBudget = 2_500,
        instructions = "Sonucu anlaşılır biçimde açıkla. Gerekli gerekçeyi, önemli ayrıntıları ve uygun olduğunda kısa bir örneği ver."
    ),
    DEEP(
        label = "Derin",
        description = "Daha kapsamlı bağlam ve ayrıntılı değerlendirme",
        defaultOutputTokens = 1_024,
        maxOutputTokens = 1_024,
        temperature = 0.55,
        topK = 24,
        topP = 0.92,
        historyMessageLimit = 18,
        historyCharacterBudget = 5_000,
        instructions = "Konuyu kapsamlı ama düzenli ele al. Sonucu, dayanakları, varsayımları, sınırlamaları ve uygulanabilir adımları ayır. Gerektiğinde örnek ve karşılaştırma kullan; emin olmadığın noktaları açıkça belirt. İçsel düşünme dökümü yerine kullanıcıya yönelik gerekçe sun."
    );

    companion object {
        fun fromStored(value: String?): ResponseProfile = entries.firstOrNull { it.name == value } ?: BALANCED
    }
}
