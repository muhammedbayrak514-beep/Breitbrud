package com.breitbrut5.ai

import java.io.File
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/** Installs only fully-written, size-checked and checksum-verified model artifacts. */
internal object VerifiedModelFileInstaller {
    fun promoteVerified(
        partialFile: File,
        targetFile: File,
        expectedSha256: String,
        minimumBytes: Long,
        beforePromote: () -> Unit = {}
    ): String {
        require(expectedSha256.matches(Regex("[0-9a-fA-F]{64}"))) { "Güvenilir model SHA-256 değeri geçersiz." }
        require(partialFile.isFile && partialFile.length() >= minimumBytes) {
            "Geçici model dosyası eksik veya beklenen boyutun altında."
        }
        require(partialFile.canonicalFile.parentFile == targetFile.canonicalFile.parentFile) {
            "Model dosyası aynı klasörde hazırlanmadığı için güvenli biçimde etkinleştirilemedi."
        }
        val actual = ModelArtifactIntegrity.sha256(partialFile)
        require(actual.equals(expectedSha256, ignoreCase = true)) {
            "Model SHA-256 doğrulaması başarısız. İndirilen dosya etkinleştirilmedi; mevcut model korundu."
        }
        // Cancellation may arrive while hashing a large file; check again immediately before commit.
        beforePromote()
        try {
            // Same-directory atomic rename replaces the old file in one filesystem operation.
            // No delete/copy fallback: if atomic promotion is unavailable, keep the old model.
            Files.move(
                partialFile.toPath(),
                targetFile.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING
            )
        } catch (e: AtomicMoveNotSupportedException) {
            throw IOException("Bu depolama alanı güvenli atomik model değişimini desteklemiyor. Mevcut model korundu.", e)
        }
        ModelArtifactIntegrity.recordVerifiedDigest(targetFile, actual, expectedSha256)
        return actual
    }

    fun promoteImported(
        partialFile: File,
        targetFile: File,
        minimumBytes: Long,
        beforePromote: () -> Unit = {}
    ): String {
        require(partialFile.isFile && partialFile.length() >= minimumBytes) {
            "İçe aktarılan geçici model dosyası eksik veya çok küçük."
        }
        require(partialFile.canonicalFile.parentFile == targetFile.canonicalFile.parentFile) {
            "Model dosyası aynı klasörde hazırlanmadığı için güvenli biçimde etkinleştirilemedi."
        }
        val actual = ModelArtifactIntegrity.sha256(partialFile)
        beforePromote()
        try {
            Files.move(
                partialFile.toPath(),
                targetFile.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING
            )
        } catch (e: AtomicMoveNotSupportedException) {
            throw IOException("Bu depolama alanı güvenli atomik içe aktarmayı desteklemiyor.", e)
        }
        // Imported files have no publisher checksum: this fingerprint detects later local changes,
        // but it is intentionally not described as proof of publisher authenticity.
        ModelArtifactIntegrity.recordVerifiedDigest(targetFile, actual)
        return actual
    }
}
