package com.breitbrut5.ai

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.ThinkingConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExecutorCoroutineDispatcher
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.TimeoutCancellationException
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

internal class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = LocalRepository(application)
    private val apiSettingsStore = ApiSettingsStore(application)
    private val apiUsageStore = ApiUsageStore(application)
    private val performanceTelemetry = LocalPerformanceTelemetry(File(application.filesDir, "telemetry/model-performance.tsv"))
    private val processStartTimeMs = System.currentTimeMillis()
    private var modelLoadedThisProcess = false
    private val modelDirectory = File(application.filesDir, "models").apply { mkdirs() }
    private val embeddingModelDirectory = File(application.filesDir, "embedding_models").apply { mkdirs() }
    private val embeddingModelFile = File(embeddingModelDirectory, LocalEmbeddingModelCatalog.FILE_NAME)
    private val embeddingEngine = LiteRtLocalTextEmbedder(embeddingModelFile)
    private val contextDocumentDirectory = File(application.filesDir, "context_documents").apply { mkdirs() }
    private val documentImportPipeline = DocumentImportPipeline(application)
    private val ragIndex = LocalRagIndexStore(File(application.filesDir, "local_rag_index"))
    private val aiExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "breit-brut-local-ai").apply { isDaemon = true }
    }
    private val aiDispatcher: ExecutorCoroutineDispatcher = aiExecutor.asCoroutineDispatcher()

    var threads by androidx.compose.runtime.mutableStateOf(repository.loadThreads())
        private set
    var activeThreadId by androidx.compose.runtime.mutableStateOf(repository.loadActiveChatId())
        private set
    var modelReady by androidx.compose.runtime.mutableStateOf(false)
        private set
    var isModelLoading by androidx.compose.runtime.mutableStateOf(false)
        private set
    var isDownloading by androidx.compose.runtime.mutableStateOf(false)
        private set
    var isImportingContext by androidx.compose.runtime.mutableStateOf(false)
        private set
    var isEmbeddingLoading by androidx.compose.runtime.mutableStateOf(false)
        private set
    var embeddingModelReady by androidx.compose.runtime.mutableStateOf(false)
        private set
    var embeddingModelInstalled by androidx.compose.runtime.mutableStateOf(embeddingModelFile.isFile && embeddingModelFile.length() >= LocalEmbeddingModelCatalog.MIN_VALID_BYTES)
        private set
    var embeddingEnabled by androidx.compose.runtime.mutableStateOf(repository.loadEmbeddingEnabled())
        private set
    var embeddingStatus by androidx.compose.runtime.mutableStateOf("Anlamsal arama kapalı • BM25 + TF-IDF hazır")
        private set
    var downloadProgress by androidx.compose.runtime.mutableFloatStateOf(0f)
        private set
    var downloadLabel by androidx.compose.runtime.mutableStateOf("")
        private set
    var busy by androidx.compose.runtime.mutableStateOf(false)
        private set
    var generationElapsedSeconds by androidx.compose.runtime.mutableIntStateOf(0)
        private set
    var hasReceivedFirstToken by androidx.compose.runtime.mutableStateOf(false)
        private set
    var isStopping by androidx.compose.runtime.mutableStateOf(false)
        private set
    var stopTimedOut by androidx.compose.runtime.mutableStateOf(false)
        private set
    var status by androidx.compose.runtime.mutableStateOf("Yerel model yüklenmedi")
        private set
    var errorText by androidx.compose.runtime.mutableStateOf<String?>(null)
        private set
    var models by androidx.compose.runtime.mutableStateOf<List<LocalModel>>(emptyList())
        private set
    /** Catalog files that failed publisher SHA-256 verification are hidden from the installed list so they can be safely re-downloaded. */
    var invalidCatalogModelNames by androidx.compose.runtime.mutableStateOf<Set<String>>(emptySet())
        private set
    var activeModelName by androidx.compose.runtime.mutableStateOf(repository.loadActiveModelName())
        private set
    var backendPreference by androidx.compose.runtime.mutableStateOf(repository.loadBackendPreference())
        private set
    var activeBackendLabel by androidx.compose.runtime.mutableStateOf("—")
        private set
    var downloadingModelName by androidx.compose.runtime.mutableStateOf<String?>(null)
        private set
    var draft by androidx.compose.runtime.mutableStateOf("")
    var maxOutputTokens by androidx.compose.runtime.mutableIntStateOf(repository.loadMaxOutputTokens())
        private set
    var responseProfile by androidx.compose.runtime.mutableStateOf(repository.loadResponseProfile())
        private set
    var apiUsage by androidx.compose.runtime.mutableStateOf(runCatching { apiUsageStore.load() }.getOrDefault(ApiUsageSnapshot()))
        private set
    val apiEndpointHost: String
        get() = runCatching { URL(apiEndpoint).host }.getOrDefault("")
    val effectiveOutputTokens: Int
        get() = minOf(maxOutputTokens, responseProfile.maxOutputTokens).coerceAtLeast(128)
    var aiBackendMode by androidx.compose.runtime.mutableStateOf(apiSettingsStore.loadMode())
        private set
    var apiEndpoint by androidx.compose.runtime.mutableStateOf(apiSettingsStore.loadEndpoint())
        private set
    var apiModelName by androidx.compose.runtime.mutableStateOf(apiSettingsStore.loadModel())
        private set
    var apiKeyConfigured by androidx.compose.runtime.mutableStateOf(apiSettingsStore.hasApiKey())
        private set
    var isTestingApi by androidx.compose.runtime.mutableStateOf(false)
        private set
    var apiTestResult by androidx.compose.runtime.mutableStateOf<String?>(null)
        private set
    var apiConfigMessage by androidx.compose.runtime.mutableStateOf<String?>(null)
        private set
    var performanceSamples by androidx.compose.runtime.mutableStateOf(
        runCatching { performanceTelemetry.load() }.getOrDefault(emptyList())
    )
        private set

    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private var responseJob: kotlinx.coroutines.Job? = null
    private var generationClockJob: Job? = null
    private var isPreparingTurn = false
    private var embeddingAutoLoadPending = repository.loadEmbeddingEnabled() && embeddingModelFile.isFile && embeddingModelFile.length() >= LocalEmbeddingModelCatalog.MIN_VALID_BYTES
    private var stopWatchdogJob: kotlinx.coroutines.Job? = null
    private var persistenceJob: kotlinx.coroutines.Job? = null
    private var downloadJob: kotlinx.coroutines.Job? = null
    @Volatile private var downloadConnection: HttpURLConnection? = null
    @Volatile private var apiConnection: HttpURLConnection? = null
    @Volatile private var downloadCancellationRequested = false

    val activeThread: ChatThread?
        get() = threads.firstOrNull { it.id == activeThreadId }
    val activeMode: AssistantMode
        get() = activeThread?.mode ?: AssistantMode.GENERAL
    val activeDocuments: List<LocalDocument>
        get() = activeThread?.documents.orEmpty()
    val messages: List<ChatMessage>
        get() = activeThread?.messages ?: emptyList()
    val deviceProfile: DeviceProfile
        get() = DeviceProfile.read(getApplication())
    val modelSuitability: List<ModelSuitability>
        get() = DeviceModelAdvisor.rank(deviceProfile)
    val performanceSummary: PerformanceSummary?
        get() = PerformanceMath.summarize(performanceSamples)
    val modelLoadSummary: ModelLoadSummary?
        get() = PerformanceMath.summarizeModelLoads(performanceSamples)
    val deviceReadiness: List<Pair<ModelCatalogItem, DeviceReadiness>>
        get() = ModelCatalog.items.map { it to DeviceReadinessScorer.assess(deviceProfile, it) }
    val isWorking: Boolean
        get() = busy || isModelLoading || isDownloading || isImportingContext || isEmbeddingLoading || isTestingApi

    init {
        repository.setStorageErrorListener { warning ->
            errorText = warning
        }
        if (threads.isEmpty()) {
            val first = ChatThread()
            threads = listOf(first)
            activeThreadId = first.id
            persistThreads()
        } else if (activeThreadId == null || threads.none { it.id == activeThreadId }) {
            activeThreadId = threads.first().id
            persistThreads()
        }
        reconcileContextDocuments()
        cleanupOrphanModelArtifacts()
        refreshModels()
        val savedName = activeModelName
        if (aiBackendMode == AiBackendMode.LOCAL && savedName != null && safeModelFile(savedName)?.isFile == true) {
            loadModel(savedName, autoLoad = true)
        } else {
            status = if (aiBackendMode == AiBackendMode.API) {
                if (apiKeyConfigured) "API modu seçili • bağlantı hazır; ilk istek bekleniyor" else "API modu seçili • API anahtarını ayarlardan ekle"
            } else "Model seçilmedi • API anahtarı gerekmez"
            if (embeddingAutoLoadPending) {
                embeddingAutoLoadPending = false
                loadEmbeddingSearch(autoLoad = true)
            }
        }
        if (embeddingEnabled && !embeddingModelInstalled) {
            embeddingEnabled = false
            repository.saveEmbeddingEnabled(false)
            embeddingStatus = "Embedding modeli bulunamadı • metinsel arama kullanılacak"
        } else if (!embeddingEnabled && embeddingModelInstalled) {
            embeddingStatus = "Embedding modeli kurulu • isteğe bağlı"
        }
        repository.lastStorageWarning?.let { errorText = it }
    }

    fun newChat() {
        if (isWorking) return
        val thread = ChatThread()
        val candidate = listOf(thread) + threads
        val keep = candidate.take(MAX_THREADS)
        val dropped = candidate.drop(MAX_THREADS)
        threads = keep
        activeThreadId = thread.id
        if (dropped.isNotEmpty()) viewModelScope.launch(Dispatchers.IO) { dropped.forEach(::deleteThreadDocumentFiles) }
        persistThreads()
        rebuildConversationForActiveThread()
    }

    fun setAssistantMode(mode: AssistantMode) {
        if (isWorking || isStopping || activeMode == mode) return
        val thread = activeThread ?: return
        updateThread(thread.copy(mode = mode, updatedAt = System.currentTimeMillis()))
        status = "${mode.label} modu seçildi"
        rebuildConversationForActiveThread()
    }

    /** Import one local document through the same pipeline used for multi-select import. */
    fun importContextDocument(uri: Uri) = importContextDocuments(listOf(uri))

    /** P4.4: batch import through Android's user-selected document URIs. */
    fun importContextDocuments(uris: List<Uri>) {
        if (isWorking || isStopping || uris.isEmpty()) return
        val threadId = activeThreadId ?: return
        val distinctUris = uris.distinctBy { it.toString() }
        val selected = distinctUris.take(MAX_BATCH_IMPORT_DOCUMENTS)
        isImportingContext = true
        errorText = null
        status = "Yerel belgeler hazırlanıyor…"
        viewModelScope.launch {
            var added = 0
            var duplicates = 0
            val failures = mutableListOf<String>()
            try {
                selected.forEachIndexed { index, uri ->
                    coroutineContext.ensureActive()
                    status = "Belge işleniyor (${index + 1}/${selected.size})…"
                    val name = withContext(Dispatchers.IO) { runCatching { queryDisplayName(uri) }.getOrDefault("Belge ${index + 1}") }.take(120)
                    try {
                        when (importOneContextDocument(uri, threadId)) {
                            DocumentImportResult.ADDED -> added++
                            DocumentImportResult.DUPLICATE -> duplicates++
                        }
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (e: Exception) {
                        failures += "$name: ${e.message ?: "okuma hatası"}"
                    }
                }
                status = when {
                    added > 0 -> "$added yerel belge eklendi" + if (duplicates > 0) " • $duplicates kopya atlandı" else ""
                    duplicates > 0 && failures.isEmpty() -> "Seçilen belgeler zaten bu sohbette ekli"
                    failures.isEmpty() -> "Yeni belge eklenmedi"
                    else -> "Belge aktarımı tamamlandı; bazı dosyalar eklenemedi"
                }
                val allFailures = failures + if (distinctUris.size > selected.size) listOf("Seçimin ilk ${selected.size} farklı dosyası işlendi; parti sınırı ${MAX_BATCH_IMPORT_DOCUMENTS}.") else emptyList()
                if (allFailures.isNotEmpty()) {
                    errorText = allFailures.take(3).joinToString("\n") + if (allFailures.size > 3) "\n… ve ${allFailures.size - 3} hata daha" else ""
                }
                if (added > 0) rebuildConversationForActiveThread()
            } catch (cancelled: CancellationException) {
                status = "Belge aktarımı durduruldu"
                throw cancelled
            } finally {
                isImportingContext = false
            }
        }
    }

    private enum class DocumentImportResult { ADDED, DUPLICATE }

    private suspend fun importOneContextDocument(uri: Uri, threadId: String): DocumentImportResult {
        var savedFile: File? = null
        var indexedDocumentId: String? = null
        try {
            val displayName = withContext(Dispatchers.IO) { queryDisplayName(uri) }.take(160)
            val extracted = withContext(Dispatchers.IO) { documentImportPipeline.extract(uri, displayName) }
            val clean = sanitizeExtractedDocument(extracted.text)
            if (clean.isBlank()) error("Dosyada okunabilir metin bulunamadı.")
            if (clean.length > DocumentImportPipeline.MAX_EXTRACTED_TEXT_CHARS) {
                error("Çıkarılan metin desteklenen karakter sınırını aşıyor.")
            }
            val thread = threads.firstOrNull { it.id == threadId } ?: error("Belgenin ekleneceği sohbet artık mevcut değil.")
            val contentHash = LocalRagIndexStore.fingerprint(clean)
            val duplicate = withContext(Dispatchers.IO) {
                findDuplicateLocalDocument(thread.documents, contentHash) { existing ->
                    safeContextDocumentFile(existing.storedFileName)?.takeIf { it.isFile }
                        ?.readText(StandardCharsets.UTF_8)
                }
            }
            if (duplicate != null) return DocumentImportResult.DUPLICATE
            if (thread.documents.size >= MAX_CONTEXT_DOCUMENTS) {
                error("Bir sohbete en fazla $MAX_CONTEXT_DOCUMENTS yerel belge eklenebilir.")
            }
            val docId = UUID.randomUUID().toString()
            val outputFile = File(contextDocumentDirectory, "${threadId}_$docId.txt")
            savedFile = outputFile
            withContext(Dispatchers.IO) { outputFile.writeText(clean, StandardCharsets.UTF_8) }
            val doc = LocalDocument(
                id = docId,
                displayName = displayName,
                storedFileName = outputFile.name,
                bytes = outputFile.length(),
                characterCount = clean.length,
                contentHash = contentHash,
                mimeType = extracted.mimeType,
                pageCount = extracted.pageCount,
                sectionCount = extracted.sectionCount,
                extractionMethod = extracted.extractionMethod,
                extractionWarnings = extracted.warnings
            )
            // Build and persist the offline search index before making the document visible in chat.
            withContext(Dispatchers.IO) { ragIndex.upsertDocument(doc.id, doc.displayName, clean) }
            indexedDocumentId = doc.id
            val latestThread = threads.firstOrNull { it.id == threadId } ?: error("Belgenin bağlı olduğu sohbet kapandı.")
            updateThread(latestThread.copy(documents = latestThread.documents + doc, updatedAt = System.currentTimeMillis()))
            return DocumentImportResult.ADDED
        } catch (cancelled: CancellationException) {
            savedFile?.delete()
            indexedDocumentId?.let { withContext(NonCancellable + Dispatchers.IO) { ragIndex.removeDocument(it) } }
            throw cancelled
        } catch (e: Exception) {
            savedFile?.delete()
            indexedDocumentId?.let { withContext(Dispatchers.IO) { ragIndex.removeDocument(it) } }
            throw e
        }
    }

    private fun sanitizeExtractedDocument(content: String): String = DocumentIngestionPolicy.sanitize(content)

    /** Replace the contents of an existing local reference and rebuild its persisted search index. */
    fun replaceContextDocument(documentId: String, uri: Uri) {
        if (isWorking || isStopping) return
        val threadId = activeThreadId ?: return
        val initialThread = activeThread ?: return
        val originalDocument = initialThread.documents.firstOrNull { it.id == documentId } ?: return
        val targetFile = safeContextDocumentFile(originalDocument.storedFileName) ?: return
        isImportingContext = true
        errorText = null
        status = "Yerel belge güncelleniyor…"
        viewModelScope.launch {
            var tempFile: File? = null
            var oldContent: String? = null
            var replaced = false
            try {
                val displayName = withContext(Dispatchers.IO) { queryDisplayName(uri) }.take(160)
                val extracted = withContext(Dispatchers.IO) { documentImportPipeline.extract(uri, displayName) }
                val clean = sanitizeExtractedDocument(extracted.text)
                if (clean.isBlank()) error("Dosyada okunabilir metin bulunamadı.")
                if (clean.length > DocumentImportPipeline.MAX_EXTRACTED_TEXT_CHARS) error("Çıkarılan metin desteklenen karakter sınırını aşıyor.")
                if (!targetFile.isFile) error("Güncellenecek yerel belge artık bulunamıyor.")
                oldContent = withContext(Dispatchers.IO) { targetFile.readText(StandardCharsets.UTF_8) }
                tempFile = File(contextDocumentDirectory, "${threadId}_${documentId}.replace.tmp")
                withContext(Dispatchers.IO) { tempFile!!.writeText(clean, StandardCharsets.UTF_8) }
                withContext(Dispatchers.IO) {
                    try {
                        java.nio.file.Files.move(
                            tempFile!!.toPath(), targetFile.toPath(),
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                            java.nio.file.StandardCopyOption.ATOMIC_MOVE
                        )
                    } catch (_: java.nio.file.AtomicMoveNotSupportedException) {
                        java.nio.file.Files.move(tempFile!!.toPath(), targetFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING)
                    }
                }
                replaced = true
                withContext(Dispatchers.IO) { ragIndex.upsertDocument(documentId, displayName, clean) }
                val currentThread = threads.firstOrNull { it.id == threadId } ?: error("Belgenin bağlı olduğu sohbet bulunamadı.")
                val updatedDocument = originalDocument.copy(
                    displayName = displayName,
                    bytes = targetFile.length(),
                    characterCount = clean.length,
                    contentHash = LocalRagIndexStore.fingerprint(clean),
                    mimeType = extracted.mimeType,
                    pageCount = extracted.pageCount,
                    sectionCount = extracted.sectionCount,
                    extractionMethod = extracted.extractionMethod,
                    extractionWarnings = extracted.warnings
                )
                updateThread(
                    currentThread.copy(
                        documents = currentThread.documents.map { if (it.id == documentId) updatedDocument else it },
                        updatedAt = System.currentTimeMillis()
                    )
                )
                status = "Yerel belge ve arama indeksi güncellendi • $displayName"
                isImportingContext = false
                rebuildConversationForActiveThread()
            } catch (cancelled: CancellationException) {
                if (replaced && oldContent != null) {
                    withContext(NonCancellable + Dispatchers.IO) {
                        runCatching { targetFile.writeText(oldContent!!, StandardCharsets.UTF_8) }
                        runCatching { ragIndex.upsertDocument(documentId, originalDocument.displayName, oldContent!!) }
                    }
                }
                throw cancelled
            } catch (e: Exception) {
                if (replaced && oldContent != null) {
                    withContext(Dispatchers.IO) {
                        runCatching { targetFile.writeText(oldContent!!, StandardCharsets.UTF_8) }
                        runCatching { ragIndex.upsertDocument(documentId, originalDocument.displayName, oldContent!!) }
                    }
                }
                status = "Yerel belge güncellenemedi"
                errorText = e.message ?: "Belge güncellenirken bilinmeyen bir hata oluştu."
            } finally {
                tempFile?.delete()
                isImportingContext = false
            }
        }
    }

    fun removeContextDocument(documentId: String) {
        if (isWorking || isStopping) return
        val thread = activeThread ?: return
        val document = thread.documents.firstOrNull { it.id == documentId } ?: return
        updateThread(thread.copy(documents = thread.documents.filterNot { it.id == documentId }, updatedAt = System.currentTimeMillis()))
        viewModelScope.launch(Dispatchers.IO) {
            safeContextDocumentFile(document.storedFileName)?.delete()
            ragIndex.removeDocument(document.id)
        }
        rebuildConversationForActiveThread()
    }

    fun exportActiveChat(): String {
        val thread = activeThread ?: return "BREİT BRUT 5 AI sohbeti"
        return buildString {
            append("BREİT BRUT 5 AI\n")
            append("Sohbet: ").append(thread.title).append("\n")
            append("Mod: ").append(thread.mode.label).append("\n")
            if (thread.documents.isNotEmpty()) {
                append("Yerel belgeler: ").append(thread.documents.joinToString { it.displayName }).append("\n")
            }
            append("\n")
            thread.messages.forEach { message ->
                append(if (message.isUser) "Sen" else "BREİT BRUT 5 AI").append(":\n")
                append(message.text).append("\n\n")
            }
        }
    }

    fun selectThread(threadId: String) {
        if (isWorking || threads.none { it.id == threadId }) return
        activeThreadId = threadId
        persistThreads()
        rebuildConversationForActiveThread()
    }

    fun renameThread(threadId: String, rawTitle: String): Boolean {
        if (isWorking || isStopping) return false
        val title = rawTitle.trim().replace(Regex("\\s+"), " ").take(80)
        if (title.isBlank()) {
            errorText = "Sohbet başlığı boş bırakılamaz."
            return false
        }
        val thread = threads.firstOrNull { it.id == threadId } ?: return false
        updateThread(thread.copy(title = title, updatedAt = System.currentTimeMillis()))
        return true
    }

    /** Replaces a user message by moving its edited text to the composer and discarding later turns. */
    fun editUserMessage(messageId: String, editedText: String): Boolean {
        if (isWorking || isStopping) return false
        val clean = editedText.trim()
        if (clean.isBlank()) {
            errorText = "Düzenlenmiş mesaj boş olamaz."
            return false
        }
        val thread = activeThread ?: return false
        val index = thread.messages.indexOfFirst { it.id == messageId && it.isUser }
        if (index < 0) return false
        val promptLimit = if (thread.documents.isNotEmpty()) MAX_USER_PROMPT_CHARS_WITH_DOCUMENTS else MAX_USER_PROMPT_CHARS
        if (clean.length > promptLimit) {
            errorText = "Düzenlenmiş mesaj en fazla $promptLimit karakter olabilir."
            return false
        }
        updateThread(thread.copy(messages = thread.messages.take(index), updatedAt = System.currentTimeMillis()))
        draft = clean
        rebuildConversationForActiveThread()
        status = "Mesaj düzenlendi • sonraki mesajlar kaldırıldı • göndermek için hazır"
        return true
    }

    fun deleteThread(threadId: String) {
        if (isWorking) return
        val removed = threads.firstOrNull { it.id == threadId }
        threads = threads.filterNot { it.id == threadId }
        if (threads.isEmpty()) threads = listOf(ChatThread())
        if (threads.none { it.id == activeThreadId }) activeThreadId = threads.first().id
        if (removed != null) viewModelScope.launch(Dispatchers.IO) { deleteThreadDocumentFiles(removed) }
        persistThreads()
        rebuildConversationForActiveThread()
    }

    fun clearCurrentChat() {
        if (isWorking) return
        val current = activeThread ?: return
        updateThread(current.copy(title = "Yeni sohbet", updatedAt = System.currentTimeMillis(), messages = emptyList()))
        rebuildConversationForActiveThread()
    }

    fun updateMaxOutputTokens(value: Int) {
        maxOutputTokens = value.coerceIn(128, 1024)
        repository.saveMaxOutputTokens(maxOutputTokens)
    }

    fun updateResponseProfile(profile: ResponseProfile) {
        if (isWorking || isStopping || responseProfile == profile) return
        responseProfile = profile
        repository.saveResponseProfile(profile)
        // Selecting a profile applies its suggested starting budget; the slider can lower/raise it later.
        maxOutputTokens = profile.defaultOutputTokens
        repository.saveMaxOutputTokens(maxOutputTokens)
        status = "${profile.label} yanıt profili seçildi"
        if (modelReady && aiBackendMode == AiBackendMode.LOCAL) rebuildConversationForActiveThread()
    }

    fun clearApiUsage() {
        runCatching {
            apiUsageStore.clear()
            apiUsage = apiUsageStore.load()
        }.onFailure { errorText = "API kullanım kayıtları temizlenemedi: ${it.message ?: "depolama hatası"}" }
    }

    fun setAiBackendMode(mode: AiBackendMode) {
        if (isWorking || isStopping || aiBackendMode == mode) return
        aiBackendMode = mode
        apiSettingsStore.saveMode(mode)
        apiConfigMessage = null
        apiTestResult = null
        status = when (mode) {
            AiBackendMode.API -> if (apiKeyConfigured) "API modu seçili • $apiModelName" else "API modu seçili • önce API anahtarını kaydet"
            AiBackendMode.LOCAL -> if (modelReady) "Yerel model hazır • $activeBackendLabel • çevrimdışı" else "Cihazda çalışma seçili • model indir veya içe aktar"
        }
        if (mode == AiBackendMode.LOCAL && !modelReady) {
            val savedName = activeModelName
            if (savedName != null && safeModelFile(savedName)?.isFile == true) loadModel(savedName)
        }
    }

    fun saveApiConnectionSettings(endpoint: String, model: String, keyInput: String): Boolean {
        return try {
            apiSettingsStore.saveConfiguration(endpoint, model, keyInput)
            apiEndpoint = apiSettingsStore.loadEndpoint()
            apiModelName = apiSettingsStore.loadModel()
            apiKeyConfigured = apiSettingsStore.hasApiKey()
            apiConfigMessage = "API ayarları kaydedildi. Anahtar, Android Keystore ile şifrelenmiş olarak saklanıyor."
            apiTestResult = null
            errorText = null
            if (aiBackendMode == AiBackendMode.API) status = if (apiKeyConfigured) "API hazır • $apiModelName" else "API anahtarı gerekli"
            true
        } catch (e: Exception) {
            apiConfigMessage = e.message ?: "API ayarları kaydedilemedi."
            false
        }
    }

    fun clearApiKey() {
        if (isWorking || isStopping) return
        runCatching { apiSettingsStore.clearApiKey() }
            .onSuccess {
                apiKeyConfigured = false
                apiTestResult = null
                apiConfigMessage = "Kayıtlı API anahtarı kaldırıldı."
                if (aiBackendMode == AiBackendMode.API) {
                    aiBackendMode = AiBackendMode.LOCAL
                    apiSettingsStore.saveMode(AiBackendMode.LOCAL)
                    status = if (modelReady) "Yerel model hazır • çevrimdışı" else "Cihazda çalışma seçili • model gerekli"
                }
            }
            .onFailure { apiConfigMessage = "API anahtarı kaldırılamadı: ${it.message ?: "depolama hatası"}" }
    }

    fun testApiConnection() {
        if (isWorking || isStopping) return
        if (!apiKeyConfigured) {
            apiTestResult = "Önce API anahtarını kaydet."
            return
        }
        isTestingApi = true
        apiTestResult = "Bağlantı sınanıyor…"
        apiConfigMessage = null
        viewModelScope.launch {
            try {
                val messages = JSONArray()
                    .put(JSONObject().put("role", "system").put("content", "Yanıtı tam olarak TEST_OK yap."))
                    .put(JSONObject().put("role", "user").put("content", "Bağlantı testi"))
                val result = withTimeout(API_TEST_TIMEOUT_MS) { performApiRequest(messages, 16) }
                apiTestResult = if (result.contains("TEST_OK", ignoreCase = true)) {
                    "Bağlantı başarılı • model yanıt üretti."
                } else {
                    "Sunucu yanıt verdi; test metni beklenenden farklı: ${result.take(120)}"
                }
                status = "API bağlantısı test edildi • $apiModelName"
            } catch (e: TimeoutCancellationException) {
                apiConnection?.disconnect()
                apiTestResult = "Zaman aşımı: API 75 saniye içinde yanıt vermedi. Uç noktayı, ağı ve model adını kontrol et."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                apiTestResult = friendlyApiError(e)
            } finally {
                apiConnection?.disconnect()
                apiConnection = null
                isTestingApi = false
            }
        }
    }

    private fun friendlyApiError(error: Throwable): String {
        val diagnostic = AiFailureDiagnostics.classify(error)
        return "${diagnostic.userMessage} (P0: ${diagnostic.code})"
    }

    fun dismissError() { errorText = null }

    /** User-controlled deletion for local model performance metrics. */
    fun clearPerformanceHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { performanceTelemetry.clear() }
                .onSuccess { withContext(Dispatchers.Main.immediate) { performanceSamples = emptyList(); status = "Performans ölçümleri temizlendi" } }
                .onFailure { withContext(Dispatchers.Main.immediate) { errorText = "Performans kayıtları temizlenemedi: ${it.message ?: "dosya hatası"}" } }
        }
    }

    fun importModel(uri: Uri) {
        if (isWorking) return
        viewModelScope.launch {
            isModelLoading = true
            errorText = null
            status = "Model dosyası içe aktarılıyor…"
            var partialImport: File? = null
            var importedTarget: File? = null
            try {
                val displayName = withContext(Dispatchers.IO) { queryDisplayName(uri) }
                if (!displayName.endsWith(".litertlm", ignoreCase = true)) {
                    error("Dosya adı .litertlm ile bitmeli. Bu aşamada yalnızca LiteRT-LM model dosyaları destekleniyor.")
                }
                val baseName = sanitizeModelName(displayName)
                val target = uniqueFile(baseName)
                importedTarget = target
                val part = File(modelDirectory, "${target.name}.importing")
                partialImport = part
                val expectedBytes = withContext(Dispatchers.IO) { queryDocumentSize(uri) }
                val importSpaceProfile = withContext(Dispatchers.IO) { DeviceProfile.read(getApplication()) }
                ModelImportPolicy.preflightIssue(expectedBytes, importSpaceProfile.freeStorageBytes)?.let { issue ->
                    error(ModelImportPolicy.message(issue, expectedBytes, 0L, importSpaceProfile.freeStorageBytes))
                }
                var copiedBytes = 0L
                withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri).use { input ->
                        requireNotNull(input) { "Seçilen dosya okunamadı." }.use { source ->
                            BufferedInputStream(source).use { bufferedInput ->
                                FileOutputStream(part).use { fileOutput ->
                                    BufferedOutputStream(fileOutput).use { output ->
                                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                                        while (true) {
                                            coroutineContext.ensureActive()
                                            val count = bufferedInput.read(buffer)
                                            if (count < 0) break
                                            copiedBytes += count.toLong()
                                            ModelImportPolicy.progressIssue(copiedBytes, expectedBytes, importSpaceProfile.freeStorageBytes)?.let { issue ->
                                                error(ModelImportPolicy.message(issue, expectedBytes, copiedBytes, importSpaceProfile.freeStorageBytes))
                                            }
                                            output.write(buffer, 0, count)
                                        }
                                        output.flush()
                                        fileOutput.fd.sync()
                                    }
                                }
                            }
                        }
                    }
                }
                ModelImportPolicy.completionIssue(copiedBytes, expectedBytes)?.let { issue ->
                    error(ModelImportPolicy.message(issue, expectedBytes, copiedBytes, importSpaceProfile.freeStorageBytes))
                }
                if (part.length() < MIN_MODEL_BYTES) {
                    part.delete()
                    error("Dosya çok küçük. Seçtiğin dosya bozuk veya gerçek bir .litertlm modeli olmayabilir.")
                }
                withContext(Dispatchers.IO) {
                    VerifiedModelFileInstaller.promoteImported(
                        partialFile = part,
                        targetFile = target,
                        minimumBytes = MIN_MODEL_BYTES,
                        beforePromote = { coroutineContext.ensureActive() }
                    )
                }
                partialImport = null
                refreshModels()
                isModelLoading = false
                loadModel(target.name)
            } catch (cancelled: CancellationException) {
                partialImport?.delete()
                importedTarget?.let { target ->
                    withContext(NonCancellable + Dispatchers.IO) {
                        target.delete()
                        ModelArtifactIntegrity.deleteManifest(target)
                    }
                }
                withContext(NonCancellable + Dispatchers.Main.immediate) {
                    isModelLoading = false
                    status = "Model içe aktarma durduruldu"
                }
                throw cancelled
            } catch (e: Exception) {
                partialImport?.delete()
                importedTarget?.let { target ->
                    withContext(Dispatchers.IO) {
                        target.delete()
                        ModelArtifactIntegrity.deleteManifest(target)
                    }
                }
                status = "Model içe aktarılamadı"
                errorText = e.message ?: "Bilinmeyen dosya hatası"
                isModelLoading = false
            }
        }
    }

    fun downloadRecommendedModel() = downloadModel(ModelCatalog.items.first { it.fileName == RECOMMENDED_MODEL_NAME })

    fun downloadModel(selected: ModelCatalogItem) {
        if (isWorking || isStopping) return
        val trustedSpec = ModelCatalog.items.firstOrNull { it.id == selected.id }
        if (trustedSpec == null || trustedSpec != selected || !trustedSpec.expectedSha256.matches(Regex("[0-9a-fA-F]{64}")) ||
            !trustedSpec.downloadUrl.startsWith("https://", ignoreCase = true)) {
            errorText = "Bu model katalogdaki güvenilir tanımla eşleşmiyor. Güvenli indirme başlatılmadı."
            return
        }
        // Always use the in-app pinned catalog object after validating the supplied selection.
        val spec = trustedSpec
        val targetName = spec.fileName
        val existing = File(modelDirectory, targetName)
        val existingBytes = if (existing.isFile) existing.length() else 0L
        val requiredSpace = ModelStoragePolicy.requiredFreeBytes(spec.approxBytes + existingBytes)
        val profile = deviceProfile
        // Existing data is not discarded: it is checked first and otherwise kept until the new
        // download has completed and its publisher-pinned digest has passed. Reserve both copies.
        if (!ModelStoragePolicy.hasEnoughSpace(profile.freeStorageBytes, spec.approxBytes + existingBytes)) {
            errorText = "${spec.title} için eski model korunurken yaklaşık ${formatBytes(requiredSpace)} boş alan gerekiyor. Şu an ${formatBytes(profile.freeStorageBytes)} boş görünüyor."
            return
        }
        downloadCancellationRequested = false
        isDownloading = true
        downloadingModelName = targetName
        downloadProgress = 0f
        downloadLabel = "Model ve SHA-256 kontrol ediliyor…"
        errorText = null
        status = "${spec.title} hazırlanıyor…"
        downloadJob = viewModelScope.launch(Dispatchers.IO) {
            val partial = File(modelDirectory, "$targetName.part")
            var connection: HttpURLConnection? = null
            try {
                if (existing.isFile && existing.length() >= MIN_MODEL_BYTES) {
                    val existingValid = runCatching {
                        ModelArtifactIntegrity.verifyOrCreate(existing, spec.expectedSha256)
                    }.isSuccess
                    if (existingValid) {
                        withContext(Dispatchers.Main.immediate) {
                            isDownloading = false
                            downloadingModelName = null
                            downloadProgress = 1f
                            downloadLabel = "Mevcut model doğrulandı"
                            invalidCatalogModelNames = invalidCatalogModelNames - targetName
                            refreshModels()
                            loadModel(targetName)
                        }
                        return@launch
                    }
                    withContext(Dispatchers.Main.immediate) {
                        invalidCatalogModelNames = invalidCatalogModelNames + targetName
                        refreshModels()
                        downloadLabel = "Mevcut model doğrulanamadı • güvenilir kopya indiriliyor"
                    }
                }

                partial.delete()
                connection = (URL(spec.downloadUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 30_000
                    readTimeout = 60_000
                    instanceFollowRedirects = true
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "BREIT-BRUT-5-AI-Android/0.5")
                }
                downloadConnection = connection
                connection.connect()
                if (!connection.url.protocol.equals("https", ignoreCase = true)) {
                    error("Model sunucusu HTTPS bağlantısını korumadı. Güvenli indirme durduruldu.")
                }
                val code = connection.responseCode
                if (code !in 200..299) error("Model sunucusu HTTP $code döndürdü.")
                val total = connection.contentLengthLong
                var downloaded = 0L
                var lastUiUpdate = 0L
                FileOutputStream(partial).use { fileOutput ->
                    BufferedInputStream(connection.inputStream).use { input ->
                        BufferedOutputStream(fileOutput).use { output ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                coroutineContext.ensureActive()
                                val read = input.read(buffer)
                                if (read < 0) break
                                output.write(buffer, 0, read)
                                downloaded += read
                                val now = System.nanoTime()
                                if (now - lastUiUpdate > TimeUnit.MILLISECONDS.toNanos(250)) {
                                    lastUiUpdate = now
                                    withContext(Dispatchers.Main.immediate) {
                                        if (total > 0L) downloadProgress = (downloaded.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f)
                                        downloadLabel = if (total > 0L) {
                                            "${formatBytes(downloaded)} / ${formatBytes(total)} (${(downloaded * 100 / total).coerceIn(0, 100)}%)"
                                        } else "${formatBytes(downloaded)} indirildi"
                                    }
                                }
                            }
                            output.flush()
                            fileOutput.fd.sync()
                        }
                    }
                }
                if (partial.length() < spec.approxBytes * 8 / 10) {
                    error("İndirilen dosya beklenenden küçük. Dosya yarım veya model bağlantısı hatalı olabilir.")
                }
                if (total > 0L && downloaded != total) {
                    error("İndirme tamamlanmadan bağlantı kapandı (${formatBytes(downloaded)} / ${formatBytes(total)}). Tekrar dene.")
                }
                withContext(Dispatchers.Main.immediate) { downloadLabel = "Yayımlanmış SHA-256 doğrulanıyor…" }
                val finalFile = File(modelDirectory, targetName)
                VerifiedModelFileInstaller.promoteVerified(
                    partialFile = partial,
                    targetFile = finalFile,
                    expectedSha256 = spec.expectedSha256,
                    minimumBytes = (spec.approxBytes * 8 / 10),
                    beforePromote = { coroutineContext.ensureActive() }
                )
                withContext(Dispatchers.Main.immediate) {
                    isDownloading = false
                    downloadingModelName = null
                    downloadProgress = 1f
                    downloadLabel = "İndirme ve bütünlük kontrolü tamamlandı"
                    invalidCatalogModelNames = invalidCatalogModelNames - targetName
                    refreshModels()
                    loadModel(targetName)
                }
            } catch (cancelled: CancellationException) {
                partial.delete()
                withContext(NonCancellable + Dispatchers.Main.immediate) {
                    isDownloading = false
                    downloadingModelName = null
                    downloadLabel = "İndirme iptal edildi • mevcut model korundu"
                    status = "Model indirmesi iptal edildi"
                }
                throw cancelled
            } catch (e: Exception) {
                partial.delete()
                if (downloadCancellationRequested) {
                    // HttpURLConnection.disconnect() can surface IOException before Job cancellation
                    // is observed. Treat that race as a user cancellation, not a network failure.
                    withContext(NonCancellable + Dispatchers.Main.immediate) {
                        isDownloading = false
                        downloadingModelName = null
                        downloadLabel = "İndirme iptal edildi • mevcut model korundu"
                        status = "Model indirmesi iptal edildi"
                        errorText = null
                    }
                } else {
                    val diagnostic = AiFailureDiagnostics.classify(e)
                    withContext(Dispatchers.Main.immediate) {
                        isDownloading = false
                        downloadingModelName = null
                        status = "Model indirilemedi • mevcut model korundu"
                        errorText = "${diagnostic.userMessage} (P0: ${diagnostic.code})"
                    }
                }
            } finally {
                connection?.disconnect()
                if (downloadConnection === connection) downloadConnection = null
                downloadCancellationRequested = false
            }
        }
    }

    /** Downloads the official text-only EmbeddingGemma 2 artifact to a separate directory. */
    fun downloadEmbeddingModel() {
        if (isWorking || isStopping) return
        if (embeddingModelFile.isFile && embeddingModelFile.length() >= LocalEmbeddingModelCatalog.MIN_VALID_BYTES && embeddingModelInstalled) {
            loadEmbeddingSearch()
            return
        }
        val existingEmbeddingBytes = if (embeddingModelFile.isFile) embeddingModelFile.length() else 0L
        val requiredSpace = LocalEmbeddingModelCatalog.APPROX_BYTES + existingEmbeddingBytes + 180L * 1_048_576L
        if (deviceProfile.freeStorageBytes < requiredSpace) {
            errorText = "EmbeddingGemma 2 indirilirken mevcut dosya da korunacağı için yaklaşık ${formatBytes(requiredSpace)} boş alan gerekiyor. Şu an ${formatBytes(deviceProfile.freeStorageBytes)} boş görünüyor."
            return
        }
        downloadCancellationRequested = false
        isDownloading = true
        downloadingModelName = LocalEmbeddingModelCatalog.FILE_NAME
        downloadProgress = 0f
        downloadLabel = "EmbeddingGemma 2 bağlantısı kuruluyor…"
        errorText = null
        status = "Yerel anlamsal arama modeli indiriliyor…"
        downloadJob = viewModelScope.launch(Dispatchers.IO) {
            val partial = File(embeddingModelDirectory, "${LocalEmbeddingModelCatalog.FILE_NAME}.part")
            var connection: HttpURLConnection? = null
            try {
                partial.delete()
                connection = (URL(LocalEmbeddingModelCatalog.DOWNLOAD_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 30_000
                    readTimeout = 60_000
                    instanceFollowRedirects = true
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "BREIT-BRUT-5-AI-Android/0.5")
                }
                downloadConnection = connection
                connection.connect()
                if (!connection.url.protocol.equals("https", ignoreCase = true)) {
                    error("Embedding model sunucusu HTTPS bağlantısını korumadı. Güvenli indirme durduruldu.")
                }
                val code = connection.responseCode
                if (code !in 200..299) error("Embedding model sunucusu HTTP $code döndürdü.")
                val total = connection.contentLengthLong
                var downloaded = 0L
                var lastUiUpdate = 0L
                FileOutputStream(partial).use { fileOutput ->
                    BufferedInputStream(connection.inputStream).use { input ->
                        BufferedOutputStream(fileOutput).use { output ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                coroutineContext.ensureActive()
                                val read = input.read(buffer)
                                if (read < 0) break
                                output.write(buffer, 0, read)
                                downloaded += read
                                val now = System.nanoTime()
                                if (now - lastUiUpdate > TimeUnit.MILLISECONDS.toNanos(250)) {
                                    lastUiUpdate = now
                                    withContext(Dispatchers.Main.immediate) {
                                        if (total > 0L) downloadProgress = (downloaded.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f)
                                        downloadLabel = if (total > 0L) {
                                            "${formatBytes(downloaded)} / ${formatBytes(total)} (${(downloaded * 100 / total).coerceIn(0, 100)}%)"
                                        } else "${formatBytes(downloaded)} indirildi"
                                    }
                                }
                            }
                            output.flush()
                            fileOutput.fd.sync()
                        }
                    }
                }
                if (partial.length() < LocalEmbeddingModelCatalog.MIN_VALID_BYTES) {
                    error("Embedding modeli beklenenden küçük. İndirme eksik veya model bağlantısı hatalı olabilir.")
                }
                if (total > 0L && downloaded != total) {
                    error("Embedding modeli eksik indi (${formatBytes(downloaded)} / ${formatBytes(total)}). Tekrar dene.")
                }
                val target = embeddingModelFile
                VerifiedModelFileInstaller.promoteVerified(
                    partialFile = partial,
                    targetFile = target,
                    expectedSha256 = LocalEmbeddingModelCatalog.SHA256,
                    minimumBytes = LocalEmbeddingModelCatalog.MIN_VALID_BYTES,
                    beforePromote = { coroutineContext.ensureActive() }
                )
                LocalEmbeddingModelCatalog.writeVerifiedMarker(target)
                withContext(Dispatchers.Main.immediate) {
                    isDownloading = false
                    downloadingModelName = null
                    downloadProgress = 1f
                    downloadLabel = "EmbeddingGemma 2 indirildi"
                    embeddingModelInstalled = true
                    loadEmbeddingSearch()
                }
            } catch (cancelled: CancellationException) {
                partial.delete()
                withContext(NonCancellable + Dispatchers.Main.immediate) {
                    isDownloading = false
                    downloadingModelName = null
                    downloadLabel = "Anlamsal arama indirmesi iptal edildi • mevcut model korundu"
                    status = "Anlamsal arama modeli indirmesi durduruldu"
                    errorText = null
                }
                throw cancelled
            } catch (e: Exception) {
                partial.delete()
                withContext(NonCancellable + Dispatchers.Main.immediate) {
                    isDownloading = false
                    downloadingModelName = null
                    embeddingModelInstalled = withContext(Dispatchers.IO) { LocalEmbeddingModelCatalog.verifyModelFile(embeddingModelFile) }
                    status = "Embedding modeli indirilemedi • BM25 + TF-IDF çalışmaya devam ediyor"
                    errorText = if (downloadCancellationRequested) null else (e.message ?: "Embedding modeli indirme hatası")
                }
            } finally {
                connection?.disconnect()
                if (downloadConnection === connection) downloadConnection = null
                downloadCancellationRequested = false
            }
        }
    }

    /** Enables the optional semantic reranker. Lexical retrieval remains the guaranteed fallback. */
    fun loadEmbeddingSearch(autoLoad: Boolean = false) {
        if ((isWorking && !autoLoad) || isStopping) return
        if (!embeddingModelFile.isFile || embeddingModelFile.length() < LocalEmbeddingModelCatalog.MIN_VALID_BYTES) {
            embeddingModelInstalled = false
            embeddingStatus = "Embedding modeli kurulu değil • BM25 + TF-IDF hazır"
            errorText = "Anlamsal arama için önce EmbeddingGemma 2 modelini indir. İndirme başarısız olursa temel yerel arama çalışmaya devam eder."
            return
        }
        val profile = deviceProfile
        if (profile.totalRamBytes < 1_500_000_000L) {
            errorText = "Bu cihazın toplam RAM'i 1,5 GB altında görünüyor. EmbeddingGemma 2'nin resmî önerisi 2 GB+; bellek yetersizliğinde kapalı tutup BM25 + TF-IDF kullanabilirsin."
            return
        }
        isEmbeddingLoading = true
        embeddingModelInstalled = true
        embeddingStatus = if (autoLoad) "Kayıtlı embedding modeli yükleniyor…" else "Embedding modeli hazırlanıyor…"
        status = "Yerel anlamsal arama hazırlanıyor…"
        errorText = null
        viewModelScope.launch {
            try {
                val rebuilt = withContext(Dispatchers.IO) {
                    embeddingEngine.initialize()
                    // Repair legacy/missing lexical indexes before attaching the embedder, avoiding duplicate work.
                    threads.flatMap { it.documents }.forEach { document ->
                        if (!ragIndex.hasIndex(document.id)) {
                            val file = safeContextDocumentFile(document.storedFileName)
                            if (file != null && file.isFile) {
                                runCatching { ragIndex.upsertDocument(document.id, document.displayName, file.readText(StandardCharsets.UTF_8)) }
                            }
                        }
                    }
                    ragIndex.setVectorEmbedder(embeddingEngine)
                    ragIndex.rebuildAllEmbeddings()
                }
                embeddingModelReady = true
                embeddingEnabled = true
                repository.saveEmbeddingEnabled(true)
                embeddingStatus = "Anlamsal arama aktif • BM25 + TF-IDF + EmbeddingGemma 2 • $rebuilt belge vektör indeksi hazırlandı"
                status = if (modelReady) "Yerel model hazır • anlamsal belge araması etkin" else "Anlamsal belge araması hazır • sohbet modeli ayrıca yüklenmeli"
            } catch (cancelled: CancellationException) {
                ragIndex.setVectorEmbedder(null)
                embeddingEnabled = false
                repository.saveEmbeddingEnabled(false)
                throw cancelled
            } catch (e: OutOfMemoryError) {
                recoverEmbeddingFailure(e)
            } catch (e: LinkageError) {
                recoverEmbeddingFailure(e)
            } catch (e: Exception) {
                recoverEmbeddingFailure(e)
            } finally {
                isEmbeddingLoading = false
            }
        }
    }

    private suspend fun recoverEmbeddingFailure(error: Throwable) {
        ragIndex.setVectorEmbedder(null)
        embeddingEnabled = false
        repository.saveEmbeddingEnabled(false)
        embeddingModelReady = false
        embeddingModelInstalled = withContext(Dispatchers.IO) {
            LocalEmbeddingModelCatalog.verifyModelFile(embeddingModelFile)
        }
        embeddingStatus = "Embedding yüklenemedi • BM25 + TF-IDF yedeği aktif"
        status = "Temel yerel arama hazır"
        val diagnostic = AiFailureDiagnostics.classify(error)
        errorText = "${diagnostic.userMessage} (P0: ${diagnostic.code}). Embedding devre dışı bırakıldı; metinsel belge araması çalışmaya devam ediyor."
        withContext(Dispatchers.IO) { runCatching { embeddingEngine.closeModel() } }
    }

    fun disableEmbeddingSearch() {
        if (isWorking || isStopping) return
        embeddingEnabled = false
        repository.saveEmbeddingEnabled(false)
        ragIndex.setVectorEmbedder(null)
        isEmbeddingLoading = true
        embeddingStatus = "Anlamsal arama kapatılıyor…"
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { embeddingEngine.closeModel() }
                embeddingModelReady = false
                embeddingStatus = "Anlamsal arama kapalı • BM25 + TF-IDF hazır"
                status = if (modelReady) "Yerel model hazır • metinsel belge araması etkin" else "Anlamsal arama kapalı"
            } catch (e: Exception) {
                embeddingStatus = "Anlamsal arama kapalı • motor kapatılırken uyarı"
                errorText = e.message ?: "Embedding motoru kapatılırken hata oluştu."
            } finally {
                isEmbeddingLoading = false
            }
        }
    }

    fun removeEmbeddingModel() {
        if (isWorking || isStopping) return
        embeddingEnabled = false
        repository.saveEmbeddingEnabled(false)
        ragIndex.setVectorEmbedder(null)
        isEmbeddingLoading = true
        embeddingStatus = "Embedding modeli kaldırılıyor…"
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    embeddingEngine.closeModel()
                    ragIndex.clearAllEmbeddings()
                    if (embeddingModelFile.exists() && !embeddingModelFile.delete()) error("Embedding modeli dosyası silinemedi.")
                    File(embeddingModelDirectory, embeddingModelFile.name + ".verified").delete()
                    ModelArtifactIntegrity.deleteManifest(embeddingModelFile)
                }
                embeddingModelReady = false
                embeddingModelInstalled = false
                embeddingStatus = "Embedding modeli kaldırıldı • BM25 + TF-IDF hazır"
            } catch (e: Exception) {
                errorText = "Embedding modeli kaldırılamadı: ${e.message ?: "dosya hatası"}"
            } finally {
                isEmbeddingLoading = false
            }
        }
    }

    fun cancelDownload() {
        if (!isDownloading) return
        // Mark intent before disconnect: disconnect may surface as IOException before coroutine cancellation.
        downloadCancellationRequested = true
        downloadConnection?.disconnect()
        downloadJob?.cancel(CancellationException("User cancelled model download"))
        downloadJob = null
    }

    fun loadModel(name: String, autoLoad: Boolean = false) {
        if (isWorking || isStopping) return
        val file = safeModelFile(name)
        if (file == null || !file.isFile || file.length() < MIN_MODEL_BYTES) {
            errorText = "Model dosyası bulunamadı veya boyutu beklenenden küçük. Yeniden içe aktar."
            refreshModels()
            return
        }
        val modelLoadStartNanos = System.nanoTime()
        val ramBeforeLoad = deviceProfile.availableRamBytes
        val isFirstModelLoadThisProcess = !modelLoadedThisProcess
        isModelLoading = true
        modelReady = false
        activeBackendLabel = "—"
        status = if (autoLoad) "Kayıtlı model yeniden yükleniyor…" else "${name} hazırlanıyor…"
        errorText = null
        activeModelName = name
        repository.saveActiveModelName(name)
        refreshModels()
        viewModelScope.launch {
            try {
                status = "Model dosyasının bütünlüğü kontrol ediliyor…"
                withContext(Dispatchers.IO) { ModelArtifactIntegrity.verifyOrCreate(file, ModelCatalog.byFileName(file.name)?.expectedSha256) }
                val setup = withContext(aiDispatcher) {
                    initializeEngineForModel(file, activeThread?.messages.orEmpty())
                }
                activeBackendLabel = setup.first
                modelReady = true
                invalidCatalogModelNames = invalidCatalogModelNames - name
                modelLoadedThisProcess = true
                recordPerformanceSample(InferenceSample(
                    modelName = name,
                    backendLabel = setup.first,
                    durationMs = ((System.nanoTime() - modelLoadStartNanos) / 1_000_000L).coerceAtLeast(1L),
                    outputCharacters = 0,
                    completedAt = System.currentTimeMillis(),
                    eventType = InferenceSample.EVENT_MODEL_LOAD,
                    outcome = InferenceSample.OUTCOME_SUCCESS,
                    availableRamBeforeBytes = ramBeforeLoad,
                    availableRamAfterBytes = deviceProfile.availableRamBytes,
                    firstModelLoadThisProcess = isFirstModelLoadThisProcess
                ))
                status = if (setup.second != null) {
                    "Yerel model hazır • ${setup.first}"
                } else {
                    "Yerel model hazır • ${setup.first} • çevrimdışı"
                }
                if (setup.second != null) {
                    errorText = setup.second
                }
                refreshModels()
                if (!autoLoad) appendAssistant("Model yüklendi. Sohbetin cihazında çalışıyor; mesajların bir bulut API'sine gönderilmiyor.")
            } catch (cancelled: CancellationException) {
                recordPerformanceSample(InferenceSample(
                    modelName = name, backendLabel = activeBackendLabel, durationMs = ((System.nanoTime() - modelLoadStartNanos) / 1_000_000L).coerceAtLeast(1L),
                    outputCharacters = 0, completedAt = System.currentTimeMillis(), eventType = InferenceSample.EVENT_MODEL_LOAD,
                    outcome = InferenceSample.OUTCOME_CANCELLED, availableRamBeforeBytes = ramBeforeLoad,
                    availableRamAfterBytes = deviceProfile.availableRamBytes, firstModelLoadThisProcess = isFirstModelLoadThisProcess,
                    errorCategory = "cancelled"
                ))
                throw cancelled
            } catch (e: OutOfMemoryError) {
                recordPerformanceSample(InferenceSample(
                    modelName = name, backendLabel = activeBackendLabel, durationMs = ((System.nanoTime() - modelLoadStartNanos) / 1_000_000L).coerceAtLeast(1L),
                    outputCharacters = 0, completedAt = System.currentTimeMillis(), eventType = InferenceSample.EVENT_MODEL_LOAD,
                    outcome = InferenceSample.OUTCOME_FAILURE, availableRamBeforeBytes = ramBeforeLoad,
                    availableRamAfterBytes = deviceProfile.availableRamBytes, firstModelLoadThisProcess = isFirstModelLoadThisProcess,
                    errorCategory = "memory_pressure"
                ))
                modelReady = false
                status = "Model yüklenemedi • bellek yetersiz"
                errorText = "Cihaz belleği modeli yüklemek için yetersiz kaldı (P0: memory_pressure). Daha küçük bir model seç."
            } catch (e: LinkageError) {
                recordPerformanceSample(InferenceSample(
                    modelName = name, backendLabel = activeBackendLabel, durationMs = ((System.nanoTime() - modelLoadStartNanos) / 1_000_000L).coerceAtLeast(1L),
                    outputCharacters = 0, completedAt = System.currentTimeMillis(), eventType = InferenceSample.EVENT_MODEL_LOAD,
                    outcome = InferenceSample.OUTCOME_FAILURE, availableRamBeforeBytes = ramBeforeLoad,
                    availableRamAfterBytes = deviceProfile.availableRamBytes, firstModelLoadThisProcess = isFirstModelLoadThisProcess,
                    errorCategory = "runtime_incompatible"
                ))
                modelReady = false
                status = "Model çalışma zamanı uyumsuzluğu"
                val diagnostic = AiFailureDiagnostics.classify(e)
                errorText = "${diagnostic.userMessage} (P0: ${diagnostic.code})\n\nTeknik ayrıntı: ${e.javaClass.simpleName}."
            } catch (e: Exception) {
                recordPerformanceSample(InferenceSample(
                    modelName = name, backendLabel = activeBackendLabel, durationMs = ((System.nanoTime() - modelLoadStartNanos) / 1_000_000L).coerceAtLeast(1L),
                    outputCharacters = 0, completedAt = System.currentTimeMillis(), eventType = InferenceSample.EVENT_MODEL_LOAD,
                    outcome = InferenceSample.OUTCOME_FAILURE, availableRamBeforeBytes = ramBeforeLoad,
                    availableRamAfterBytes = deviceProfile.availableRamBytes, firstModelLoadThisProcess = isFirstModelLoadThisProcess,
                    errorCategory = classifyRuntimeError(e)
                ))
                modelReady = false
                status = "Model yüklenemedi"
                val diagnostic = AiFailureDiagnostics.classify(e)
                if (diagnostic.code == "model_integrity" && ModelCatalog.byFileName(file.name) != null) {
                    invalidCatalogModelNames = invalidCatalogModelNames + file.name
                    if (activeModelName == file.name) {
                        activeModelName = null
                        repository.saveActiveModelName(null)
                    }
                    refreshModels()
                }
                errorText = "${diagnostic.userMessage} (P0: ${diagnostic.code})\n\nTeknik ayrıntı: ${e.javaClass.simpleName}. Daha küçük bir model veya CPU arka ucunu deneyebilirsin."
            } finally {
                isModelLoading = false
                if (embeddingAutoLoadPending) {
                    embeddingAutoLoadPending = false
                    loadEmbeddingSearch(autoLoad = true)
                }
            }
        }
    }

    private fun initializeEngineForModel(file: File, history: List<ChatMessage>): Pair<String, String?> {
        closeConversationAndEngine()
        val modelRecommendation = ModelCatalog.byFileName(file.name)?.recommendedBackend ?: BackendPreference.CPU
        val attempts: List<Pair<Backend, String>> = when (backendPreference) {
            BackendPreference.CPU -> listOf(Backend.CPU() to "CPU")
            BackendPreference.GPU -> listOf(Backend.GPU() to "GPU", Backend.CPU() to "CPU")
            BackendPreference.AUTO -> when (modelRecommendation) {
                BackendPreference.GPU -> listOf(Backend.GPU() to "GPU", Backend.CPU() to "CPU")
                BackendPreference.CPU, BackendPreference.AUTO -> listOf(Backend.CPU() to "CPU", Backend.GPU() to "GPU")
            }
        }
        var gpuFailure: Exception? = null
        var lastFailure: Exception? = null
        for ((backend, backendLabel) in attempts) {
            var candidate: Engine? = null
            try {
                candidate = Engine(
                    EngineConfig(
                        modelPath = file.absolutePath,
                        backend = backend,
                        cacheDir = getApplication<Application>().cacheDir.absolutePath
                    )
                )
                candidate.initialize()
                val candidateConversation = candidate.createConversation(conversationConfig(history))
                engine = candidate
                conversation = candidateConversation
                val fellBack = backendLabel == "CPU" && gpuFailure != null
                val message = if (fellBack) {
                    "GPU başlatılamadı; model CPU üzerinde açıldı. GPU uyumluluğu model ve cihaz sürücüsüne bağlıdır. Ayrıntı: ${gpuFailure?.message ?: "GPU başlatma hatası"}"
                } else null
                return (if (fellBack) "CPU (GPU yedeği)" else backendLabel) to message
            } catch (e: Exception) {
                runCatching { candidate?.close() }
                lastFailure = e
                if (backendLabel == "GPU" && attempts.size > 1) {
                    gpuFailure = e
                    continue
                }
                throw IllegalStateException("${backendLabel} arka ucunda model başlatılamadı: ${e.message ?: "Bilinmeyen hata"}", e)
            }
        }
        throw IllegalStateException("GPU ve CPU ile model başlatılamadı: ${lastFailure?.message ?: "Bilinmeyen hata"}", lastFailure)
    }

    fun updateBackendPreference(preference: BackendPreference) {
        if (isWorking || isStopping || backendPreference == preference) return
        backendPreference = preference
        repository.saveBackendPreference(preference)
        val modelName = activeModelName
        if (modelName == null) {
            status = "${preference.label} tercihi kaydedildi • model seçilmedi"
        } else {
            loadModel(modelName)
        }
    }

    /** Requests cancellation in the native inference session. We deliberately do not cancel the
     * Kotlin collector first; it must receive the native terminal callback before its state can
     * safely be rebuilt. */
    fun stopGeneration() {
        if (!busy || isStopping) return
        if (aiBackendMode == AiBackendMode.API) {
            isStopping = true
            status = "API isteği durduruluyor…"
            apiConnection?.disconnect()
            responseJob?.cancel(CancellationException("User stopped API request"))
            return
        }
        if (isPreparingTurn) {
            // During retrieval there is no active native generation to cancel yet. Cancel the
            // coroutine so it cannot create a fresh conversation and start after the stop tap.
            isStopping = true
            stopTimedOut = false
            errorText = null
            status = "Yerel kaynak hazırlığı durduruluyor…"
            responseJob?.cancel(CancellationException("User stopped during local retrieval"))
            return
        }
        val activeConversation = conversation
        if (activeConversation == null) {
            errorText = "Durdurulacak etkin sohbet oturumu bulunamadı."
            return
        }
        isStopping = true
        stopTimedOut = false
        errorText = null
        status = "Yerel yanıt durduruluyor…"
        stopWatchdogJob?.cancel()
        stopWatchdogJob = viewModelScope.launch {
            delay(12_000)
            if (isStopping && busy) {
                stopTimedOut = true
                status = "İptal onayı bekleniyor"
                errorText = "Yerel motor 12 saniye içinde iptal yanıtı vermedi. Motorla aynı anda işlem yapmamak için yeni yanıtlar kilitli tutuluyor. İptal geç tamamlanırsa sohbet otomatik toparlanacak; uygulama yanıt vermemeye devam ederse uygulamayı yeniden başlatıp modeli tekrar yükle."
            }
        }
        viewModelScope.launch {
            try {
                withContext(aiDispatcher) { activeConversation.cancelProcess() }
            } catch (e: Exception) {
                if (isStopping) {
                    isStopping = false
                    stopWatchdogJob?.cancel()
                    status = "Durdurma isteği gönderilemedi"
                    errorText = "Yerel motor iptal isteğini kabul etmedi: ${e.message ?: "Bilinmeyen hata"}. Üretim sürüyor olabilir; durum netleşmeden yeni model yükleme başlatılmadı."
                }
            }
        }
    }

    fun removeModel(name: String) {
        if (isWorking) return
        val safeFile = safeModelFile(name) ?: run {
            errorText = "Model dosyası adı geçersiz."
            return
        }
        viewModelScope.launch {
            try {
                if (name == activeModelName) {
                    withContext(aiDispatcher) { closeConversationAndEngine() }
                    modelReady = false
                    activeModelName = null
                    repository.saveActiveModelName(null)
                    status = "Yerel model kaldırıldı"
                }
                withContext(Dispatchers.IO) {
                    safeFile.delete()
                    ModelArtifactIntegrity.deleteManifest(safeFile)
                }
                invalidCatalogModelNames = invalidCatalogModelNames - name
                refreshModels()
            } catch (e: Exception) {
                errorText = "Model kaldırılamadı: ${e.message}"
            }
        }
    }

    fun send() {
        val prompt = draft.trim()
        if (prompt.isEmpty() || isWorking) return
        val promptLimit = if (activeDocuments.isNotEmpty()) MAX_USER_PROMPT_CHARS_WITH_DOCUMENTS else MAX_USER_PROMPT_CHARS
        if (prompt.length > promptLimit) {
            errorText = if (activeDocuments.isNotEmpty()) {
                "Bu sohbette yerel belgeler de bağlama ekleniyor. Tek mesajı $promptLimit karakterle sınırla; daha uzun metni birkaç mesaja böl."
            } else {
                "Tek mesaj en fazla $promptLimit karakter olabilir. Uzun metni birkaç mesaja böl."
            }
            return
        }
        draft = ""
        val thread = activeThread ?: return
        val title = if (thread.messages.none { it.isUser }) prompt.replace('\n', ' ').take(34).let { if (prompt.length > 34) "$it…" else it } else thread.title
        val userMessage = ChatMessage(text = prompt, isUser = true)
        updateThread(thread.copy(title = title.ifBlank { "Yeni sohbet" }, updatedAt = System.currentTimeMillis(), messages = thread.messages + userMessage))
        if (aiBackendMode == AiBackendMode.API) {
            if (!apiKeyConfigured) {
                appendAssistant("API modu seçili ancak kayıtlı API anahtarı yok. Ayarlar → AI bağlantısı bölümünden HTTPS API adresini, model adını ve kendi anahtarını kaydet; istersen cihazda çalışma moduna dön.", isError = true)
                return
            }
            generateApiResponse(prompt)
            return
        }
        if (!modelReady || conversation == null) {
            appendAssistant("Gerçek yanıt üretmek için önce cihazında bir model yüklemelisin. Model simgesinden Qwen3-0.6B'yi indirebilir veya `.litertlm` dosyanı içe aktarabilirsin. API anahtarı cihazda çalışma için gerekmez.", isError = true)
            return
        }
        generateResponse(prompt)
    }

    /** Adds a short, deterministic probe to the active conversation to verify real local inference. */
    fun runQuickModelTest() {
        if (!modelReady || isWorking || isStopping) {
            errorText = "Model testi için önce yerel modeli yükle ve mevcut işlemin bitmesini bekle."
            return
        }
        draft = "Hızlı çalışma testi: Yalnızca TEST_OK yaz."
        send()
    }

    fun retryLastResponse() {
        if (isWorking || (aiBackendMode == AiBackendMode.LOCAL && !modelReady) || (aiBackendMode == AiBackendMode.API && !apiKeyConfigured)) return
        val thread = activeThread ?: return
        val lastUserIndex = thread.messages.indexOfLast { it.isUser }
        if (lastUserIndex < 0) return
        val prompt = thread.messages[lastUserIndex].text
        val prefix = thread.messages.take(lastUserIndex)
        val cleaned = thread.messages.take(lastUserIndex + 1)
        updateThread(thread.copy(messages = cleaned, updatedAt = System.currentTimeMillis()))
        if (aiBackendMode == AiBackendMode.API) {
            generateApiResponse(prompt)
            return
        }
        busy = true
        status = "Önceki bağlam geri yükleniyor…"
        viewModelScope.launch {
            try {
                withContext(aiDispatcher) {
                    conversation?.close()
                    conversation = engine?.createConversation(conversationConfig(prefix))
                }
                busy = false
                if (aiBackendMode == AiBackendMode.API) generateApiResponse(prompt) else generateResponse(prompt)
            } catch (e: Exception) {
                busy = false
                appendAssistant("Yeniden deneme başlatılamadı: ${e.message ?: "Bilinmeyen hata"}", isError = true)
            }
        }
    }

    /** API mode only: chat history and selected local-document excerpts are sent to the user-configured HTTPS endpoint. */
    private fun generateApiResponse(prompt: String) {
        val turnStartNanos = System.nanoTime()
        val assistantMessage = ChatMessage(text = "", isUser = false)
        appendMessage(assistantMessage)
        busy = true
        isPreparingTurn = true
        isStopping = false
        stopTimedOut = false
        generationElapsedSeconds = 0
        hasReceivedFirstToken = false
        status = "API isteği hazırlanıyor • $apiModelName"
        errorText = null
        responseJob = viewModelScope.launch {
            var answer = ""
            val streamedAnswer = StringBuilder()
            var completed = false
            var cancelledByUser = false
            var timedOut = false
            var failureCategory = ""
            var firstChunkLatencyMs = -1L
            var apiInputCharacters = 0L
            var apiAttemptsThisTurn = 0
            generationClockJob?.cancel()
            generationClockJob = viewModelScope.launch {
                while (busy) {
                    delay(1_000)
                    if (!busy) break
                    generationElapsedSeconds += 1
                    if (!hasReceivedFirstToken && generationElapsedSeconds >= 12 && !isStopping) {
                        status = "API yanıtı bekleniyor • ${generationElapsedSeconds} sn • $apiModelName"
                    }
                }
            }
            try {
                val (messages, sourceReferences) = buildApiMessages(prompt, assistantMessage.id)
                apiInputCharacters = messages.toString().length.toLong()
                replaceMessage(assistantMessage.id) { it.copy(sourceReferences = sourceReferences) }
                isPreparingTurn = false
                status = "API üzerinden yanıt üretiliyor • $apiModelName"
                answer = withTimeout(API_REQUEST_TIMEOUT_MS) {
                    var retryNumber = 0
                    var completedAnswer: String? = null
                    while (completedAnswer == null) {
                        try {
                            // Usage telemetry is best-effort: a preferences failure must never
                            // block the actual API request or its retry path.
                            apiAttemptsThisTurn += 1
                            runCatching {
                                apiUsageStore.recordAttempt()
                                apiUsage = apiUsageStore.load()
                            }
                            completedAnswer = streamApiRequest(messages, effectiveOutputTokens, responseProfile.temperature) { delta ->
                                if (delta.isNotEmpty()) withContext(Dispatchers.Main.immediate) {
                                    if (!hasReceivedFirstToken) {
                                        firstChunkLatencyMs = ((System.nanoTime() - turnStartNanos) / 1_000_000L).coerceAtLeast(1L)
                                    }
                                    streamedAnswer.append(delta)
                                    hasReceivedFirstToken = true
                                    replaceMessage(assistantMessage.id, persistNow = false) { it.copy(text = streamedAnswer.toString()) }
                                    status = "API yanıtı geliyor • ${generationElapsedSeconds} sn • $apiModelName"
                                }
                            }
                        } catch (cancelled: CancellationException) {
                            throw cancelled
                        } catch (attemptError: Exception) {
                            if (!ApiRetryPolicy.shouldRetry(attemptError, retryNumber, streamedAnswer.isNotEmpty())) throw attemptError
                            retryNumber += 1
                            val retryAfter = ApiRetryPolicy.retryAfterMillis(attemptError)
                            val waitMs = ApiRetryPolicy.delayMillis(retryNumber, retryAfter)
                            status = "Geçici API hatası • yeniden deneniyor ($retryNumber/${ApiRetryPolicy.MAX_RETRIES})"
                            delay(waitMs)
                        }
                    }
                    completedAnswer.orEmpty()
                }
                if (answer.isBlank()) answer = streamedAnswer.toString()
                hasReceivedFirstToken = answer.isNotBlank()
                if (answer.isBlank()) error("API boş yanıt döndürdü.")
                replaceMessage(assistantMessage.id) { it.copy(text = answer) }
                if (sourceReferences.isNotEmpty()) {
                    val currentThread = activeThread
                    val attachedIds = currentThread?.documents.orEmpty().map { it.id }.toSet()
                    val audit = SourceCitationValidator.validate(
                        answer = answer,
                        availableSources = sourceReferences,
                        hasAttachedDocuments = true,
                        allowedDocumentIds = attachedIds
                    )
                    replaceMessage(assistantMessage.id) { it.copy(citationAudit = audit) }
                }
                completed = true
            } catch (e: TimeoutCancellationException) {
                timedOut = true
                failureCategory = "api_request_timeout"
                apiConnection?.disconnect()
                val detail = "API yanıtı ${API_REQUEST_TIMEOUT_MS / 1000} saniye içinde tamamlanmadı (P0: api_request_timeout). Ağ, model adı ve sağlayıcı durumunu kontrol edip tekrar dene."
                replaceMessage(assistantMessage.id) {
                    val partial = answer.ifBlank { streamedAnswer.toString() }
                    it.copy(text = if (partial.isBlank()) detail else "$partial\n\n[$detail]", isInterrupted = true, isError = true)
                }
                errorText = detail
            } catch (e: CancellationException) {
                if (isStopping) {
                    cancelledByUser = true
                    failureCategory = "cancelled"
                    replaceMessage(assistantMessage.id) {
                        it.copy(text = answer.ifBlank { streamedAnswer.toString() }.ifBlank { "API isteği durduruldu." }, isInterrupted = true)
                    }
                } else {
                    throw e
                }
            } catch (e: Exception) {
                val diagnostic = AiFailureDiagnostics.classify(e, streamedAnswer.isNotEmpty())
                failureCategory = diagnostic.code
                val detail = "${diagnostic.userMessage} (P0: ${diagnostic.code})"
                val partial = answer.ifBlank { streamedAnswer.toString() }
                replaceMessage(assistantMessage.id) { it.copy(text = if (partial.isBlank()) detail else "$partial\n\n[$detail]", isError = true) }
                errorText = detail
            } finally {
                val apiOutcome = when {
                    completed -> InferenceSample.OUTCOME_SUCCESS
                    cancelledByUser -> InferenceSample.OUTCOME_CANCELLED
                    else -> InferenceSample.OUTCOME_FAILURE
                }
                if (apiAttemptsThisTurn > 0) {
                    runCatching {
                        apiUsageStore.recordTurn(
                            inputCharacters = apiInputCharacters,
                            outputCharacters = streamedAnswer.length.toLong().coerceAtLeast(answer.length.toLong()),
                            outcome = apiOutcome
                        )
                        apiUsage = apiUsageStore.load()
                    }
                }
                recordPerformanceSample(InferenceSample(
                    modelName = apiModelName.ifBlank { "API modeli" },
                    backendLabel = "API",
                    durationMs = ((System.nanoTime() - turnStartNanos) / 1_000_000L).coerceAtLeast(1L),
                    outputCharacters = streamedAnswer.length.coerceAtLeast(answer.length),
                    completedAt = System.currentTimeMillis(),
                    eventType = InferenceSample.EVENT_INFERENCE,
                    outcome = apiOutcome,
                    firstChunkLatencyMs = firstChunkLatencyMs,
                    errorCategory = when {
                        apiOutcome == InferenceSample.OUTCOME_SUCCESS -> ""
                        apiOutcome == InferenceSample.OUTCOME_CANCELLED -> "cancelled"
                        else -> failureCategory.ifBlank { "api_request_failed" }
                    }
                ))
                apiConnection?.disconnect()
                apiConnection = null
                generationClockJob?.cancel()
                generationClockJob = null
                isPreparingTurn = false
                busy = false
                isStopping = false
                stopTimedOut = false
                responseJob = null
                status = when {
                    completed -> "API hazır • $apiModelName"
                    timedOut -> "API zaman aşımı • tekrar deneyebilirsin"
                    cancelledByUser -> "API isteği durduruldu"
                    else -> "API isteği tamamlanamadı • ayarları kontrol et"
                }
                persistThreads()
            }
        }
    }

    /** Compose bounded chat history and local RAG context for remote inference. */
    private suspend fun buildApiMessages(prompt: String, excludedAssistantMessageId: String): Pair<JSONArray, List<LocalSourceReference>> {
        val thread = activeThread ?: error("Aktif sohbet bulunamadı.")
        val documentIds = thread.documents.map { it.id }.toSet()
        val retrievedSources = if (thread.documents.isNotEmpty()) withContext(Dispatchers.IO) {
            thread.documents.forEach { document ->
                if (!ragIndex.hasIndex(document.id)) {
                    val file = safeContextDocumentFile(document.storedFileName)
                    if (file != null && file.isFile) {
                        runCatching { ragIndex.upsertDocument(document.id, document.displayName, file.readText(StandardCharsets.UTF_8)) }
                    }
                }
            }
            ragIndex.search(
                query = prompt,
                allowedDocumentIds = documentIds,
                topK = LocalRagIndexStore.DEFAULT_TOP_K,
                maxContextChars = AssistantPromptBuilder.MAX_RETRIEVED_CONTEXT_CHARS
            )
        } else emptyList()
        val references = retrievedSources.mapIndexed { index, source ->
            LocalSourceReference(
                label = "[S${index + 1}]",
                documentId = source.documentId,
                documentName = source.documentName,
                sectionNumber = source.ordinal + 1,
                startOffset = source.startOffset,
                endOffset = source.endOffset,
                excerpt = source.text.take(900)
            )
        }
        val systemPrompt = AssistantPromptBuilder.buildWithRetrievedSources(
            mode = thread.mode,
            sources = retrievedSources,
            hasLocalDocuments = documentIds.isNotEmpty(),
            hasSemanticReranking = embeddingEnabled && embeddingModelReady,
            responseProfile = responseProfile
        )
        val result = JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt))
        val profileBudget = responseProfile.historyCharacterBudget
        val charBudget = if (documentIds.isNotEmpty()) minOf(profileBudget, 2_500) else maxOf(profileBudget, 2_500)
        val selected = mutableListOf<ChatMessage>()
        var usedChars = 0
        thread.messages.asReversed().forEach { message ->
            if (message.id == excludedAssistantMessageId || message.text.isBlank() || message.isError || message.isInterrupted) return@forEach
            if (selected.size >= responseProfile.historyMessageLimit || usedChars >= charBudget) return@forEach
            val remaining = charBudget - usedChars
            val perMessageLimit = if (selected.isEmpty() && message.isUser) {
                if (documentIds.isNotEmpty()) MAX_USER_PROMPT_CHARS_WITH_DOCUMENTS else MAX_USER_PROMPT_CHARS
            } else 1_500
            val clipped = message.copy(text = message.text.takeLast(remaining.coerceAtMost(perMessageLimit)))
            if (clipped.text.isNotBlank()) {
                selected += clipped
                usedChars += clipped.text.length
            }
        }
        selected.asReversed().forEach { message ->
            result.put(JSONObject()
                .put("role", if (message.isUser) "user" else "assistant")
                .put("content", message.text))
        }
        return result to references
    }

    /** SSE streaming with a non-streaming JSON fallback for compatible providers that ignore stream=true. */
    private suspend fun streamApiRequest(
        messages: JSONArray,
        tokenLimit: Int,
        temperature: Double,
        onDelta: suspend (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val key = apiSettingsStore.readApiKey()?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("API anahtarı bulunamadı. AI bağlantısı ayarlarından kendi anahtarını kaydet.")
        val payload = JSONObject()
            .put("model", apiSettingsStore.loadModel())
            .put("messages", messages)
            .put("max_tokens", tokenLimit.coerceIn(16, 1024))
            .put("temperature", temperature.coerceIn(0.0, 1.0))
            .put("stream", true)
        val connection = (URL(apiSettingsStore.loadEndpoint()).openConnection() as HttpURLConnection).apply {
            // Do not forward the user's bearer key through an unexpected cross-host redirect.
            instanceFollowRedirects = false
            requestMethod = "POST"
            connectTimeout = API_CONNECT_TIMEOUT_MS
            readTimeout = API_READ_TIMEOUT_MS
            doOutput = true
            useCaches = false
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "text/event-stream, application/json")
        }
        apiConnection = connection
        try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
            val code = connection.responseCode
            if (code !in 200..299) {
                val raw = connection.errorStream?.use { stream ->
                    val out = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(4096)
                    var total = 0
                    while (true) {
                        val count = stream.read(buffer)
                        if (count < 0) break
                        total += count
                        if (total > 16_384) break
                        out.write(buffer, 0, count)
                    }
                    out.toString("UTF-8")
                }.orEmpty()
                val providerMessage = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                val message = when (code) {
                    401, 403 -> "API anahtarı kabul edilmedi veya yetki yok (HTTP $code)."
                    429 -> "API sınırına veya bakiyeye ulaşıldı (HTTP 429)."
                    else -> "API HTTP $code${providerMessage?.takeIf { it.isNotBlank() }?.let { ": ${it.take(240)}"}.orEmpty()}"
                }
                throw ApiHttpException(
                    statusCode = code,
                    retryAfterMillis = ApiRetryPolicy.parseRetryAfterMillis(connection.getHeaderField("Retry-After")),
                    message = message
                )
            }
            val accumulated = StringBuilder()
            val nonSseBody = StringBuilder()
            java.io.BufferedReader(java.io.InputStreamReader(connection.inputStream, StandardCharsets.UTF_8)).use { reader ->
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.startsWith("data:")) {
                        val data = line.substringAfter("data:").trim()
                        if (data == "[DONE]") break
                        if (data.isNotEmpty()) {
                            val piece = runCatching {
                                val choices = JSONObject(data).optJSONArray("choices")
                                val delta = choices?.optJSONObject(0)?.optJSONObject("delta")?.opt("content")
                                when (delta) {
                                    is String -> delta
                                    is JSONArray -> buildString {
                                        for (i in 0 until delta.length()) append(delta.optJSONObject(i)?.optString("text", "").orEmpty())
                                    }
                                    else -> ""
                                }
                            }.getOrDefault("")
                            if (piece.isNotEmpty()) {
                                if (accumulated.length + piece.length > MAX_API_ANSWER_CHARS) {
                                    throw IllegalStateException("API yanıtı 100.000 karakter sınırını aştı.")
                                }
                                accumulated.append(piece)
                                onDelta(piece)
                            }
                        }
                    } else if (line.isNotBlank()) {
                        if (nonSseBody.length + line.length < MAX_API_RESPONSE_BYTES) nonSseBody.append(line)
                    }
                }
            }
            if (accumulated.isNotEmpty()) return@withContext accumulated.toString().trim()
            // Fallback for gateways that return a regular JSON completion despite stream=true.
            val fallbackBody = nonSseBody.toString()
            if (fallbackBody.isNotBlank()) {
                val root = JSONObject(fallbackBody)
                val choice = root.optJSONArray("choices")?.optJSONObject(0)
                val content = choice?.optJSONObject("message")?.opt("content")
                val fallback = when (content) {
                    is String -> content
                    is JSONArray -> buildString {
                        for (i in 0 until content.length()) append(content.optJSONObject(i)?.optString("text", "").orEmpty())
                    }
                    else -> ""
                }.trim()
                if (fallback.isNotBlank()) {
                    onDelta(fallback)
                    return@withContext fallback
                }
            }
            throw IllegalStateException("API akışında okunabilir metin yok. Sağlayıcının SSE stream biçimini ve model erişimini kontrol et.")
        } finally {
            connection.disconnect()
            if (apiConnection === connection) apiConnection = null
        }
    }

    /** Direct OpenAI Chat Completions-compatible request; the secret is never written to logs. */
    private suspend fun performApiRequest(messages: JSONArray, tokenLimit: Int): String = withContext(Dispatchers.IO) {
        val key = apiSettingsStore.readApiKey()?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("API anahtarı bulunamadı. AI bağlantısı ayarlarından kendi anahtarını kaydet.")
        val endpoint = apiSettingsStore.loadEndpoint()
        val model = apiSettingsStore.loadModel()
        val payload = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("max_tokens", tokenLimit.coerceIn(16, 1024))
            .put("stream", false)
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            // Do not forward the user's bearer key through an unexpected cross-host redirect.
            instanceFollowRedirects = false
            requestMethod = "POST"
            connectTimeout = API_CONNECT_TIMEOUT_MS
            readTimeout = API_READ_TIMEOUT_MS
            doOutput = true
            useCaches = false
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        apiConnection = connection
        try {
            connection.outputStream.use { output -> output.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
            val code = connection.responseCode
            val input = if (code in 200..299) connection.inputStream else connection.errorStream
            val bodyText = input?.use { stream ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8_192)
                var total = 0
                while (true) {
                    val count = stream.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_API_RESPONSE_BYTES) throw IllegalStateException("API yanıtı 1,5 MB sınırını aştı.")
                    out.write(buffer, 0, count)
                }
                out.toString("UTF-8")
            }.orEmpty()
            if (code !in 200..299) {
                val providerMessage = runCatching {
                    JSONObject(bodyText).optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }
                }.getOrNull()
                val message = when (code) {
                    401, 403 -> "API anahtarı kabul edilmedi veya yetki yok (HTTP $code)."
                    429 -> "API sınırına veya bakiyeye ulaşıldı (HTTP 429)."
                    else -> "API HTTP $code${providerMessage?.let { ": ${it.take(240)}"}.orEmpty()}"
                }
                throw ApiHttpException(
                    statusCode = code,
                    retryAfterMillis = ApiRetryPolicy.parseRetryAfterMillis(connection.getHeaderField("Retry-After")),
                    message = message
                )
            }
            val root = JSONObject(bodyText)
            val choices = root.optJSONArray("choices") ?: throw IllegalStateException("API yanıtında choices alanı yok. Uç nokta Chat Completions uyumlu olmalı.")
            val choice = choices.optJSONObject(0) ?: throw IllegalStateException("API yanıtında kullanılabilir seçenek yok.")
            val message = choice.optJSONObject("message") ?: throw IllegalStateException("API yanıtında message alanı yok.")
            val content = message.opt("content")
            val text = when (content) {
                is String -> content
                is JSONArray -> buildString {
                    for (i in 0 until content.length()) {
                        val item = content.optJSONObject(i) ?: continue
                        append(item.optString("text", ""))
                    }
                }
                else -> ""
            }.trim()
            if (text.isBlank()) {
                val finish = choice.optString("finish_reason", "bilinmiyor")
                throw IllegalStateException("API metin yanıtı vermedi (finish_reason=$finish). Modelin metin sohbetini desteklediğini kontrol et.")
            }
            text
        } finally {
            connection.disconnect()
            if (apiConnection === connection) apiConnection = null
        }
    }

    private fun generateResponse(prompt: String) {
        val turnStartNanos = System.nanoTime()
        val assistantMessage = ChatMessage(text = "", isUser = false)
        appendMessage(assistantMessage)
        busy = true
        isPreparingTurn = true
        isStopping = false
        stopTimedOut = false
        generationElapsedSeconds = 0
        hasReceivedFirstToken = false
        status = "${responseProfile.label} yanıt hazırlanıyor • ${activeBackendLabel}"
        responseJob = viewModelScope.launch {
            val accumulated = StringBuilder()
            var stoppedByUser = false
            var flowCompleted = false
            var timeoutTriggered = false
            var failureCategory = ""
            var firstChunkLatencyMs = -1L
            val ramBeforeInference = deviceProfile.availableRamBytes
            generationClockJob?.cancel()
            generationClockJob = viewModelScope.launch {
                while (busy) {
                    delay(1_000)
                    if (!busy) break
                    // Retrieval and conversation assembly can also take time; the first-token
                    // watchdog must start only after native generation is actually launched.
                    if (isPreparingTurn) continue
                    generationElapsedSeconds += 1
                    val elapsed = generationElapsedSeconds
                    if (!isStopping && ((!hasReceivedFirstToken && elapsed >= FIRST_TOKEN_TIMEOUT_SECONDS) || elapsed >= HARD_GENERATION_TIMEOUT_SECONDS)) {
                        timeoutTriggered = true
                        status = if (hasReceivedFirstToken) "Yanıt süresi sınırına ulaştı • güvenli durdurma" else "Model ilk yanıtı başlatamadı • güvenli durdurma"
                        stopGeneration()
                        break
                    }
                    if (!hasReceivedFirstToken && !isStopping && elapsed >= 12) {
                        status = "İlk yanıt bekleniyor • ${elapsed} sn • ${activeBackendLabel}"
                    }
                }
            }
            try {
                // Retrieve only relevant chunks for this question, scoped to documents attached to this chat.
                val threadSnapshot = activeThread ?: error("Aktif sohbet bulunamadı.")
                val historyBeforeQuestion = threadSnapshot.messages
                    .filterNot { it.id == assistantMessage.id }
                    .dropLast(1)
                val attachedDocumentIds = threadSnapshot.documents.map { it.id }.toSet()
                val retrievedSources = withContext(Dispatchers.IO) {
                    // A document imported by P2 may not have a P3 index yet; repair it before searching.
                    threadSnapshot.documents.forEach { document ->
                        if (!ragIndex.hasIndex(document.id)) {
                            val file = safeContextDocumentFile(document.storedFileName)
                            if (file != null && file.isFile) {
                                runCatching {
                                    ragIndex.upsertDocument(document.id, document.displayName, file.readText(StandardCharsets.UTF_8))
                                }
                            }
                        }
                    }
                    ragIndex.search(
                        query = prompt,
                        allowedDocumentIds = attachedDocumentIds,
                        topK = LocalRagIndexStore.DEFAULT_TOP_K,
                        maxContextChars = AssistantPromptBuilder.MAX_RETRIEVED_CONTEXT_CHARS
                    )
                }
                val sourceReferences = retrievedSources.mapIndexed { index, source ->
                    LocalSourceReference(
                        label = "[S${index + 1}]",
                        documentId = source.documentId,
                        documentName = source.documentName,
                        sectionNumber = source.ordinal + 1,
                        startOffset = source.startOffset,
                        endOffset = source.endOffset,
                        excerpt = source.text.take(900)
                    )
                }
                replaceMessage(assistantMessage.id) { it.copy(sourceReferences = sourceReferences) }
                val useSemanticRanking = embeddingEnabled && embeddingModelReady
                val activeConversation = withContext(aiDispatcher) {
                    conversation?.close()
                    engine?.createConversation(
                        conversationConfig(
                            history = historyBeforeQuestion,
                            retrievedSources = retrievedSources,
                            hasLocalDocuments = attachedDocumentIds.isNotEmpty(),
                            hasSemanticReranking = useSemanticRanking
                        )
                    )?.also { conversation = it }
                } ?: error("Yerel sohbet oturumu hazır değil.")
                isPreparingTurn = false
                streamResponse(activeConversation, prompt, effectiveOutputTokens)
                    .collect { chunk ->
                        // Keep the exact partial transcript until the native cancel callback arrives.
                        // If completion wins a race with the stop tap, the full response remains intact.
                        val part = chunk.toString()
                        if (part.isNotEmpty()) {
                            if (firstChunkLatencyMs < 0L) firstChunkLatencyMs = ((System.nanoTime() - turnStartNanos) / 1_000_000L).coerceAtLeast(1L)
                            hasReceivedFirstToken = true
                            accumulated.append(part)
                            replaceMessage(assistantMessage.id, persistNow = false) { it.copy(text = accumulated.toString()) }
                        }
                    }
                flowCompleted = true
                if (accumulated.isNotEmpty() && attachedDocumentIds.isNotEmpty()) {
                    val audit = SourceCitationValidator.validate(
                        answer = accumulated.toString(),
                        availableSources = sourceReferences,
                        hasAttachedDocuments = true,
                        allowedDocumentIds = attachedDocumentIds
                    )
                    replaceMessage(assistantMessage.id) { it.copy(citationAudit = audit) }
                }
                if (accumulated.isEmpty() && !isStopping) {
                    replaceMessage(assistantMessage.id) { it.copy(text = "Model boş yanıt döndürdü. Tekrar deneyebilirsin.", isError = true) }
                }
            } catch (cancelled: CancellationException) {
                if (isStopping) {
                    stoppedByUser = true
                } else {
                    throw cancelled
                }
            } catch (e: OutOfMemoryError) {
                failureCategory = "memory_pressure"
                replaceMessage(assistantMessage.id) { it.copy(text = "Cihaz belleği model yanıtı için yetersiz kaldı (P0: memory_pressure). Daha küçük bir model seçip diğer uygulamaları kapattıktan sonra tekrar dene.", isError = true) }
                errorText = "Model belleği aştı (P0: memory_pressure)."
            } catch (e: Exception) {
                if (isStopping && e is CancellationException) {
                    stoppedByUser = true
                } else {
                    val diagnostic = AiFailureDiagnostics.classify(e, hasReceivedFirstToken)
                    failureCategory = diagnostic.code
                    replaceMessage(assistantMessage.id) { it.copy(text = "${diagnostic.userMessage} (P0: ${diagnostic.code})", isError = true) }
                    errorText = "${diagnostic.userMessage} (P0: ${diagnostic.code})"
                }
            } catch (e: LinkageError) {
                // Surface binary/runtime incompatibilities instead of leaving an empty assistant bubble.
                replaceMessage(assistantMessage.id) {
                    it.copy(text = "${AiFailureDiagnostics.classify(e, hasReceivedFirstToken).userMessage} (P0: runtime_incompatible). Uygulama ve model uyumluluğunu kontrol edip modeli yeniden yükle.", isError = true)
                }
                failureCategory = "runtime_incompatible"
                errorText = "LiteRT-LM çalışma zamanı uyumsuzluğu: ${e.javaClass.simpleName}"
                modelReady = false
            } finally {
                generationClockJob?.cancel()
                generationClockJob = null
                val finalOutcome = when {
                    timeoutTriggered -> InferenceSample.OUTCOME_FAILURE
                    stoppedByUser || (isStopping && !flowCompleted) -> InferenceSample.OUTCOME_CANCELLED
                    flowCompleted && accumulated.isNotEmpty() -> InferenceSample.OUTCOME_SUCCESS
                    else -> InferenceSample.OUTCOME_FAILURE
                }
                if (timeoutTriggered) failureCategory = if (hasReceivedFirstToken) "generation_timeout" else "first_token_timeout"
                if (flowCompleted && accumulated.isEmpty() && failureCategory.isBlank()) failureCategory = "empty_response"
                recordPerformanceSample(InferenceSample(
                    modelName = activeModelName ?: "içe-aktarılmış-model",
                    backendLabel = activeBackendLabel,
                    durationMs = ((System.nanoTime() - turnStartNanos) / 1_000_000L).coerceAtLeast(1L),
                    outputCharacters = accumulated.length,
                    completedAt = System.currentTimeMillis(),
                    eventType = InferenceSample.EVENT_INFERENCE,
                    outcome = finalOutcome,
                    availableRamBeforeBytes = ramBeforeInference,
                    availableRamAfterBytes = deviceProfile.availableRamBytes,
                    firstChunkLatencyMs = firstChunkLatencyMs,
                    errorCategory = when {
                        finalOutcome == InferenceSample.OUTCOME_FAILURE -> failureCategory.ifBlank { "inference_failure" }
                        finalOutcome == InferenceSample.OUTCOME_CANCELLED -> "cancelled"
                        else -> ""
                    }
                ))
                if (stoppedByUser || (isStopping && !flowCompleted)) {
                    val timeoutMessage = when {
                        !timeoutTriggered -> "Yanıt durduruldu."
                        !hasReceivedFirstToken -> "Model ${FIRST_TOKEN_TIMEOUT_SECONDS} saniye içinde ilk yanıt parçasını üretmedi. Otomatik durduruldu (P0: first_token_timeout). Model ayarlarından CPU/GPU arka ucunu değiştirip kısa bir test sorusu dene."
                        else -> "Yanıt ${HARD_GENERATION_TIMEOUT_SECONDS} saniyelik güvenlik sınırına ulaştığı için durduruldu (P0: generation_timeout)."
                    }
                    replaceMessage(assistantMessage.id) {
                        it.copy(
                            text = accumulated.toString().ifBlank { timeoutMessage }.let { partial ->
                                if (timeoutTriggered && accumulated.isNotEmpty()) "$partial\n\n[$timeoutMessage]" else partial
                            },
                            isInterrupted = true,
                            isError = timeoutTriggered
                        )
                    }
                    persistThreads()
                    try {
                        val restoredHistory = activeThread?.messages.orEmpty()
                        withContext(NonCancellable + aiDispatcher) {
                            // The Flow may deliver cancellation as a CancellationException, which marks
                            // this coroutine cancelled. Use NonCancellable only for deterministic cleanup.
                            // LiteRT-LM also says a cancelled Conversation must not be reused.
                            conversation?.close()
                            conversation = engine?.createConversation(conversationConfig(restoredHistory))
                                ?: error("Model motoru kapalı; yeniden sohbet oturumu oluşturulamadı.")
                        }
                        status = if (timeoutTriggered) "Yanıt zaman aşımı • $activeBackendLabel yeniden hazır" else "Yanıt durduruldu • $activeBackendLabel hazır"
                        errorText = if (timeoutTriggered) {
                            if (!hasReceivedFirstToken) {
                                "Model ilk yanıt parçasını ${FIRST_TOKEN_TIMEOUT_SECONDS} saniyede üretemedi (P0: first_token_timeout). RAM'i, model bütünlüğünü ve CPU/GPU arka ucunu kontrol et; daha küçük modelle test et."
                            } else {
                                "Yanıt ${HARD_GENERATION_TIMEOUT_SECONDS} saniyelik güvenlik sınırına ulaştı (P0: generation_timeout). Daha kısa bir istem veya daha düşük çıktı sınırı dene."
                            }
                        } else null
                    } catch (e: Exception) {
                        modelReady = false
                        status = "Sohbet oturumu sıfırlanamadı"
                        errorText = "Yanıt durduruldu ancak sohbet oturumu yeniden oluşturulamadı: ${e.message ?: "Bilinmeyen hata"}. Modeli yeniden yüklemeyi dene."
                    }
                } else if (modelReady) {
                    status = "Yerel model hazır • $activeBackendLabel • çevrimdışı"
                } else {
                    status = "Yerel model yüklenmedi"
                }
                persistThreads()
                busy = false
                isPreparingTurn = false
                if (isStopping || stoppedByUser) {
                    isStopping = false
                    stopTimedOut = false
                    stopWatchdogJob?.cancel()
                    stopWatchdogJob = null
                }
                responseJob = null
            }
        }
    }

    /**
     * Uses LiteRT-LM's callback API and adapts it locally to Flow. This avoids relying on the
     * Flow adapter bundled inside the native runtime artifact and makes terminal callbacks explicit.
     * Native generation is started on the same single-thread dispatcher as initialize/close.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    private fun streamResponse(activeConversation: Conversation, prompt: String, tokenLimit: Int): Flow<Message> =
        callbackFlow {
            val callback = object : MessageCallback {
                override fun onMessage(message: Message) {
                    trySend(message)
                }

                override fun onDone() {
                    close()
                }

                override fun onError(throwable: Throwable) {
                    close(throwable)
                }
            }
            activeConversation.sendMessageAsync(
                prompt,
                callback,
                maxOutputToken = tokenLimit,
                thinkingConfig = FAST_THINKING_CONFIG
            )
            awaitClose { }
        }.flowOn(aiDispatcher)

    private suspend fun recordPerformanceSample(sample: InferenceSample) {
        // Performance recording is best-effort and must not turn successful inference into failure.
        runCatching {
            withContext(NonCancellable + Dispatchers.IO) {
                performanceTelemetry.record(sample)
                performanceTelemetry.load()
            }
        }.onSuccess { performanceSamples = it }
    }

    private fun classifyRuntimeError(error: Throwable): String = AiFailureDiagnostics.classify(error).code

    private fun rebuildConversationForActiveThread() {
        if (!modelReady || engine == null || isWorking) return
        viewModelScope.launch {
            try {
                withContext(aiDispatcher) {
                    conversation?.close()
                    conversation = engine?.createConversation(conversationConfig(activeThread?.messages.orEmpty()))
                }
            } catch (e: Exception) {
                errorText = "Sohbet bağlamı yüklenemedi: ${e.message}"
            }
        }
    }

    private fun conversationConfig(
        history: List<ChatMessage>,
        retrievedSources: List<RagChunk> = emptyList(),
        hasLocalDocuments: Boolean = activeThread?.documents?.isNotEmpty() == true,
        hasSemanticReranking: Boolean = false
    ): ConversationConfig {
        // Keep the history and retrieved source excerpts bounded for small local context windows.
        // A real model tokenizer is not exposed by the currently integrated LiteRT-LM API, so this
        // stage uses a conservative character budget rather than pretending to count exact tokens.
        val thread = activeThread
        val hasDocuments = hasLocalDocuments
        val historyCharBudget = if (hasDocuments) minOf(responseProfile.historyCharacterBudget, 1_800) else responseProfile.historyCharacterBudget
        val historyMessageLimit = responseProfile.historyMessageLimit
        val boundedHistory = mutableListOf<ChatMessage>()
        var contextChars = 0
        for (msg in history.asReversed()) {
            if (msg.text.isBlank() || msg.isError || msg.isInterrupted) continue
            if (boundedHistory.size >= historyMessageLimit || contextChars >= historyCharBudget) break
            val remaining = historyCharBudget - contextChars
            val clipped = msg.copy(text = msg.text.takeLast(remaining.coerceAtMost(1_200)))
            boundedHistory += clipped
            contextChars += clipped.text.length
        }
        val initial = boundedHistory.asReversed().map { msg ->
            if (msg.isUser) Message.user(msg.text) else Message.model(msg.text)
        }
        val systemPrompt = AssistantPromptBuilder.buildWithRetrievedSources(
            mode = thread?.mode ?: AssistantMode.GENERAL,
            sources = retrievedSources,
            hasLocalDocuments = hasDocuments,
            hasSemanticReranking = hasSemanticReranking,
            responseProfile = responseProfile
        )
        return ConversationConfig(
            systemInstruction = Contents.of(systemPrompt),
            initialMessages = initial,
            samplerConfig = SamplerConfig(
                topK = responseProfile.topK,
                topP = responseProfile.topP,
                temperature = responseProfile.temperature
            ),
            thinkingConfig = FAST_THINKING_CONFIG,
            maxOutputToken = effectiveOutputTokens
        )
    }

    private fun appendAssistant(text: String, isError: Boolean = false) {
        appendMessage(ChatMessage(text = text, isUser = false, isError = isError))
    }

    private fun appendMessage(message: ChatMessage) {
        val thread = activeThread ?: return
        updateThread(thread.copy(updatedAt = System.currentTimeMillis(), messages = thread.messages + message))
    }

    private fun replaceMessage(id: String, persistNow: Boolean = true, transform: (ChatMessage) -> ChatMessage) {
        val thread = activeThread ?: return
        updateThread(
            thread.copy(updatedAt = System.currentTimeMillis(), messages = thread.messages.map { if (it.id == id) transform(it) else it }),
            persistNow = persistNow
        )
    }

    private fun updateThread(updated: ChatThread, persistNow: Boolean = true) {
        threads = threads.map { if (it.id == updated.id) updated else it }.sortedByDescending { it.updatedAt }
        if (persistNow) persistThreads() else persistThreadsDebounced()
    }

    private fun persistThreadsDebounced() {
        if (persistenceJob?.isActive == true) return
        persistenceJob = viewModelScope.launch {
            delay(500)
            persistThreads()
        }
    }

    private fun persistThreads() {
        repository.saveThreads(threads, activeThreadId.orEmpty())
    }

    /** Removes interrupted download/import scratch files left if Android killed the process. */
    private fun cleanupOrphanModelArtifacts() {
        viewModelScope.launch(Dispatchers.IO) {
            listOf(modelDirectory, embeddingModelDirectory).forEach { directory ->
                directory.listFiles().orEmpty()
                    .filter { file ->
                        file.isFile && file.lastModified() < processStartTimeMs &&
                            (file.name.endsWith(".part", ignoreCase = true) || file.name.endsWith(".importing", ignoreCase = true) ||
                                file.name.endsWith(".integrity.tmp", ignoreCase = true) || file.name.endsWith(".integrity.bak", ignoreCase = true) ||
                                file.name.endsWith(".verified.tmp", ignoreCase = true))
                    }
                    .forEach { file -> runCatching { file.delete() } }
            }
        }
    }

    private fun refreshModels() {
        val active = activeModelName
        models = modelDirectory.listFiles()
            .orEmpty()
            .filter { it.isFile && it.name.endsWith(".litertlm", ignoreCase = true) && it.length() >= MIN_MODEL_BYTES && it.name !in invalidCatalogModelNames }
            .sortedBy { it.name.lowercase() }
            .map { LocalModel(it.name, it, it.length(), it.name == active) }
    }

    private fun queryDisplayName(uri: Uri): String {
        val resolver = getApplication<Application>().contentResolver
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) return cursor.getString(index) ?: "imported.litertlm"
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "imported.litertlm"
    }

    private fun queryDocumentSize(uri: Uri): Long? {
        val resolver = getApplication<Application>().contentResolver
        return runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (index >= 0) cursor.getLong(index).takeIf { it > 0L } else null
                } else null
            }
        }.getOrNull()
    }

    private fun safeModelFile(name: String): File? {
        if (name != File(name).name || !name.endsWith(".litertlm", ignoreCase = true)) return null
        if (!name.matches(Regex("[A-Za-z0-9._-]+\\.litertlm", RegexOption.IGNORE_CASE))) return null
        return File(modelDirectory, name)
    }

    private fun sanitizeModelName(input: String): String {
        val base = input.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return (base.ifBlank { "model.litertlm" }).let { if (it.endsWith(".litertlm", true)) it else "$it.litertlm" }
    }

    private fun uniqueFile(name: String): File {
        var output = File(modelDirectory, name)
        var index = 2
        while (output.exists()) {
            val base = name.removeSuffix(".litertlm")
            output = File(modelDirectory, "$base-$index.litertlm")
            index++
        }
        return output
    }

    private fun formatBytes(bytes: Long): String {
        val mb = bytes / 1_048_576.0
        return if (mb >= 1024) String.format(java.util.Locale("tr", "TR"), "%.2f GB", mb / 1024.0)
        else String.format(java.util.Locale("tr", "TR"), "%.0f MB", mb)
    }

    private fun reconcileContextDocuments() {
        val current = threads
        val cleaned = current.map { thread ->
            thread.copy(documents = thread.documents.filter { document ->
                safeContextDocumentFile(document.storedFileName)?.isFile == true
            })
        }
        if (cleaned != current) {
            threads = cleaned
            persistThreads()
        }
        val liveDocuments = cleaned.flatMap { it.documents }
        val liveNames = liveDocuments.map { it.storedFileName }.toSet()
        val liveDocumentIds = liveDocuments.map { it.id }.toSet()
        viewModelScope.launch(Dispatchers.IO) {
            // Recover missing indexes on upgrade, and prune index files whose documents were removed.
            ragIndex.removeMissing(liveDocumentIds)
            liveDocuments.forEach { document ->
                if (!ragIndex.hasIndex(document.id)) {
                    val file = safeContextDocumentFile(document.storedFileName)
                    if (file != null && file.isFile) {
                        runCatching { ragIndex.upsertDocument(document.id, document.displayName, file.readText(StandardCharsets.UTF_8)) }
                    }
                }
            }
            contextDocumentDirectory.listFiles().orEmpty().forEach { file ->
                if (file.isFile && file.name !in liveNames) file.delete()
            }
        }
    }


    private fun safeContextDocumentFile(name: String): File? {
        // Imported names are generated by this app; still reject path separators from stale/corrupt metadata.
        if (name != File(name).name || !name.endsWith(".txt", ignoreCase = true)) return null
        if (!name.matches(Regex("[A-Fa-f0-9-]+_[A-Fa-f0-9-]+\\.txt", RegexOption.IGNORE_CASE))) return null
        return File(contextDocumentDirectory, name)
    }

    private fun deleteThreadDocumentFiles(thread: ChatThread) {
        thread.documents.forEach { document ->
            runCatching { safeContextDocumentFile(document.storedFileName)?.delete() }
            runCatching { ragIndex.removeDocument(document.id) }
        }
    }

    private fun closeConversationAndEngine() {
        runCatching { conversation?.close() }
        conversation = null
        runCatching { engine?.close() }
        engine = null
    }

    override fun onCleared() {
        persistenceJob?.cancel()
        responseJob?.cancel()
        downloadJob?.cancel()
        stopWatchdogJob?.cancel()
        runCatching { repository.saveThreadsNow(threads, activeThreadId.orEmpty()) }
        repository.close()
        runCatching {
            aiExecutor.execute {
                closeConversationAndEngine()
                aiDispatcher.close()
                aiExecutor.shutdown()
            }
        }
        runCatching { embeddingEngine.shutdown() }
        super.onCleared()
    }

    companion object {
        private val FAST_THINKING_CONFIG = ThinkingConfig(enableThinking = false, thinkingTokenBudget = 0)
        private const val FIRST_TOKEN_TIMEOUT_SECONDS = 120
        private const val HARD_GENERATION_TIMEOUT_SECONDS = 300
        private const val API_CONNECT_TIMEOUT_MS = 15_000
        private const val API_READ_TIMEOUT_MS = 60_000
        private const val API_REQUEST_TIMEOUT_MS = 75_000L
        private const val API_TEST_TIMEOUT_MS = 75_000L
        private const val MAX_API_RESPONSE_BYTES = 1_572_864
        private const val MAX_API_ANSWER_CHARS = 100_000
        const val RECOMMENDED_MODEL_NAME = "Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm"
        private const val MIN_MODEL_BYTES = 100_000_000L
        private const val MAX_THREADS = 100
        private const val MAX_CONTEXT_DOCUMENTS = DocumentIngestionPolicy.MAX_ATTACHED_PER_CHAT
        private const val MAX_BATCH_IMPORT_DOCUMENTS = DocumentIngestionPolicy.MAX_BATCH_FILES
        private const val MAX_USER_PROMPT_CHARS = 3_000
        private const val MAX_USER_PROMPT_CHARS_WITH_DOCUMENTS = 1_800
    }
}
