package com.breitbrut5.ai

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Local change detection plus optional publisher checksum verification. A first fingerprint for
 * a user-imported file is only a local baseline; it does not prove who published those bytes.
 */
internal object ModelArtifactIntegrity {
    enum class Result { VERIFIED_EXISTING_FINGERPRINT, CREATED_FIRST_FINGERPRINT }

    private data class CachedValidation(
        val size: Long,
        val modifiedAt: Long,
        val digest: String,
        val trustedSha256: String?
    )

    private val validated = ConcurrentHashMap<String, CachedValidation>()

    fun manifestFile(modelFile: File): File = File(modelFile.parentFile, modelFile.name + ".integrity")

    fun initialize(modelFile: File, trustedSha256: String? = null): String {
        require(modelFile.isFile && modelFile.length() > 0L) { "Model dosyası boş veya bulunamadı." }
        validateExpectedHash(trustedSha256)
        val digest = sha256(modelFile)
        recordVerifiedDigest(modelFile, digest, trustedSha256)
        return digest
    }

    /** Records a digest that was computed over the exact temporary file immediately before its atomic move. */
    internal fun recordVerifiedDigest(modelFile: File, digest: String, trustedSha256: String? = null) {
        require(modelFile.isFile && modelFile.length() > 0L) { "Model dosyası boş veya bulunamadı." }
        validateExpectedHash(trustedSha256)
        require(digest.matches(Regex("[0-9a-f]{64}"))) { "Hesaplanan model SHA-256 değeri geçersiz." }
        if (trustedSha256 != null) {
            require(digest.equals(trustedSha256, ignoreCase = true)) {
                "Model SHA-256 doğrulaması başarısız. Dosya etkinleştirilmedi."
            }
        }
        writeManifest(modelFile, digest, trustedSha256)
        remember(modelFile, digest, trustedSha256)
    }

    fun verifyOrCreate(modelFile: File, trustedSha256: String? = null): Result {
        require(modelFile.isFile && modelFile.length() > 0L) { "Model dosyası boş veya bulunamadı." }
        validateExpectedHash(trustedSha256)
        val manifest = manifestFile(modelFile)
        val key = modelFile.absolutePath
        val cached = validated[key]

        if (trustedSha256 != null) {
            if (cached != null && cached.size == modelFile.length() && cached.modifiedAt == modelFile.lastModified() &&
                cached.digest == trustedSha256.lowercase() && cached.trustedSha256 == trustedSha256.lowercase()) {
                return Result.VERIFIED_EXISTING_FINGERPRINT
            }
            // Publisher-pinned digest is authoritative. A stale/missing sidecar is repaired only
            // after the full artifact hash matches; this also recovers a process death during install.
            val actual = sha256(modelFile)
            require(actual.equals(trustedSha256, ignoreCase = true)) {
                "Model SHA-256 doğrulaması başarısız. Dosya bozulmuş veya katalogdaki güvenilir sürümle eşleşmiyor."
            }
            val sidecarMatches = runCatching {
                val lines = manifest.readLines(Charsets.UTF_8)
                if (lines.firstOrNull() == "v2") {
                    lines.size >= 4 &&
                        lines[1].toLongOrNull() == modelFile.length() &&
                        lines[2].trim().equals(actual, ignoreCase = true) &&
                        lines[3].trim().equals(trustedSha256, ignoreCase = true)
                } else {
                    // An old local-only fingerprint is not enough to establish publisher trust.
                    false
                }
            }.getOrDefault(false)
            if (!sidecarMatches) writeManifest(modelFile, actual, trustedSha256)
            remember(modelFile, actual, trustedSha256)
            return if (sidecarMatches) Result.VERIFIED_EXISTING_FINGERPRINT else Result.CREATED_FIRST_FINGERPRINT
        }

        if (!manifest.isFile) {
            initialize(modelFile)
            return Result.CREATED_FIRST_FINGERPRINT
        }
        val lines = manifest.readLines(Charsets.UTF_8)
        val expectedSize: Long
        val expectedDigest: String
        if (lines.firstOrNull() == "v2") {
            require(lines.size >= 4) { "Model bütünlük kaydı bozuk; modeli yeniden içe aktar." }
            expectedSize = lines[1].toLongOrNull() ?: error("Model bütünlük kaydındaki boyut geçersiz.")
            expectedDigest = lines[2].trim().lowercase()
        } else {
            // Backward-compatible reader for the original two-line P0 manifest.
            require(lines.size >= 2) { "Model bütünlük kaydı bozuk; modeli yeniden içe aktar." }
            expectedSize = lines[0].toLongOrNull() ?: error("Model bütünlük kaydındaki boyut geçersiz.")
            expectedDigest = lines[1].trim().lowercase()
        }
        require(expectedDigest.matches(Regex("[0-9a-f]{64}"))) { "Model bütünlük kaydındaki SHA-256 geçersiz." }
        require(modelFile.length() == expectedSize) {
            "Model dosyasının boyutu bütünlük kaydıyla eşleşmiyor. Yeniden indir veya içe aktar."
        }
        if (cached != null && cached.size == modelFile.length() && cached.modifiedAt == modelFile.lastModified() &&
            cached.digest == expectedDigest && cached.trustedSha256 == null) {
            return Result.VERIFIED_EXISTING_FINGERPRINT
        }
        val actual = sha256(modelFile)
        require(actual == expectedDigest) {
            "Model dosyası son kontrolden sonra değişmiş veya bozulmuş. Dosyayı yeniden indir/içe aktar."
        }
        remember(modelFile, actual, null)
        return Result.VERIFIED_EXISTING_FINGERPRINT
    }

    fun deleteManifest(modelFile: File) {
        validated.remove(modelFile.absolutePath)
        manifestFile(modelFile).delete()
    }

    internal fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun validateExpectedHash(value: String?) {
        require(value == null || value.matches(Regex("[0-9a-fA-F]{64}"))) {
            "Güvenilir model SHA-256 değeri geçersiz."
        }
    }

    private fun writeManifest(file: File, digest: String, trustedSha256: String?) {
        val source = trustedSha256?.lowercase() ?: "local"
        AtomicTextFileStore(manifestFile(file)).writeText("v2\n${file.length()}\n$digest\n$source\n")
    }

    private fun remember(file: File, digest: String, trustedSha256: String?) {
        validated[file.absolutePath] = CachedValidation(file.length(), file.lastModified(), digest, trustedSha256?.lowercase())
    }
}
