package com.breitbrut5.ai

import java.io.EOFException
import java.io.IOException
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Stable, privacy-safe failure categories surfaced to the UI and local performance telemetry. */
internal data class AiFailureDiagnostic(
    val code: String,
    val userMessage: String,
    val retryable: Boolean
)

internal object AiFailureDiagnostics {
    fun classify(error: Throwable, firstOutputReceived: Boolean = false): AiFailureDiagnostic {
        val chain = causeChain(error)
        val text = chain.joinToString(" ") { it.message.orEmpty() }.lowercase(Locale.ROOT)
        val code = when {
            chain.any { it is OutOfMemoryError } -> "memory_pressure"
            chain.any { it is UnknownHostException } -> "network_unavailable"
            chain.any { it is SocketTimeoutException } -> "network_timeout"
            chain.any { it is ApiHttpException && (it.statusCode == 401 || it.statusCode == 403) } -> "api_authentication"
            chain.any { it is ApiHttpException && it.statusCode == 429 } -> "api_rate_limited"
            chain.any { it is ApiHttpException && it.statusCode in setOf(408, 425) } -> "api_transient_failure"
            chain.any { it is ApiHttpException && it.statusCode >= 500 } -> "api_server_error"
            chain.any { it is ApiHttpException && it.statusCode in 300..499 } -> "api_request_rejected"
            chain.any { it is java.net.MalformedURLException } -> "invalid_api_endpoint"
            chain.any { it is javax.net.ssl.SSLException } -> "api_tls_failure"
            text.contains("sha-256") || text.contains("sha256") || text.contains("bütünlük") || text.contains("integrity") -> "model_integrity"
            chain.any { it is LinkageError } -> "runtime_incompatible"
            text.contains("gpu") || text.contains("delegate") || text.contains("backend") || text.contains("opencl") -> "backend_failure"
            chain.any { it is ConnectException || it is NoRouteToHostException || it is SocketException || it is EOFException } -> "network_connection"
            text.contains("empty") || text.contains("boş yanıt") || text.contains("no readable text") -> "empty_response"
            text.contains("model") || text.contains("litert") || text.contains("tokenizer") || text.contains("file") -> "model_or_file_failure"
            else -> if (firstOutputReceived) "generation_interrupted" else "inference_failure"
        }
        return when (code) {
            "memory_pressure" -> AiFailureDiagnostic(code, "Cihaz RAM'i model için yetersiz kaldı. Daha küçük bir model seç, diğer uygulamaları kapat ve tekrar dene.", false)
            "network_unavailable" -> AiFailureDiagnostic(code, "Sunucunun adresi bulunamadı. İnternet bağlantısını ve sunucu adresini kontrol et.", true)
            "network_timeout" -> AiFailureDiagnostic(code, "Sunucu bağlantısı zaman aşımına uğradı. İnternet bağlantısını ve sunucunun durumunu kontrol edip yeniden deneyebilirsin.", true)
            "network_connection" -> AiFailureDiagnostic(code, "Sunucuyla bağlantı kesildi. Ağ bağlantısını kontrol edip yeniden deneyebilirsin.", true)
            "invalid_api_endpoint" -> AiFailureDiagnostic(code, "API adresi geçerli bir URL değil. HTTPS uç noktasını kontrol et.", false)
            "api_tls_failure" -> AiFailureDiagnostic(code, "API sunucusunun TLS/sertifika bağlantısı doğrulanamadı. HTTPS adresini, cihaz tarihini ve sunucu sertifikasını kontrol et.", false)
            "api_authentication" -> AiFailureDiagnostic(code, "API anahtarı kabul edilmedi veya bu model için yetkin yok. Anahtarı ve sağlayıcı izinlerini kontrol et.", false)
            "api_rate_limited" -> AiFailureDiagnostic(code, "API kullanım sınırına ulaşıldı. Sağlayıcının kota ve kullanım bilgilerini kontrol et.", true)
            "api_transient_failure" -> AiFailureDiagnostic(code, "API isteği geçici olarak kabul edilemedi veya zaman aşımına uğradı. Bağlantıyı kontrol edip yeniden deneyebilirsin.", true)
            "api_request_rejected" -> AiFailureDiagnostic(code, "API isteği reddedildi. Uç noktanın doğru olduğunu, model adını ve sağlayıcının beklediği istek biçimini kontrol et.", false)
            "api_server_error" -> AiFailureDiagnostic(code, "API sağlayıcısı geçici bir sunucu hatası verdi. Biraz sonra yeniden deneyebilirsin.", true)
            "model_integrity" -> AiFailureDiagnostic(code, "Model dosyasının SHA-256 bütünlük kontrolü başarısız oldu. Bu dosya etkinleştirilmedi; modeli güvenilir kaynaktan yeniden indir.", false)
            "runtime_incompatible" -> AiFailureDiagnostic(code, "LiteRT-LM yerel çalışma zamanı bu model veya cihaz yapısıyla uyumlu değil. Uygulama sürümünü ve model biçimini kontrol et.", false)
            "backend_failure" -> AiFailureDiagnostic(code, "Seçilen CPU/GPU arka ucu modeli başlatamadı. Model yöneticisinden CPU seçeneğini deneyebilirsin.", false)
            "model_or_file_failure" -> AiFailureDiagnostic(code, "Model dosyası açılamadı veya model başlatılamadı. Dosyanın bütünlüğünü kontrol edip modeli yeniden yükle.", false)
            "empty_response" -> AiFailureDiagnostic(code, "Model boş yanıt döndürdü. Daha kısa bir istemle veya farklı bir model/arka uçla tekrar dene.", true)
            "generation_interrupted" -> AiFailureDiagnostic(code, "Yanıt üretimi ilk parçadan sonra kesildi. Kısmi yanıt korunuyor; yeniden deneyebilirsin.", true)
            else -> AiFailureDiagnostic(code, "AI yanıtı tamamlayamadı. Modelin hazır olduğunu kontrol et; kısa bir test sorusu dene ve gerekirse modeli yeniden yükle.", false)
        }
    }

    private fun causeChain(error: Throwable): List<Throwable> {
        val result = ArrayList<Throwable>(4)
        val seen = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Throwable, Boolean>())
        var current: Throwable? = error
        while (current != null && result.size < 12 && seen.add(current)) {
            result += current
            current = current.cause
        }
        return result
    }
}

/** HTTP status kept as a typed value so retry policy never parses provider text. */
internal class ApiHttpException(
    val statusCode: Int,
    val retryAfterMillis: Long? = null,
    message: String
) : IOException(message)

internal object ApiRetryPolicy {
    const val MAX_RETRIES = 2

    fun shouldRetry(error: Throwable, retryNumber: Int, hasPartialOutput: Boolean): Boolean {
        if (retryNumber >= MAX_RETRIES || hasPartialOutput) return false
        val chain = causeChain(error)
        val status = chain.filterIsInstance<ApiHttpException>().firstOrNull()?.statusCode
        if (status != null) return status in RETRYABLE_HTTP_CODES
        if (chain.any { it is UnknownHostException || it is javax.net.ssl.SSLException }) return false
        // Do not retry arbitrary IOExceptions (for example malformed requests or local file errors).
        return chain.any {
            it is SocketTimeoutException || it is ConnectException ||
                it is NoRouteToHostException || it is SocketException || it is EOFException
        }
    }

    /** Retry-After may be either delta-seconds or an RFC-1123 HTTP date. */
    fun parseRetryAfterMillis(value: String?, nowMillis: Long = System.currentTimeMillis()): Long? {
        val raw = value?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        raw.toLongOrNull()?.let { seconds ->
            if (seconds < 0L) return null
            return seconds.coerceAtMost(60L) * 1_000L
        }
        return runCatching {
            val at = ZonedDateTime.parse(raw, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli()
            (at - nowMillis).coerceAtLeast(0L).coerceAtMost(60_000L)
        }.getOrNull()
    }

    fun retryAfterMillis(error: Throwable): Long? =
        causeChain(error).filterIsInstance<ApiHttpException>().firstOrNull()?.retryAfterMillis

    fun delayMillis(retryNumber: Int, retryAfterMillis: Long? = null): Long {
        val exponential = when (retryNumber) {
            1 -> 700L
            else -> 1_500L
        }
        return (retryAfterMillis ?: exponential).coerceIn(250L, 15_000L)
    }

    private fun causeChain(error: Throwable): List<Throwable> {
        val result = ArrayList<Throwable>(4)
        val seen = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Throwable, Boolean>())
        var current: Throwable? = error
        while (current != null && result.size < 12 && seen.add(current)) {
            result += current
            current = current.cause
        }
        return result
    }

    private val RETRYABLE_HTTP_CODES = setOf(408, 425, 429, 500, 502, 503, 504)
}
