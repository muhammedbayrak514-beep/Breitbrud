package com.breitbrut5.ai

import android.app.ActivityManager
import android.content.Context
import android.os.StatFs
import java.io.File
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import java.util.UUID

internal data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val createdAt: Long = System.currentTimeMillis(),
    val isError: Boolean = false,
    val isInterrupted: Boolean = false,
    val sourceReferences: List<LocalSourceReference> = emptyList(),
    val citationAudit: CitationAudit? = null
)

/** Citation integrity plus conservative lexical/numeric evidence audit; not a semantic truth score. */
internal data class CitationAudit(
    val citedLabels: List<String> = emptyList(),
    val unknownLabels: List<String> = emptyList(),
    val uncitedLabels: List<String> = emptyList(),
    val noMatchingSources: Boolean = false,
    val invalidSourceLabels: List<String> = emptyList(),
    val claimFindings: List<ClaimEvidenceFinding> = emptyList()
) {
    val hasUnknownLabels: Boolean get() = unknownLabels.isNotEmpty()
    val hasSourceIntegrityIssues: Boolean get() = hasUnknownLabels || invalidSourceLabels.isNotEmpty()
    val noLexicalSupportCount: Int get() = claimFindings.count {
        it.status == ClaimEvidenceStatus.NO_LEXICAL_MATCH ||
            it.status == ClaimEvidenceStatus.UNKNOWN_SOURCE ||
            it.status == ClaimEvidenceStatus.UNSUPPORTED_NUMERIC
    }
    val uncitedClaimCount: Int get() = claimFindings.count { it.status == ClaimEvidenceStatus.UNCITED }
    val unsupportedNumericCount: Int get() = claimFindings.sumOf { it.unmatchedNumericValues.size }
}

internal enum class ClaimEvidenceStatus(val label: String) {
    LEXICAL_MATCH("Metinsel eşleşme"),
    WEAK_LEXICAL_MATCH("Zayıf eşleşme"),
    NO_LEXICAL_MATCH("Belirgin eşleşme yok"),
    UNCITED("Atıf yok"),
    UNKNOWN_SOURCE("Bilinmeyen kaynak"),
    UNSUPPORTED_NUMERIC("Kaynakta doğrulanamayan sayı/tarih")
}

internal data class ClaimEvidenceFinding(
    val claimExcerpt: String,
    val citedLabels: List<String>,
    val matchedLabels: List<String>,
    val bestLexicalOverlap: Double,
    val status: ClaimEvidenceStatus,
    val unmatchedNumericValues: List<String> = emptyList()
)

/** Citation metadata retained with an assistant answer so sources remain inspectable in chat history. */
internal data class LocalSourceReference(
    val label: String,
    val documentId: String,
    val documentName: String,
    val sectionNumber: Int,
    val startOffset: Int,
    val endOffset: Int,
    val excerpt: String = ""
)

internal enum class AssistantMode(
    val label: String,
    val shortDescription: String,
    val instructions: String
) {
    GENERAL(
        "Genel", "Günlük sorular, fikirler ve açıklamalar",
        "Soruyu doğrudan cevapla. Belirsizlik varsa belirt; önemli ayrıntıları yapılandırılmış ve anlaşılır anlat."
    ),
    CODING(
        "Kodlama", "Kod üretme, hata ayıklama ve teknik tasarım",
        "Kodlama asistanı gibi davran. Dili ve ortamı netleştir; çalışan, bütünlüklü örnek ver. Gerekli importları, hata durumlarını ve güvenlik etkilerini düşün. Emin olmadığın API veya sürümü uydurma; test edilmemiş kodu test edilmiş gibi sunma."
    ),
    STUDY(
        "Öğrenme", "Kavramları anlaşılır adımlarla öğren",
        "Sabırlı bir öğretmen gibi açıkla. Önce kavramı basitleştir, sonra örnek ver. Karmaşık sorularda adımları göster ve yaygın hataları belirt. Öğrencinin öğrenmesine yardımcı ol."
    ),
    WRITING(
        "Yazma", "Metin, plan, özet ve düzenleme",
        "Yazı asistanı gibi çalış. Kullanıcının amacına ve istediği tona uy. Gerektiğinde önce kullanılabilir bir taslak ver; uydurma kaynak veya alıntı üretme."
    ),
    ANALYSIS(
        "Analiz", "Karşılaştırma, plan ve karar desteği",
        "Analist gibi çalış. Varsayımları, artıları, eksileri ve riskleri ayır. Bilinenlerle tahminleri karıştırma; eksik veri varsa açıkça söyle. Sonunda uygulanabilir bir öneri ver."
    );

    companion object {
        fun fromStored(value: String?): AssistantMode =
            entries.firstOrNull { it.name == value } ?: GENERAL
    }
}

internal data class LocalDocument(
    val id: String = UUID.randomUUID().toString(),
    val displayName: String,
    val storedFileName: String,
    val bytes: Long,
    val characterCount: Int,
    val importedAt: Long = System.currentTimeMillis(),
    /** SHA-256 of sanitized UTF-8 extracted text; blank only for legacy P2 metadata. */
    val contentHash: String = "",
    val mimeType: String = "text/plain",
    val pageCount: Int? = null,
    /** Slide count for PPTX or worksheet count for XLSX; separate from PDF pages. */
    val sectionCount: Int? = null,
    val extractionMethod: String = "utf8_text",
    val extractionWarnings: List<String> = emptyList()
)

internal data class ChatThread(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Yeni sohbet",
    val updatedAt: Long = System.currentTimeMillis(),
    val messages: List<ChatMessage> = emptyList(),
    val mode: AssistantMode = AssistantMode.GENERAL,
    val documents: List<LocalDocument> = emptyList()
)

internal data class LocalModel(
    val name: String,
    val path: File,
    val bytes: Long,
    val isActive: Boolean
)

internal enum class BackendPreference(val label: String) {
    AUTO("Otomatik"), CPU("CPU"), GPU("GPU");

    companion object {
        fun fromStored(value: String?): BackendPreference =
            entries.firstOrNull { it.name == value } ?: AUTO
    }
}

internal data class ModelCatalogItem(
    val id: String,
    val title: String,
    val fileName: String,
    val approxBytes: Long,
    val contextTokens: Int,
    val license: String,
    val description: String,
    val recommendedBackend: BackendPreference,
    val minimumSuggestedRamBytes: Long,
    val downloadUrl: String,
    /** Publisher SHA-256 pinned from the exact LiteRT Community model artifact. */
    val expectedSha256: String
) {
    fun formattedSize(): String = if (approxBytes >= 1_073_741_824L) {
        String.format(Locale("tr", "TR"), "%.2f GB", approxBytes / 1_073_741_824.0)
    } else {
        String.format(Locale("tr", "TR"), "%.0f MB", approxBytes / 1_048_576.0)
    }
}

internal object ModelCatalog {
    // File sizes, model names and license labels follow the LiteRT Community model cards.
    // Memory is a conservative recommendation, not a device-specific guarantee.
    val items = listOf(
        ModelCatalogItem(
            id = "qwen06-int4",
            title = "Qwen3 0.6B INT4",
            fileName = "Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm",
            approxBytes = 329L * 1_048_576L,
            contextTokens = 4096,
            license = "Apache-2.0",
            description = "En küçük katalog seçeneği. Hız ve bellek kullanımı cihazına ve arka uca bağlıdır.",
            recommendedBackend = BackendPreference.AUTO,
            minimumSuggestedRamBytes = 2_000_000_000L,
            downloadUrl = "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm?download=true",
            expectedSha256 = "03e7da1eb1108b50dffaa9bb52cc7bcbad2eb0c66ca990267f480c1e545d2856"
        ),
        ModelCatalogItem(
            id = "qwen06-int8",
            title = "Qwen3 0.6B INT8",
            fileName = "Qwen3-0.6B.litertlm",
            approxBytes = 586L * 1_048_576L,
            contextTokens = 4096,
            license = "Apache-2.0",
            description = "Başlangıç için dengeli model; düşük RAM'li cihazlarda yine de ağır gelebilir.",
            recommendedBackend = BackendPreference.CPU,
            minimumSuggestedRamBytes = 3_000_000_000L,
            downloadUrl = "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm?download=true",
            expectedSha256 = "c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108"
        ),
        ModelCatalogItem(
            id = "qwen17-int4",
            title = "Qwen3 1.7B INT4",
            fileName = "Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm",
            approxBytes = 932L * 1_048_576L,
            contextTokens = 4096,
            license = "Apache-2.0",
            description = "Daha büyük model; daha fazla bellek ve uygun cihazda GPU ile deneme önerilir.",
            recommendedBackend = BackendPreference.GPU,
            minimumSuggestedRamBytes = 4_000_000_000L,
            downloadUrl = "https://huggingface.co/litert-community/Qwen3-1.7B/resolve/main/Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm?download=true",
            expectedSha256 = "2a72330b504a6596d53a2c00923c57173b10f1b83e6a541213ffec08d1fc5de8"
        )
    )

    fun byFileName(name: String): ModelCatalogItem? = items.firstOrNull { it.fileName == name }
}

internal data class DeviceProfile(
    val totalRamBytes: Long,
    val availableRamBytes: Long,
    val freeStorageBytes: Long
) {
    val totalRamGb: Double get() = totalRamBytes / 1_073_741_824.0
    val availableRamGb: Double get() = availableRamBytes / 1_073_741_824.0
    val freeStorageGb: Double get() = freeStorageBytes / 1_073_741_824.0
    val shouldWarnForQwen: Boolean get() = totalRamBytes < 5_500_000_000L || availableRamBytes < 2_500_000_000L

    fun summary(): String {
        val format = DecimalFormat("0.0", DecimalFormatSymbols.getInstance(Locale("tr", "TR")))
        return "RAM: ${format.format(totalRamGb)} GB toplam / ${format.format(availableRamGb)} GB boş\n" +
            "Depolama: ${format.format(freeStorageGb)} GB boş"
    }

    companion object {
        fun read(context: Context): DeviceProfile {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memory = ActivityManager.MemoryInfo()
            manager.getMemoryInfo(memory)
            val stat = StatFs(context.filesDir.absolutePath)
            return DeviceProfile(
                totalRamBytes = memory.totalMem,
                availableRamBytes = memory.availMem,
                freeStorageBytes = stat.availableBytes
            )
        }
    }
}
