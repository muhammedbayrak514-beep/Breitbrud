package com.breitbrut5.ai

import java.util.Locale

/** Small deterministic search over locally stored conversation metadata and user-visible content. */
internal object ChatSearch {
    fun matches(thread: ChatThread, rawQuery: String): Boolean {
        val query = normalize(rawQuery)
        if (query.isBlank()) return true
        if (normalize(thread.title).contains(query)) return true
        if (thread.messages.any { normalize(it.text).contains(query) }) return true
        return thread.documents.any { normalize(it.displayName).contains(query) }
    }

    fun matchingPreview(thread: ChatThread, rawQuery: String): String? {
        val query = normalize(rawQuery)
        if (query.isBlank()) return null
        return thread.messages.firstOrNull { normalize(it.text).contains(query) }
            ?.text
            ?.replace('\n', ' ')
            ?.let { text ->
                val index = normalize(text).indexOf(query).coerceAtLeast(0)
                val start = (index - 36).coerceAtLeast(0)
                val end = (index + query.length + 60).coerceAtMost(text.length)
                (if (start > 0) "…" else "") + text.substring(start, end) + if (end < text.length) "…" else ""
            }
    }

    private fun normalize(value: String): String = value.trim().lowercase(TURKISH_LOCALE)

    private val TURKISH_LOCALE: Locale = Locale("tr", "TR")
}
