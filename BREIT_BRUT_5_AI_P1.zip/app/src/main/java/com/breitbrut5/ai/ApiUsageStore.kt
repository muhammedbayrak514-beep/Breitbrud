package com.breitbrut5.ai

import android.content.Context

/** Local-only API telemetry. No prompts, answers, document text, keys, or raw errors are stored. */
internal data class ApiUsageSnapshot(
    val requestAttempts: Long = 0,
    val successfulTurns: Long = 0,
    val failedTurns: Long = 0,
    val cancelledTurns: Long = 0,
    val inputCharacters: Long = 0,
    val outputCharacters: Long = 0,
    val estimatedInputTokens: Long = 0,
    val estimatedOutputTokens: Long = 0,
    val lastRequestAt: Long = 0
) {
    val completedTurns: Long get() = successfulTurns + failedTurns + cancelledTurns
}

internal object ApiUsageMath {
    /** A rough UI estimate only. Provider billing/tokenizer values are not available in this app. */
    fun estimateTokens(characterCount: Long): Long {
        val chars = characterCount.coerceAtLeast(0L)
        return (chars / 4L) + if (chars % 4L == 0L) 0L else 1L
    }
}

internal class ApiUsageStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("breit_brut_api_usage", Context.MODE_PRIVATE)

    @Synchronized
    fun load(): ApiUsageSnapshot = ApiUsageSnapshot(
        requestAttempts = prefs.getLong(KEY_ATTEMPTS, 0).coerceAtLeast(0),
        successfulTurns = prefs.getLong(KEY_SUCCESS, 0).coerceAtLeast(0),
        failedTurns = prefs.getLong(KEY_FAILED, 0).coerceAtLeast(0),
        cancelledTurns = prefs.getLong(KEY_CANCELLED, 0).coerceAtLeast(0),
        inputCharacters = prefs.getLong(KEY_INPUT_CHARS, 0).coerceAtLeast(0),
        outputCharacters = prefs.getLong(KEY_OUTPUT_CHARS, 0).coerceAtLeast(0),
        estimatedInputTokens = prefs.getLong(KEY_INPUT_TOKENS, 0).coerceAtLeast(0),
        estimatedOutputTokens = prefs.getLong(KEY_OUTPUT_TOKENS, 0).coerceAtLeast(0),
        lastRequestAt = prefs.getLong(KEY_LAST_REQUEST, 0).coerceAtLeast(0)
    )

    @Synchronized
    fun recordAttempt() {
        prefs.edit()
            .putLong(KEY_ATTEMPTS, load().requestAttempts + 1)
            .putLong(KEY_LAST_REQUEST, System.currentTimeMillis())
            .apply()
    }

    @Synchronized
    fun recordTurn(inputCharacters: Long, outputCharacters: Long, outcome: String) {
        val current = load()
        val input = inputCharacters.coerceAtLeast(0)
        val output = outputCharacters.coerceAtLeast(0)
        val editor = prefs.edit()
            .putLong(KEY_INPUT_CHARS, current.inputCharacters + input)
            .putLong(KEY_OUTPUT_CHARS, current.outputCharacters + output)
            .putLong(KEY_INPUT_TOKENS, current.estimatedInputTokens + ApiUsageMath.estimateTokens(input))
            .putLong(KEY_OUTPUT_TOKENS, current.estimatedOutputTokens + ApiUsageMath.estimateTokens(output))
        when (outcome) {
            InferenceSample.OUTCOME_SUCCESS -> editor.putLong(KEY_SUCCESS, current.successfulTurns + 1)
            InferenceSample.OUTCOME_CANCELLED -> editor.putLong(KEY_CANCELLED, current.cancelledTurns + 1)
            else -> editor.putLong(KEY_FAILED, current.failedTurns + 1)
        }
        editor.apply()
    }

    @Synchronized
    fun clear() {
        prefs.edit().clear().apply()
    }

    private companion object {
        const val KEY_ATTEMPTS = "request_attempts"
        const val KEY_SUCCESS = "successful_turns"
        const val KEY_FAILED = "failed_turns"
        const val KEY_CANCELLED = "cancelled_turns"
        const val KEY_INPUT_CHARS = "input_characters"
        const val KEY_OUTPUT_CHARS = "output_characters"
        const val KEY_INPUT_TOKENS = "estimated_input_tokens"
        const val KEY_OUTPUT_TOKENS = "estimated_output_tokens"
        const val KEY_LAST_REQUEST = "last_request_at"
    }
}
