# P1 implementation and validation report — BREIT BRUT 5 AI 0.19.0

## Implemented changes

### 1. Local chat search
- Added `ChatSearch.kt` with deterministic, on-device search across conversation title, message text, and attached document display names.
- Added Turkish-locale case folding so queries with `İ/I/ı/i` behave consistently for Turkish text.
- History UI displays a bounded matching-message preview. Blank search leaves all chats visible.

### 2. Conversation editing
- Chat titles can be renamed from the history sheet. Empty titles are rejected; titles are normalized and limited to 80 characters.
- User messages can be edited. On confirmation, the selected user message and all subsequent turns are removed; the edited text is moved to the composer and is not sent automatically. This avoids retaining assistant answers that belong to the old prompt.

### 3. Quick / Balanced / Deep response profiles
- Added `ResponseProfile.kt` with persisted `FAST`, `BALANCED`, and `DEEP` profiles.
- Profiles affect user-facing system instructions, bounded history message/character budgets, local sampler values, API `temperature`, and output token budget.
- The effective output ceiling is the lower of the user's configured token limit and the selected profile maximum.
- Deep mode does not reveal hidden reasoning; it requests a more complete user-facing response. Actual model capability remains model-dependent.
- Some Chat Completions-compatible services may not support all optional sampling parameters; provider errors remain visible.

### 4. Visible document sources
- Preserved the RAG source references already present in the P0 base project and clarified the source-details UI.
- Answers can display the retrieved source label, document name, extracted section, character range, excerpt, and citation audit.
- Character/section offsets refer to extracted text. This release does not claim reliable PDF page-number mapping. Lexical citation checks do not prove semantic truth.

### 5. API use and privacy panel
- Added `ApiUsageStore.kt` to maintain device-local request-attempt and turn-outcome counters plus input/output character and rough token estimates.
- The store keeps only numeric counters/timestamps; it does not store prompt text, responses, document contents, API keys, endpoint paths, or raw errors.
- Token estimates use approximately one token per four characters. They are not provider tokenizer data, official usage values, or billing estimates.
- The settings panel displays current mode, endpoint host/model, local counters, estimated usage, data-flow explanation, and a reset control.
- Counter writes are best-effort and cannot prevent the actual API request from proceeding.
- The API connection test probe is not included in chat-request counters. Each retry attempt is counted separately; a user turn is counted once.

## Version and CI
- Android app version: `versionCode 19`, `versionName 0.19.0`.
- Workflow: `.github/workflows/android-ci.yml`.
- Workflow artifact names: `BREIT_BRUT_5_AI-P1-debug-APK` and `BREIT_BRUT_5_AI-P1-build-diagnostics`.
- Workflow accepts extracted Android sources directly, or selects the P1/P0/V9 project archive and extracts it in a clean temporary directory. It does not merge archive files into the checkout.
- APK upload is gated on dependency resolution, AAR metadata validation, unit tests, and successful `assembleDebug` plus a non-empty APK file.

## Validation performed in this environment

| Check | Result |
|---|---|
| Targeted pure-Kotlin P1 smoke suite | **27 assertions passed** |
| YAML parse | **Passed** |
| Workflow shell syntax | **10/10 Bash blocks passed `bash -n`** |
| CI gate/archive/artifact assertions | **Passed** |
| Gradle distribution bootstrap | **Not completed: DNS could not resolve `services.gradle.org`** |
| Android Gradle unit-test task | **Not run** |
| Full Android/Compose compilation | **Not run** |
| `assembleDebug` / APK install on device | **Not run** |

The smoke suite compiled the P1 core Kotlin files with `kotlinc` 1.9.0 and small Android API test stubs, then executed 27 assertions for Turkish chat search, preview behavior, response-profile budgets/fallback, profiled source prompts, token-estimate math, and API-counter persistence/reset behavior. This is a targeted core test only; it is not a substitute for the Android Gradle build or device validation.

A real `./gradlew --version` attempt failed before Gradle could start because the environment could not resolve `services.gradle.org`. Therefore this report does not claim that the Android app, Compose UI, Gradle unit tests, or APK build have passed. Run the included GitHub Actions workflow to perform those gates in a network-enabled Android runner.

## Manual acceptance checklist

1. Search chat history by title, message content, and attached document display name; verify Turkish uppercase/lowercase matching and bounded preview.
2. Rename a chat; blank title must be rejected, and a long title must be capped at 80 characters.
3. Edit a user message; verify that the selected message and subsequent turns are removed and edited text is moved to the composer without an automatic request.
4. Select each response profile, restart the app, and verify the selection persists.
5. Verify profile affects local sampler/context/output settings and API `temperature`/`max_tokens` inputs.
6. Ask a question that retrieves local document chunks and inspect filename, section/character range, excerpt, and citation-audit caveat. Confirm the UI does not display character offsets as PDF page numbers.
7. In API mode, verify the endpoint/model and estimated counters update after a chat request; retries increase attempts while one turn records one outcome.
8. Verify the API panel explains what context is sent to the configured HTTPS endpoint and that provider retention is controlled by provider policy.
9. Verify local mode explains that prompt/document inference remains on-device, while model downloads may use the network.
10. Reset counters and confirm only usage metrics are cleared, not chats, documents, model files, or API configuration.
