# P0 — Runtime reliability and model integrity

Release: `0.18.0` (`versionCode = 18`)

This document records the P0 reliability changes in the application source. It distinguishes publisher verification for official catalog downloads from local change detection for user-imported files.

## 1. Model response diagnostics

`AiFailureDiagnostics.kt` defines stable, privacy-safe categories and Turkish user guidance for:

- `memory_pressure`
- `network_unavailable`, `network_timeout`, `network_connection`
- `api_authentication`, `api_rate_limited`, `api_transient_failure`, `api_server_error`
- `invalid_api_endpoint`, `api_tls_failure`
- `model_integrity`, `model_or_file_failure`, `runtime_incompatible`, `backend_failure`
- `empty_response`, `generation_interrupted`, and the general `inference_failure`

Model initialization catches both ordinary exceptions and `LinkageError`; generation catches RAM pressure and runtime linkage incompatibility rather than leaving an empty assistant message. Existing local first-token and total-generation guards remain at 120 seconds and 300 seconds respectively. Performance telemetry stores bounded event categories and timing/outcome data, not prompts, completions, document contents, API keys or raw exception messages.

## 2. Stop and retry behavior

- Local generation calls the LiteRT-LM conversation cancellation API and waits for the runtime's terminal callback before normal state recovery. A watchdog keeps the UI locked if native cancellation does not complete promptly.
- API generation disconnects the active HTTP request and cancels the response coroutine. A partial answer is retained and is not automatically replayed.
- `ApiRetryPolicy` permits at most two retries for HTTP 408, 425, 429, 500, 502, 503 and 504, or selected socket/connection/EOF failures. DNS failures, TLS failures, arbitrary local I/O failures and any failure after streamed answer text are not retried.
- Retry delay uses bounded exponential backoff or `Retry-After` (delta-seconds / RFC-1123 date), capped at 15 seconds per wait. The whole API request remains bounded by the existing overall timeout.
- Manual retry remains user initiated; cancelling a request does not silently start another request.

## 3. Safe model download and atomic installation

`ChatViewModel.downloadModel` and `downloadEmbeddingModel` write to a sibling `.part` file. They enforce HTTPS (for the catalog download), successful HTTP status, a minimum expected size, and exact `Content-Length` when the server reports one. The output stream is flushed and `FileDescriptor.sync()` is called before verification.

`VerifiedModelFileInstaller` then:

1. Verifies that the partial and target are in the same canonical directory.
2. Computes SHA-256 over the complete partial file.
3. Compares the result with the expected publisher pin.
4. Promotes the verified bytes using same-directory `ATOMIC_MOVE` + `REPLACE_EXISTING`.
5. Refuses an unsupported atomic move rather than falling back to a delete/copy sequence.
6. Records an atomic `.integrity` sidecar after promotion.

A mismatch, incomplete download, cancellation or unsupported atomic move leaves the prior target untouched. A failed/corrupt existing catalog model is hidden from the installed-model list and the UI offers a verified re-download; the original bytes are retained until a verified replacement is ready. Orphan `.part` / `.importing` files from a prior process are cleaned on startup and are never treated as installed models.

## 4. Publisher SHA-256 pins

The official model catalog now includes expected SHA-256 values for all automatic-download entries:

| Artifact | Expected SHA-256 | Source |
|---|---|---|
| Qwen3 0.6B dynamic INT4 | `03e7da1eb1108b50dffaa9bb52cc7bcbad2eb0c66ca990267f480c1e545d2856` | [LiteRT Community Qwen3-0.6B main-branch file history](https://huggingface.co/litert-community/Qwen3-0.6B/discussions/13/files) |
| Qwen3 0.6B INT8 | `c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108` | [LiteRT Community Qwen3-0.6B file page](https://huggingface.co/litert-community/Qwen3-0.6B/blob/main/Qwen3-0.6B.litertlm) |
| Qwen3 1.7B dynamic INT4 | `2a72330b504a6596d53a2c00923c57173b10f1b83e6a541213ffec08d1fc5de8` | [LiteRT Community Qwen3-1.7B commit](https://huggingface.co/litert-community/Qwen3-1.7B/commit/87603f0ff3fe74b9b77ed0477edb773b4b596f32) |
| EmbeddingGemma 2 text 270M | `2d079ee2f6f066b1f368e8d7c819f55214eaef1d0513b312321901f30ab286fb` | [LiteRT Community EmbeddingGemma file page](https://huggingface.co/litert-community/embeddinggemma-2-text-270m-litert-lm/blob/main/embeddinggemma-2-text-270m.litertlm) |

Important pinning note: at the time of this source audit, the newer Qwen3 0.6B INT4 SHA `96491...` appeared in a proposed change from `refs/pr/13`, while the application's URL downloads from `refs/heads/main`. The source diff showed the prior main-branch pointer as `03e7...`; the app therefore pins the hash matching the URL it actually uses, not the proposed PR artifact. Re-check and deliberately update both URL and pin if the upstream main branch changes.

Official catalog loads re-check the publisher hash on first validation in each app process. A local `.integrity` or `.verified` file alone cannot override a mismatched publisher pin. User-imported `.litertlm` files have no publisher pin; they receive a local fingerprint that detects later changes but does not certify provenance.

## 5. CI build/test gate

`.github/workflows/android-ci.yml` supports either:

- Kotlin DSL Android source committed at the repository root, or
- `BREIT_BRUT_5_AI_P0.zip` (with the legacy V9 archive fallback) extracted into a clean runner-temporary directory.

The workflow checks ZIP paths, duplicate entries, links, CRC, entry count and expanded size; does not overlay ZIP contents over the checkout; verifies pinned Gradle settings; resolves runtime dependencies; runs `checkDebugAarMetadata`; runs `testDebugUnitTest`; then runs `assembleDebug` only if the earlier gates pass. Debug APK packaging/upload requires zero exit codes and a non-empty APK. Diagnostics and Gradle test reports are uploaded on failure. The workflow's final summary fails the job if any required gate fails or no APK exists.

## 6. Tests added/updated

- `AiFailureDiagnosticsTest`: 10 targeted test methods covering stable categories, no retry for auth/DNS/TLS/arbitrary I/O or unsupported HTTP 4xx, transient HTTP and socket retries, no retry after partial output, bounded retry budget, and both `Retry-After` forms.
- `VerifiedModelFileInstallerTest`: 5 methods; checksum mismatch, incomplete download and cancellation before promotion leave the existing target unchanged; valid bytes are atomically promoted and trusted metadata is written; imported artifacts are marked local-only.
- `ModelArtifactIntegrityTest`: 7 methods covering publisher pin, pin mismatch, local-vs-publisher trust precedence, sidecar migration and same-size content mutation.
- `ModelCatalogIntegrityTest`: 4 methods verifying every auto-downloaded catalog artifact and EmbeddingGemma has a 64-character SHA pin and HTTPS URL.

Total targeted result in this run: **26/26 methods passed** (22 helper/integrity methods plus 4 catalog methods). These were compiled with `kotlinc` and executed using a lightweight JUnit-compatible harness; they are not a substitute for `:app:testDebugUnitTest` on the complete Android project.

## 7. Verification boundary

Targeted Kotlin helper compilation and targeted test methods are run in the development container. This is not a substitute for the complete Android Gradle test task, Android packaging, LiteRT native initialization, or physical-device inference. The development container used for this run does not include the Android SDK or a configured Gradle installation. The GitHub Actions workflow must complete successfully before the debug APK can be called build-verified; actual local model load/generation and cancellation behavior must additionally be checked on an Android device.
