# P1 — Daha akıllı günlük kullanım (v0.19.0)

## Bu sürümde eklenenler

### 1. Sohbet arama
- Geçmiş ekranına yerel arama alanı eklendi.
- Başlık, mesaj gövdesi ve sohbetin ekli belge adlarında arama yapılır.
- Karşılaştırma büyük/küçük harf duyarsızdır; içerik aramasında eşleşen mesajdan kısa bir önizleme gösterilir.
- Arama yalnızca cihazda kayıtlı sohbet verisini tarar; uzak arama servisi yoktur.

### 2. Sohbet düzenleme
- Sohbet başlığı geçmiş listesindeki düzenle simgesiyle değiştirilebilir; başlık en fazla 80 karakterdir ve boş başlık reddedilir.
- Kullanıcı mesajı düzenlenebilir. Kullanıcı onayı sonrasında seçilen mesaj ve sonraki mesajlar sohbetten çıkarılır, düzenlenmiş metin mesaj kutusuna taşınır.
- Düzenlenmiş metin kendiliğinden gönderilmez. Kullanıcı göndermeden önce yeniden düzenleyebilir. Bu davranış, eski assistant yanıtlarının farklı bir prompt'a aitmiş gibi görünmesini önler.

### 3. Hızlı / Dengeli / Derin yanıt profilleri
- Profil tercihi SharedPreferences içinde saklanır ve uygulama yeniden açıldığında korunur.
- Profil; sistem prompt yönergesini, örnekleme parametrelerini, bağlam geçmişi mesaj/karakter bütçesini ve önerilen çıktı token sınırını değiştirir.
- Hızlı: daha kısa bağlam, düşük çıktı bütçesi ve kısa yanıt talimatı.
- Dengeli: günlük kullanım için orta bağlam ve çıktı bütçesi.
- Derin: daha geniş geçmiş, 1024 token önerisi ve varsayım/sınırlama/uygulanabilir adımları ayrı ele alan yanıt talimatı.
- Kullanıcı çıktı sınırı profilden ayrı bir üst sınırdır; etkin sınır iki değerin küçüğüdür. Profil seçmek önerilen başlangıç üst sınırını da kaydeder.
- Profil “gizli düşünce” üretimini etkinleştirmez. Derin profil, daha uzun bağlam ve daha kapsamlı kullanıcıya dönük gerekçe talep eder; gerçek yanıt kalitesi modelin kapasitesine bağlıdır.
- API isteğinde Chat Completions uyumlu `temperature` ve `max_tokens` alanları gönderilir. Sağlayıcı/model bu alanları reddederse hata API sağlayıcısından kaynaklanabilir.

### 4. Belgelerde gösterilebilir kaynaklar
- Önceki sürümden gelen RAG kaynak referansları ve denetim verisi korunmuştur.
- Yerel ve API yanıtlarının her birinde getirilen belge parçaları `[S1]`, `[S2]` etiketleriyle cevap mesajına bağlanır.
- Sohbet balonunda dosya adı, bölüm numarası, çıkarılmış metin karakter aralığı ve kaynak alıntısı açılabilir.
- Kaynak bütünlüğü / atıf denetimi ayrıca gösterilir. Bu denetim metinsel eşleşme kontrolüdür; semantik doğruluk garantisi değildir.
- PDF ve Office kaynak konumu çıkarılmış metindeki bölüm/karakter aralığıdır. Bu sürüm her referans için gerçek PDF sayfa eşlemesi iddia etmez.

### 5. API kullanım ve gizlilik paneli
- API istek denemeleri, başarılı/başarısız/iptal edilen turlar, giriş/çıkış karakter sayıları ve yaklaşık token sayıları yerel `SharedPreferences` alanında saklanır.
- Token tahmini yaklaşık karakter/4 hesabıdır; gerçek tokenizer sonucu, sağlayıcı usage alanı veya fatura tahmini değildir.
- Kullanım sayaçları prompt, yanıt, belge içeriği, API anahtarı veya ham hata metni saklamaz; sadece sayısal özetleri saklar.
- Sayaçlar kullanıcı tarafından panelden sıfırlanabilir.
- Panel aktif çalışma modunu, endpoint host adını ve model kimliğini gösterir. API modunda mevcut istem, sınırlı sohbet geçmişi ve getirilen yerel belge parçaları seçilen HTTPS endpoint'e gönderilir. Cihazda modunda sohbet/ belge içeriği model çıkarımı için cihazdan gönderilmez; model indirme yine ağ kullanabilir.
- Sağlayıcının veri saklama/işleme koşulları kendi politikasına bağlıdır; uygulama bunu garanti etmez.

## Önemli sınırlar
- API token sayıları kesin değildir; sağlayıcı tarafından döndürülen gerçek usage değerleri bu sürümde ayrıştırılmıyor.
- API kullanım kaydı yalnızca uygulamanın yaptığı chat streaming çağrılarını sayar; “Bağlantıyı test et” probe'u bu sayaçlara dahil değildir.
- API yeniden deneme denemeleri istek denemesi sayacını artırır; bir kullanıcı turu ise tek sonuç olarak sayılır.
- Yanıt profilleri otomatik model değişikliği, API fallback veya gerçek düşünme modu değildir.
