package com.breitbrut5.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF10131A)
private val Panel = Color(0xFF1B202B)
private val PanelRaised = Color(0xFF252C39)
private val Accent = Color(0xFF8B6CFF)
private val TextMain = Color(0xFFF3F4FA)
private val Muted = Color(0xFFA2ACBC)
private val Danger = Color(0xFFFF7F86)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BreitBrutApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BreitBrutApp(vm: ChatViewModel = viewModel()) {
    var showHistory by remember { mutableStateOf(false) }
    var showModels by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showModes by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var extractionWarningDocument by remember { mutableStateOf<LocalDocument?>(null) }
    val localContext = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            showModels = false
            vm.importModel(uri)
        }
    }
    var replaceDocumentId by remember { mutableStateOf<String?>(null) }
    val multiContextDocumentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            replaceDocumentId = null
            vm.importContextDocuments(uris)
        }
    }
    val contextDocumentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val documentId = replaceDocumentId
        replaceDocumentId = null
        if (uri != null) {
            if (documentId == null) vm.importContextDocument(uri)
            else vm.replaceContextDocument(documentId, uri)
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Ink,
            surface = Panel,
            onBackground = TextMain,
            onSurface = TextMain,
            error = Danger
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                            Text("BREİT BRUT 5 AI", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                text = "${vm.activeMode.label} modu • " + when {
                                    vm.isDownloading -> "Model indiriliyor"
                                    vm.isModelLoading -> "Model hazırlanıyor"
                                    vm.isEmbeddingLoading -> "Anlamsal arama hazırlanıyor"
                                    vm.isImportingContext -> "Yerel belge işleniyor"
                                    vm.modelReady -> "Yerel yapay zekâ aktif"
                                    else -> "API anahtarı yok • yerel çalışma"
                                },
                                color = Muted,
                                fontSize = 11.sp
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { showHistory = true }) {
                            Icon(Icons.Default.Menu, contentDescription = "Sohbet geçmişi", tint = TextMain)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showModes = true }, enabled = !vm.isWorking && !vm.isStopping) {
                            Icon(Icons.Default.Tune, contentDescription = "Asistan modu", tint = Accent)
                        }
                        IconButton(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, vm.exportActiveChat())
                                }
                                localContext.startActivity(Intent.createChooser(shareIntent, "BREİT BRUT sohbetini paylaş"))
                            },
                            enabled = vm.messages.isNotEmpty()
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Sohbeti paylaş", tint = TextMain)
                        }
                        IconButton(onClick = { showModels = true }) {
                            Icon(Icons.Default.Memory, contentDescription = "Yerel modeller", tint = if (vm.modelReady) Accent else TextMain)
                        }
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Ayarlar", tint = TextMain)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink, titleContentColor = TextMain)
                )
            },
            bottomBar = {
                Composer(
                    value = vm.draft,
                    onValueChange = { vm.draft = it },
                    onSend = { vm.send() },
                    enabled = !vm.isWorking,
                    focusManager = LocalFocusManager.current,
                    onModels = { showModels = true },
                    onContextDocuments = {
                        replaceDocumentId = null
                        multiContextDocumentPicker.launch(arrayOf(
                            "application/pdf",
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            "text/plain", "text/markdown", "text/csv", "application/json", "application/xml",
                            "text/html", "text/css", "text/javascript", "text/x-java-source", "text/x-python",
                            "image/png", "image/jpeg", "image/webp", "image/bmp", "*/*"
                        ))
                    }
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                StatusPanel(
                    status = vm.status,
                    modelReady = vm.modelReady,
                    isWorking = vm.isWorking,
                    backendLabel = vm.activeBackendLabel,
                    canStop = vm.busy && !vm.isStopping,
                    isStopping = vm.isStopping,
                    stopTimedOut = vm.stopTimedOut,
                    onStop = { vm.stopGeneration() },
                    onModels = { showModels = true }
                )
                if (vm.activeDocuments.isNotEmpty()) {
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(vm.activeDocuments, key = { it.id }) { document ->
                            Surface(color = PanelRaised, shape = RoundedCornerShape(12.dp)) {
                                Row(
                                    Modifier.widthIn(max = 230.dp).padding(start = 9.dp, end = 2.dp, top = 3.dp, bottom = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Description, contentDescription = null, tint = Accent, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text(
                                        document.displayName + when {
                                            document.pageCount != null -> " • ${document.pageCount} sayfa"
                                            document.mimeType.endsWith("presentationml.presentation") -> " • ${document.sectionCount ?: 0} slayt"
                                            document.mimeType.endsWith("spreadsheetml.sheet") -> " • ${document.sectionCount ?: 0} çalışma sayfası"
                                            document.mimeType.endsWith("wordprocessingml.document") -> " • DOCX"
                                            document.mimeType == "application/pdf" -> " • PDF"
                                            document.mimeType.startsWith("image/") -> " • OCR"
                                            else -> ""
                                        },
                                        color = TextMain, fontSize = 10.sp, maxLines = 1, modifier = Modifier.weight(1f)
                                    )
                                    if (document.extractionWarnings.isNotEmpty()) {
                                        IconButton(onClick = { extractionWarningDocument = document }, modifier = Modifier.size(28.dp)) {
                                            Icon(Icons.Default.Info, contentDescription = "Belge içe aktarma uyarıları", tint = Color(0xFFFFC36E), modifier = Modifier.size(15.dp))
                                        }
                                    }
                                    IconButton(
                                        onClick = {
                                            replaceDocumentId = document.id
                                            contextDocumentPicker.launch(arrayOf(
                                                "application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                                "text/plain", "text/markdown", "text/csv", "application/json", "application/xml",
                                                "text/html", "text/css", "text/javascript", "text/x-java-source", "text/x-python",
                                                "image/png", "image/jpeg", "image/webp", "image/bmp", "*/*"
                                            ))
                                        },
                                        enabled = !vm.isWorking && !vm.isStopping,
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Refresh, contentDescription = "Yerel belgeyi güncelle", tint = Accent, modifier = Modifier.size(15.dp))
                                    }
                                    IconButton(onClick = { vm.removeContextDocument(document.id) }, enabled = !vm.isWorking && !vm.isStopping, modifier = Modifier.size(28.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = "Belgeyi bağlamdan çıkar", tint = Muted, modifier = Modifier.size(15.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                if (vm.errorText != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF3A2028))
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                            Text(vm.errorText.orEmpty(), color = Color(0xFFFFDDE0), fontSize = 12.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { vm.dismissError() }) { Text("Kapat", color = Color.White) }
                        }
                    }
                }
                if (vm.messages.isEmpty() && !vm.modelReady) {
                    WelcomePanel(
                        onImport = { picker.launch(arrayOf("application/octet-stream", "*/*")) },
                        onModels = { showModels = true }
                    )
                } else if (vm.messages.isEmpty() && vm.modelReady) {
                    EmptyChatPanel()
                }
                val listState = rememberLazyListState()
                LaunchedEffect(vm.messages.size, vm.messages.lastOrNull()?.text?.length) {
                    if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(vm.messages, key = { it.id }) { message ->
                        val canRetry = !vm.busy && !message.isUser && vm.messages.lastOrNull()?.id == message.id && vm.messages.any { it.isUser }
                        MessageBubble(
                            message = message,
                            canRetry = canRetry,
                            onRetry = { vm.retryLastResponse() },
                            onCopy = { clipboard.setText(AnnotatedString(message.text)) }
                        )
                    }
                    if (vm.busy) {
                        item(key = "typing-status") {
                            Row(Modifier.padding(start = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = Accent)
                                Spacer(Modifier.width(8.dp))
                                Text("BREİT BRUT 5 AI yanıt oluşturuyor…", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        if (showHistory) {
            ModalBottomSheet(onDismissRequest = { showHistory = false }, containerColor = Panel, contentColor = TextMain) {
                HistorySheet(
                    threads = vm.threads,
                    activeId = vm.activeThreadId,
                    disabled = vm.isWorking,
                    onNewChat = { vm.newChat(); showHistory = false },
                    onSelect = { vm.selectThread(it); showHistory = false },
                    onDelete = { vm.deleteThread(it) }
                )
            }
        }
        if (showModes) {
            ModalBottomSheet(onDismissRequest = { showModes = false }, containerColor = Panel, contentColor = TextMain) {
                AssistantModeSheet(
                    selected = vm.activeMode,
                    disabled = vm.isWorking || vm.isStopping,
                    onSelect = { mode -> vm.setAssistantMode(mode); showModes = false }
                )
            }
        }
        if (showModels) {
            ModalBottomSheet(onDismissRequest = { if (!vm.isDownloading) showModels = false }, containerColor = Panel, contentColor = TextMain) {
                ModelManagerSheet(
                    vm = vm,
                    onImport = { picker.launch(arrayOf("application/octet-stream", "*/*")) },
                    onClose = { if (!vm.isDownloading) showModels = false }
                )
            }
        }
        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                containerColor = Panel,
                titleContentColor = TextMain,
                textContentColor = Muted,
                title = { Text("Ayarlar", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Yanıt uzunluğu: ${vm.maxOutputTokens} token", color = TextMain, fontWeight = FontWeight.SemiBold)
                        Slider(
                            value = vm.maxOutputTokens.toFloat(),
                            onValueChange = { vm.setMaxOutputTokens(it.toInt() / 128 * 128) },
                            valueRange = 128f..1024f,
                            steps = 6
                        )
                        Text("Daha yüksek değerler daha uzun yanıt üretebilir; RAM kullanımını ve yanıt süresini artırabilir.")
                        Divider(color = Color(0xFF3A4250))
                        Text("Gizlilik", color = TextMain, fontWeight = FontWeight.SemiBold)
                        Text("Sohbet geçmişi cihazında tutulur. Model yanıtları yerel olarak üretilir. İnternet yalnızca sen model indirmeyi başlatırsan kullanılır; sohbet metinleri sunucuya gönderilmez.")
                        Text("Aktif model: ${vm.activeModelName ?: "Yüklenmedi"}")
                        Text("Arka uç tercihi: ${vm.backendPreference.label} • aktif: ${vm.activeBackendLabel}")
                        Text("Belge araması: ${vm.embeddingStatus}")
                        Text(vm.deviceProfile.summary())
                    }
                },
                confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Tamam") } },
                dismissButton = {
                    TextButton(onClick = { confirmClear = true; showSettings = false }) { Text("Sohbeti temizle", color = Danger) }
                }
            )
        }
        extractionWarningDocument?.let { document ->
            AlertDialog(
                onDismissRequest = { extractionWarningDocument = null },
                containerColor = Panel,
                titleContentColor = TextMain,
                textContentColor = Muted,
                title = { Text("Belge içe aktarma uyarısı", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(document.displayName, color = TextMain, fontWeight = FontWeight.SemiBold)
                        document.extractionWarnings.forEach { warning -> Text("• $warning", color = Muted, fontSize = 13.sp, lineHeight = 18.sp) }
                    }
                },
                confirmButton = { TextButton(onClick = { extractionWarningDocument = null }) { Text("Tamam") } }
            )
        }
        if (confirmClear) {
            AlertDialog(
                onDismissRequest = { confirmClear = false },
                containerColor = Panel,
                title = { Text("Bu sohbet temizlensin mi?") },
                text = { Text("Bu sohbetin mesajları yerel geçmişten kaldırılır. Eklediğin yerel belgeler bu sohbette kalır. Diğer sohbetler etkilenmez.", color = Muted) },
                confirmButton = {
                    TextButton(onClick = { vm.clearCurrentChat(); confirmClear = false }) { Text("Temizle", color = Danger) }
                },
                dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Vazgeç") } }
            )
        }
    }
}

@Composable
private fun StatusPanel(
    status: String,
    modelReady: Boolean,
    isWorking: Boolean,
    backendLabel: String,
    canStop: Boolean,
    isStopping: Boolean,
    stopTimedOut: Boolean,
    onStop: () -> Unit,
    onModels: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)
            .background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(32.dp).background(Accent.copy(alpha = 0.16f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Memory, contentDescription = null, tint = Accent, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(status, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextMain)
            Text(
                if (modelReady) "$backendLabel üzerinde yerel çıkarım • sohbet cihazda kalır" else "Modeli yüklemeden gerçek yapay zekâ yanıtı üretilemez",
                fontSize = 10.sp,
                color = Muted
            )
            if (isStopping) {
                Text(
                    if (stopTimedOut) "İptal 12 saniyeyi aştı. Güvenlik için yeni işlem kilitli."
                    else "Native iptal onayı bekleniyor; güvenli toparlama yapılacak.",
                    fontSize = 10.sp,
                    color = Color(0xFFFFD18B)
                )
            }
        }
        if (canStop) {
            OutlinedButton(onClick = onStop, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp)) {
                Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(3.dp))
                Text("Durdur", fontSize = 11.sp)
            }
        } else if (isStopping) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Accent)
        } else if (!modelReady && !isWorking) {
            TextButton(onClick = onModels) { Text("Model seç") }
        }
    }
}

@Composable
private fun WelcomePanel(onImport: () -> Unit, onModels: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp)
            .background(Panel, RoundedCornerShape(22.dp)).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(64.dp).background(Accent.copy(alpha = 0.17f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Memory, contentDescription = null, tint = Accent, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text("Kendi yapay zekân. Kendi cihazında.", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = TextMain)
        Spacer(Modifier.height(8.dp))
        Text(
            "BREİT BRUT 5 AI, bulut sohbet API'si kullanmaz. İlk kullanımda bir yerel dil modeli yüklemen gerekir.",
            color = Muted, fontSize = 13.sp, lineHeight = 20.sp
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onModels, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
            Icon(Icons.Default.Memory, contentDescription = null)
            Spacer(Modifier.width(7.dp))
            Text("Model yöneticisini aç")
        }
        Spacer(Modifier.height(7.dp))
        TextButton(onClick = onImport) { Text("Cihazımdaki .litertlm dosyasını seç", color = Muted) }
    }
}

@Composable
private fun EmptyChatPanel() {
    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Ne üzerinde çalışalım?", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Bir soru sor, kod yazdır veya bir konuyu birlikte incele.", color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun MessageBubble(message: ChatMessage, canRetry: Boolean, onRetry: () -> Unit, onCopy: () -> Unit) {
    var showSourceDetails by remember(message.id) { mutableStateOf(false) }
    var showEvidenceAudit by remember(message.id) { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (message.isUser) Alignment.End else Alignment.Start
    ) {
        Column(
            Modifier.widthIn(max = 720.dp)
                .background(
                    color = when {
                        message.isUser -> Accent.copy(alpha = 0.23f)
                        message.isError -> Color(0xFF37232B)
                        else -> Panel
                    },
                    shape = RoundedCornerShape(18.dp)
                ).padding(horizontal = 14.dp, vertical = 11.dp)
        ) {
            if (!message.isUser) {
                Text(
                    if (message.isInterrupted) "BREİT BRUT 5 AI • YANIT DURDURULDU" else "BREİT BRUT 5 AI",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (message.isError) Danger else Accent
                )
                Spacer(Modifier.height(4.dp))
            }
            Text(
                text = message.text.ifBlank { "" },
                color = if (message.isError) Color(0xFFFFDDE0) else TextMain,
                fontSize = 14.sp,
                lineHeight = 21.sp
            )
            if (!message.isUser && !message.isError && message.sourceReferences.isNotEmpty()) {
                TextButton(
                    onClick = { showSourceDetails = !showSourceDetails },
                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                ) {
                    Text(
                        if (showSourceDetails) "Kaynak ayrıntılarını gizle" else "Kaynaklar (${message.sourceReferences.size})",
                        color = Accent,
                        fontSize = 11.sp
                    )
                }
                if (showSourceDetails) {
                    Column(
                        Modifier.fillMaxWidth().padding(top = 2.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        message.sourceReferences.forEach { source ->
                            Column(
                                Modifier.fillMaxWidth()
                                    .background(PanelRaised, RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                Text("${source.label} • ${source.documentName}", color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Bölüm ${source.sectionNumber} • karakter ${source.startOffset + 1}–${source.endOffset}",
                                    color = Muted,
                                    fontSize = 10.sp
                                )
                                if (source.excerpt.isNotBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    Text(source.excerpt, color = TextMain, fontSize = 10.sp, lineHeight = 14.sp, maxLines = 5)
                                }
                            }
                        }
                    }
                }
            }
            message.citationAudit?.let { audit ->
                Spacer(Modifier.height(4.dp))
                val auditText = when {
                    audit.noMatchingSources -> "Kaynak kontrolü: Bu soru için belge parçalarında eşleşme bulunamadı. Yanıtı belgeyle doğrulanmış kabul etme."
                    audit.hasSourceIntegrityIssues -> buildString {
                        append("Kaynak bütünlüğü uyarısı: ")
                        if (audit.unknownLabels.isNotEmpty()) append("geçersiz etiket ${audit.unknownLabels.joinToString()} ")
                        if (audit.invalidSourceLabels.isNotEmpty()) append("sohbete bağlı olmayan belge kimliği ${audit.invalidSourceLabels.joinToString()} ")
                    }
                    audit.citedLabels.isNotEmpty() -> "Kaynak etiketleri kontrol edildi: ${audit.citedLabels.joinToString()}. Aşağıdaki iddia denetimi yalnızca metinsel eşleşmeyi ölçer; anlamı veya doğruluğu kanıtlamaz."
                    audit.uncitedLabels.isNotEmpty() -> "Kaynak kontrolü: Getirilen kaynaklardan yanıtta açıkça atıf yapılmayanlar var: ${audit.uncitedLabels.joinToString()}."
                    else -> "Kaynak kontrolü tamamlandı; yanıtta kaynak atfı bulunamadı."
                }
                Text(
                    auditText,
                    color = if (audit.hasSourceIntegrityIssues || audit.noMatchingSources || audit.noLexicalSupportCount > 0) Color(0xFFFFD18B) else Muted,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
                if (audit.claimFindings.isNotEmpty()) {
                    TextButton(
                        onClick = { showEvidenceAudit = !showEvidenceAudit },
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                    ) {
                        Text(
                            if (showEvidenceAudit) "İddia denetimini gizle" else "İddia denetimi (${audit.claimFindings.size})",
                            color = Accent,
                            fontSize = 11.sp
                        )
                    }
                    if (showEvidenceAudit) {
                        Column(
                            Modifier.fillMaxWidth().padding(top = 2.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                "Bu ön kontrol kelime örtüşmesini ölçer. Benzer kelimeler iddianın doğru olduğunu kanıtlamaz; çelişki, olumsuzluk ve sayı doğrulaması sonraki aşamalardadır.",
                                color = Muted,
                                fontSize = 10.sp,
                                lineHeight = 14.sp
                            )
                            audit.claimFindings.take(10).forEach { finding ->
                                val statusColor = when (finding.status) {
                                    ClaimEvidenceStatus.LEXICAL_MATCH -> Color(0xFFB7E8C8)
                                    ClaimEvidenceStatus.WEAK_LEXICAL_MATCH -> Color(0xFFFFD18B)
                                    ClaimEvidenceStatus.NO_LEXICAL_MATCH,
                                    ClaimEvidenceStatus.UNCITED,
                                    ClaimEvidenceStatus.UNKNOWN_SOURCE,
                                    ClaimEvidenceStatus.UNSUPPORTED_NUMERIC -> Color(0xFFFFB8B8)
                                }
                                Column(
                                    Modifier.fillMaxWidth().background(PanelRaised, RoundedCornerShape(8.dp)).padding(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(finding.status.label, color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    Text(finding.claimExcerpt, color = TextMain, fontSize = 10.sp, lineHeight = 14.sp)
                                    if (finding.unmatchedNumericValues.isNotEmpty()) {
                                        Text("Kaynak parçasında aynısı bulunamayan sayısal ifade: ${finding.unmatchedNumericValues.joinToString()}", color = statusColor, fontSize = 9.sp)
                                    }
                                    Text(
                                        "Atıf: ${finding.citedLabels.ifEmpty { listOf("yok") }.joinToString()} • Eşleşen: ${finding.matchedLabels.ifEmpty { listOf("yok") }.joinToString()} • Kelime örtüşmesi: ${(finding.bestLexicalOverlap * 100).toInt()}%",
                                        color = Muted,
                                        fontSize = 9.sp
                                    )
                                }
                            }
                            if (audit.claimFindings.size > 10) Text("${audit.claimFindings.size - 10} başka ifade gizlendi.", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        if (!message.isUser && message.text.isNotBlank() && !message.isError) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onCopy, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Muted, modifier = Modifier.size(13.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Kopyala", color = Muted, fontSize = 11.sp)
                }
                if (canRetry) {
                    TextButton(onClick = onRetry, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = Muted, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Yeniden dene", color = Muted, fontSize = 11.sp)
                    }
                }
            }
        } else if (canRetry) {
            TextButton(onClick = onRetry, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Muted, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text("Yeniden dene", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun Composer(value: String, onValueChange: (String) -> Unit, onSend: () -> Unit, enabled: Boolean, focusManager: FocusManager, onModels: () -> Unit, onContextDocuments: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Ink).imePadding().padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 10.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        IconButton(
            onClick = onModels,
            enabled = enabled,
            modifier = Modifier.size(42.dp).background(Panel, CircleShape)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Model ve dosyalar", tint = TextMain)
        }
        Spacer(Modifier.width(6.dp))
        IconButton(
            onClick = onContextDocuments,
            enabled = enabled,
            modifier = Modifier.size(38.dp).background(Panel, CircleShape)
        ) {
            Icon(Icons.Default.AttachFile, contentDescription = "Sohbete birden fazla yerel belge ekle (TXT/PDF/Office/görsel OCR)", tint = if (enabled) Accent else Muted, modifier = Modifier.size(19.dp))
        }
        Spacer(Modifier.width(6.dp))
        Row(
            Modifier.weight(1f).background(Panel, RoundedCornerShape(24.dp)).padding(horizontal = 15.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                enabled = enabled,
                modifier = Modifier.weight(1f),
                textStyle = androidx.compose.ui.text.TextStyle(color = TextMain, fontSize = 14.sp, lineHeight = 20.sp),
                cursorBrush = androidx.compose.ui.graphics.SolidColor(Accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { focusManager.clearFocus(); onSend() }),
                maxLines = 5,
                decorationBox = { inner ->
                    if (value.isEmpty()) Text("BREİT BRUT'a mesaj gönder…", color = Muted, fontSize = 14.sp)
                    inner()
                }
            )
        }
        Spacer(Modifier.width(8.dp))
        IconButton(
            onClick = { focusManager.clearFocus(); onSend() },
            enabled = enabled && value.isNotBlank(),
            modifier = Modifier.size(42.dp).background(if (enabled && value.isNotBlank()) Accent else Panel, CircleShape)
        ) {
            Icon(Icons.Default.ArrowUpward, contentDescription = "Gönder", tint = TextMain)
        }
    }
}

@Composable
private fun AssistantModeSheet(selected: AssistantMode, disabled: Boolean, onSelect: (AssistantMode) -> Unit) {
    Column(
        Modifier.fillMaxWidth().heightIn(max = 700.dp).verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Asistan modu", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = TextMain)
        Text("Her mod, yerel modelin sistem talimatlarını değiştirir. Gerçek yetenek yine seçili modelin kapasitesine bağlıdır.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        AssistantMode.entries.forEach { mode ->
            val isSelected = mode == selected
            Card(
                modifier = Modifier.fillMaxWidth().clickable(enabled = !disabled) { onSelect(mode) },
                colors = CardDefaults.cardColors(containerColor = if (isSelected) Accent.copy(alpha = 0.20f) else PanelRaised),
                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, Accent) else null
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(mode.label, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(mode.shortDescription, color = Muted, fontSize = 11.sp)
                    }
                    if (isSelected) Text("SEÇİLİ", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
private fun HistorySheet(
    threads: List<ChatThread>,
    activeId: String?,
    disabled: Boolean,
    onNewChat: () -> Unit,
    onSelect: (String) -> Unit,
    onDelete: (String) -> Unit
) {
    Column(Modifier.fillMaxWidth().heightIn(max = 680.dp).padding(horizontal = 18.dp, vertical = 8.dp)) {
        Text("Sohbet geçmişi", fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onNewChat, enabled = !disabled, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Yeni sohbet")
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f, fill = false)) {
            items(threads, key = { it.id }) { thread ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .background(if (thread.id == activeId) Accent.copy(alpha = 0.14f) else PanelRaised, RoundedCornerShape(12.dp))
                        .clickable(enabled = !disabled) { onSelect(thread.id) }
                        .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f).padding(end = 4.dp)) {
                        Text(thread.title, color = TextMain, fontSize = 13.sp, fontWeight = if (thread.id == activeId) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
                        Text("${thread.messages.size} mesaj • ${thread.mode.label} • ${thread.documents.size} belge • ${formatDate(thread.updatedAt)}", color = Muted, fontSize = 10.sp, maxLines = 1)
                    }
                    IconButton(onClick = { onDelete(thread.id) }, enabled = !disabled) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Sohbeti sil", tint = Muted)
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun ModelManagerSheet(vm: ChatViewModel, onImport: () -> Unit, onClose: () -> Unit) {
    val profile = vm.deviceProfile
    val modelSuitability = vm.modelSuitability
    val maxSize = ModelCatalog.items.maxOf { it.approxBytes }.toFloat()
    Column(
        Modifier.fillMaxWidth().heightIn(max = 780.dp).verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Yerel model kataloğu", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("İndirilen modeller cihazında kalır; sohbet buluta gönderilmez.", color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onClose, enabled = !vm.isDownloading && !vm.isStopping && !vm.isEmbeddingLoading) { Text("✕", color = Muted) }
        }

        Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Cihaz değerlendirmesi", fontWeight = FontWeight.SemiBold, color = TextMain)
                Text(profile.summary(), color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                Text(
                    if (profile.shouldWarnForQwen) "RAM uyarısı: büyük modeller beklenenden yavaş çalışabilir veya yüklenemeyebilir. Önce en küçük modeli dene."
                    else "RAM bilgisi yalnızca yaklaşık ön değerlendirmedir; gerçek bellek kullanımı model/arka uca göre değişir.",
                    color = if (profile.shouldWarnForQwen) Color(0xFFFFD18B) else Color(0xFFB7E8C8), fontSize = 11.sp
                )
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("P4.3 • Cihaza göre model önerisi", fontWeight = FontWeight.SemiBold, color = TextMain)
                val best = modelSuitability.firstOrNull { it.fit != ModelFit.NOT_RECOMMENDED }
                if (best != null) {
                    Text("İlk deneme önerisi: ${best.model.title} • ${best.fit.label}", color = if (best.fit == ModelFit.RECOMMENDED) Color(0xFFB7E8C8) else Color(0xFFFFD18B), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    best.reasons.forEach { reason -> Text("• $reason", color = Muted, fontSize = 10.sp, lineHeight = 14.sp) }
                    Text("Bu cihaz ve model için önerilen başlangıç yanıt sınırı: ${best.recommendedOutputTokens} token. Bu ayar modelin RAM kullanımını garanti etmez.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    TextButton(
                        onClick = { vm.setMaxOutputTokens(best.recommendedOutputTokens) },
                        enabled = !vm.isWorking && !vm.isStopping,
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                    ) { Text("Önerilen yanıt sınırını uygula", color = Accent, fontSize = 11.sp) }
                } else {
                    Text("Şu an katalogdaki modeller için güven veren bir RAM/depolama uygunluğu yok. Yer açıp diğer uygulamaları kapatmadan indirme yapma.", color = Color(0xFFFFB8B8), fontSize = 11.sp, lineHeight = 16.sp)
                }
                modelSuitability.forEach { entry ->
                    val readiness = DeviceReadinessScorer.assess(profile, entry.model)
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(entry.model.title, modifier = Modifier.weight(1f), color = TextMain, fontSize = 10.sp)
                            Text("${entry.fit.label} • ${readiness.score}/100 • ${entry.recommendedOutputTokens} tok.", color = when (entry.fit) {
                                ModelFit.RECOMMENDED -> Color(0xFFB7E8C8)
                                ModelFit.CAUTION -> Color(0xFFFFD18B)
                                ModelFit.NOT_RECOMMENDED -> Color(0xFFFFB8B8)
                            }, fontSize = 10.sp)
                        }
                        LinearProgressIndicator(
                            progress = { readiness.score / 100f },
                            modifier = Modifier.fillMaxWidth().height(3.dp),
                            color = when (readiness.risk) {
                                DeviceRisk.LOW -> Color(0xFF67C587)
                                DeviceRisk.MODERATE -> Color(0xFFFFC36E)
                                DeviceRisk.HIGH -> Color(0xFFFF7F86)
                            },
                            trackColor = Panel
                        )
                    }
                }
                Text("Bu ön değerlendirme RAM/depolama tahminidir; modelin kesin açılacağını veya hızını garanti etmez.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("P4.3 • Yerel performans ölçümü", fontWeight = FontWeight.SemiBold, color = TextMain)
                val summary = vm.performanceSummary
                if (summary == null) {
                    Text("Henüz ölçüm yok. Başarı, hata, iptal ve model yükleme süreleri ilk işlemlerden sonra görünür.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                } else {
                    Text("Başarılı yanıt: ${summary.successCount} • Hata: ${summary.failureCount} • İptal: ${summary.cancelledCount}", color = TextMain, fontSize = 11.sp)
                    if (summary.sampleCount > 0) {
                        Text("Medyan toplam süre: ${summary.medianDurationMs} ms • P90: ${summary.p90DurationMs} ms", color = TextMain, fontSize = 11.sp)
                        summary.medianFirstChunkLatencyMs?.let { Text("İlk metin parçasına medyan süre: $it ms", color = TextMain, fontSize = 11.sp) }
                        Text("Başarılı çıktının hızı: ${String.format(Locale("tr", "TR"), "%.1f", summary.charactersPerSecond)} karakter/sn", color = TextMain, fontSize = 11.sp)
                        summary.medianAvailableRamChangeBytes?.let { delta ->
                            val sign = if (delta >= 0) "+" else ""
                            Text("İşlem öncesi/sonrası kullanılabilir sistem RAM farkı: $sign${formatSize(delta)}", color = Muted, fontSize = 10.sp)
                        }
                    } else {
                        Text("Henüz başarılı yanıt yok; son denemeler başarısız veya iptal edilmiş.", color = Muted, fontSize = 10.sp)
                    }
                }
                val loadSummary = vm.modelLoadSummary
                if (loadSummary != null) {
                    Text("Model yükleme: ${loadSummary.sampleCount} başarılı • medyan ${loadSummary.medianDurationMs} ms • hata ${loadSummary.failureCount} • iptal ${loadSummary.cancelledCount}", color = TextMain, fontSize = 11.sp, lineHeight = 15.sp)
                    loadSummary.firstProcessLoadMedianMs?.let { Text("Bu uygulama sürecindeki ilk başarılı model yüklemesi: ${it} ms (soğuk başlangıç göstergesi)", color = Muted, fontSize = 10.sp, lineHeight = 14.sp) }
                    loadSummary.subsequentLoadMedianMs?.let { Text("Aynı süreçteki sonraki model yüklemeleri: medyan ${it} ms (bellekte tutulan modelle aynı şey değildir)", color = Muted, fontSize = 10.sp, lineHeight = 14.sp) }
                }
                val performanceGroups = vm.performanceSamples
                    .filter { it.eventType == InferenceSample.EVENT_INFERENCE }
                    .groupBy { it.modelName to it.backendLabel }
                    .entries
                    .sortedByDescending { entry -> entry.value.maxOfOrNull { it.completedAt } ?: 0L }
                performanceGroups.take(4).forEach { entry ->
                    val modelSummary = PerformanceMath.summarize(entry.value)
                    if (modelSummary != null) {
                        Text(
                            "${entry.key.first} • ${entry.key.second}: n=${modelSummary.sampleCount}, hata=${modelSummary.failureCount}, medyan ${modelSummary.medianDurationMs} ms",
                            color = Muted, fontSize = 9.sp, lineHeight = 13.sp
                        )
                    }
                }
                Text("RAM bilgisi Android'in işlem öncesi/sonrası kullanılabilir sistem RAM'idir; modelin tepe belleği değildir. Karakter/sn token/sn değildir. Sorular, yanıtlar ve belgeler telemetriye kaydedilmez.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                TextButton(onClick = { vm.clearPerformanceHistory() }, enabled = !vm.isWorking && !vm.isStopping) {
                    Text("Yerel performans geçmişini temizle", color = Danger, fontSize = 11.sp)
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Çalıştırma arka ucu", fontWeight = FontWeight.SemiBold, color = TextMain)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BackendPreference.entries.forEach { preference ->
                        val selected = vm.backendPreference == preference
                        Surface(
                            modifier = Modifier.weight(1f).clickable(enabled = !vm.isWorking && !vm.isStopping) { vm.setBackendPreference(preference) },
                            color = if (selected) Accent.copy(alpha = 0.3f) else Panel,
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Accent else Color(0xFF3B4352))
                        ) {
                            Text(
                                text = if (selected) "✓ ${preference.label}" else preference.label,
                                modifier = Modifier.padding(vertical = 10.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                color = TextMain,
                                fontSize = 12.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
                Text(
                    "Otomatik: model önerisini dener, başlatma başarısızsa diğer arka uca döner. " +
                        "GPU: GPU öncelikli, başlatma hatasında CPU yedeği. CPU: yalnızca CPU. " +
                        "Çıkarım başladıktan sonra oluşan sürücü/model hataları otomatik yeniden denenmez.",
                    color = Muted, fontSize = 11.sp, lineHeight = 16.sp
                )
                Text("Etkin arka uç: ${vm.activeBackendLabel}", color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Model boyutu karşılaştırması", fontWeight = FontWeight.SemiBold, color = TextMain)
                ModelCatalog.items.forEach { spec ->
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(spec.title, color = TextMain, fontSize = 11.sp, modifier = Modifier.weight(1f))
                            Text(spec.formattedSize(), color = Muted, fontSize = 10.sp)
                        }
                        LinearProgressIndicator(
                            progress = { (spec.approxBytes.toDouble() / maxSize.toDouble()).coerceIn(0.0, 1.0).toFloat() },
                            modifier = Modifier.fillMaxWidth().height(5.dp),
                            color = Accent,
                            trackColor = Color(0xFF3A4250)
                        )
                    }
                }
                Text("Çubuklar yalnızca yaklaşık indirme boyutunu karşılaştırır; RAM, hız veya cevap kalitesi ölçümü değildir.", color = Muted, fontSize = 10.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Anlamsal belge araması", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("EmbeddingGemma 2 Text 270M • yaklaşık 165 MB • Apache-2.0", color = Muted, fontSize = 10.sp)
                    }
                    if (vm.embeddingModelReady && vm.embeddingEnabled) {
                        Text("AKTİF", color = Color(0xFFB7E8C8), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
                Text(
                    "Bu isteğe bağlı yerel model; farklı ifadelerle sorulan soruları benzer anlamlı belge parçalarıyla eşleştirmeye yardım eder. İlk etkinleştirmede kayıtlı belgelerin vektörleri hazırlanır. Model devre dışı kalsa bile BM25 + TF-IDF araması çalışır.",
                    color = Muted, fontSize = 11.sp, lineHeight = 16.sp
                )
                Text("Durum: ${vm.embeddingStatus}", color = if (vm.embeddingModelReady && vm.embeddingEnabled) Color(0xFFB7E8C8) else Muted, fontSize = 11.sp)
                if (vm.deviceProfile.totalRamBytes < LocalEmbeddingModelCatalog.MIN_SUGGESTED_RAM_BYTES) {
                    Text("Dikkat: model için yaklaşık 2 GB+ RAM öneriliyor; bu cihazda yavaşlık veya bellek hatası olabilir.", color = Color(0xFFFFD18B), fontSize = 10.sp)
                }
                val embeddingDownloading = vm.isDownloading && vm.downloadingModelName == LocalEmbeddingModelCatalog.FILE_NAME
                when {
                    embeddingDownloading -> {
                        LinearProgressIndicator(progress = { vm.downloadProgress }, modifier = Modifier.fillMaxWidth(), color = Accent)
                        Text(vm.downloadLabel, color = Muted, fontSize = 10.sp)
                        OutlinedButton(onClick = { vm.cancelDownload() }, modifier = Modifier.fillMaxWidth()) { Text("İndirmeyi iptal et") }
                    }
                    vm.isEmbeddingLoading -> {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Accent)
                            Text("Embedding modeli yükleniyor ve yerel belge vektörleri hazırlanıyor…", color = Muted, fontSize = 11.sp)
                        }
                    }
                    !vm.embeddingModelInstalled -> {
                        Button(
                            onClick = { vm.downloadEmbeddingModel() },
                            enabled = !vm.isWorking && !vm.isStopping,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) { Text("EmbeddingGemma 2 indir • yaklaşık 165 MB") }
                    }
                    vm.embeddingEnabled && vm.embeddingModelReady -> {
                        OutlinedButton(onClick = { vm.disableEmbeddingSearch() }, enabled = !vm.isWorking && !vm.isStopping, modifier = Modifier.fillMaxWidth()) { Text("Anlamsal aramayı kapat • metinsel aramaya dön") }
                        TextButton(onClick = { vm.removeEmbeddingModel() }, enabled = !vm.isWorking && !vm.isStopping, modifier = Modifier.align(Alignment.End)) { Text("Modeli ve vektör önbelleğini kaldır", color = Danger, fontSize = 11.sp) }
                    }
                    else -> {
                        Button(
                            onClick = { vm.loadEmbeddingSearch() },
                            enabled = !vm.isWorking && !vm.isStopping,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) { Text("Anlamsal aramayı etkinleştir") }
                        TextButton(onClick = { vm.removeEmbeddingModel() }, enabled = !vm.isWorking && !vm.isStopping, modifier = Modifier.align(Alignment.End)) { Text("Embedding modelini sil", color = Danger, fontSize = 11.sp) }
                    }
                }
            }
        }

        Text("İndirilebilir modeller", fontWeight = FontWeight.SemiBold, color = TextMain)
        ModelCatalog.items.forEach { spec ->
            val installed = vm.models.firstOrNull { it.name == spec.fileName }
            val downloadingThis = vm.isDownloading && vm.downloadingModelName == spec.fileName
            Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(spec.title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${spec.formattedSize()} • ${spec.contextTokens} token bağlam • Önerilen arka uç: ${spec.recommendedBackend.label} • ${spec.license}", color = Muted, fontSize = 10.sp)
                            if (spec.id == "qwen06-int4") Text("BAŞLANGIÇ ÖNERİSİ • küçük dosya", color = Color(0xFFB7E8C8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        if (installed?.isActive == true) {
                            Text("AKTİF", color = Color(0xFFB7E8C8), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }
                    Text(spec.description, color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                    if (profile.totalRamBytes < spec.minimumSuggestedRamBytes) {
                        Text("Bu cihaz için RAM riski var; indirmeden önce daha küçük model düşün.", color = Color(0xFFFFD18B), fontSize = 10.sp)
                    }
                    if (downloadingThis) {
                        LinearProgressIndicator(progress = { vm.downloadProgress }, modifier = Modifier.fillMaxWidth(), color = Accent)
                        Text(vm.downloadLabel, color = Muted, fontSize = 10.sp)
                        OutlinedButton(onClick = { vm.cancelDownload() }, modifier = Modifier.fillMaxWidth()) { Text("İndirmeyi iptal et") }
                    } else {
                        Button(
                            onClick = { if (installed != null) vm.loadModel(spec.fileName) else vm.downloadModel(spec) },
                            enabled = !vm.isWorking && !vm.isStopping,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) {
                            Text(when {
                                installed?.isActive == true -> "Etkin model"
                                installed != null -> "Bu modeli yükle"
                                else -> "İndir • ${spec.formattedSize()}"
                            })
                        }
                    }
                }
            }
        }

        Text("Cihazdaki özel modeller (${vm.models.size})", fontWeight = FontWeight.SemiBold, color = TextMain)
        if (vm.models.isEmpty()) {
            Text("Henüz model eklenmemiş.", color = Muted, fontSize = 12.sp)
        } else {
            vm.models.forEach { model ->
                Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).padding(end = 6.dp)) {
                            Text(model.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextMain, maxLines = 2)
                            Text(formatSize(model.bytes), fontSize = 10.sp, color = Muted)
                            if (model.isActive) Text("Aktif model", fontSize = 10.sp, color = Color(0xFFB7E8C8))
                        }
                        if (!model.isActive) {
                            TextButton(onClick = { vm.loadModel(model.name) }, enabled = !vm.isWorking && !vm.isStopping) { Text("Yükle") }
                        }
                        IconButton(onClick = { vm.removeModel(model.name) }, enabled = !vm.isWorking && !vm.isStopping) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Modeli sil", tint = Danger)
                        }
                    }
                }
            }
        }
        OutlinedButton(onClick = onImport, enabled = !vm.isWorking && !vm.isStopping, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Cihazdan .litertlm modeli içe aktar")
        }
        if (vm.isModelLoading) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Accent)
                Spacer(Modifier.width(9.dp))
                Text("Model hazırlanıyor; bu işlem cihazına göre zaman alabilir…", color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

private fun formatDate(time: Long): String = SimpleDateFormat("d MMM, HH:mm", Locale("tr", "TR")).format(Date(time))
private fun formatSize(bytes: Long): String = if (bytes >= 1_073_741_824L) String.format(Locale("tr", "TR"), "%.2f GB", bytes / 1_073_741_824.0) else String.format(Locale("tr", "TR"), "%.0f MB", bytes / 1_048_576.0)
