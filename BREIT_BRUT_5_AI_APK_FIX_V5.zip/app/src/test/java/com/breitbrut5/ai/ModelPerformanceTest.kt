package com.breitbrut5.ai

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelPerformanceTest {
    @Test
    fun summaryUsesMedianAndCharacterThroughputNotTokenClaims() {
        val summary = PerformanceMath.summarize(listOf(
            InferenceSample("small", "CPU", 1_000, 500, 1),
            InferenceSample("small", "CPU", 3_000, 900, 2),
            InferenceSample("small", "CPU", 2_000, 600, 3)
        ))!!
        assertEquals(3, summary.sampleCount)
        assertEquals(2_000L, summary.medianDurationMs)
        assertEquals(3_000L, summary.p90DurationMs)
        assertEquals(2000.0 * 1000.0 / 6000.0, summary.charactersPerSecond, 1e-9)
    }

    @Test
    fun telemetryPersistsOnlyMetricsAndBoundsNumberOfSamples() {
        val root = createTempDir(prefix = "breit-telemetry-test-")
        try {
            val file = File(root, "telemetry/runs.tsv")
            val tracker = LocalPerformanceTelemetry(file, maxSamples = 2)
            tracker.record(InferenceSample("model-a", "CPU", 100, 50, 1))
            tracker.record(InferenceSample("model-b", "GPU", 200, 60, 2))
            tracker.record(InferenceSample("model-c", "CPU", 300, 70, 3))

            val loaded = LocalPerformanceTelemetry(file, maxSamples = 2).load()
            assertEquals(listOf("model-b", "model-c"), loaded.map { it.modelName })
            assertTrue(loaded.all { it.durationMs > 0 && it.outputCharacters >= 0 })
            assertTrue(file.readText().contains("model-b").not()) // model names are URL-safe Base64 encoded.
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun summarySeparatesSuccessFailureCancellationAndFirstChunkLatency() {
        val events = listOf(
            InferenceSample("model", "CPU", 1_000, 100, 1, firstChunkLatencyMs = 100, availableRamBeforeBytes = 1_000, availableRamAfterBytes = 900),
            InferenceSample("model", "CPU", 2_000, 200, 2, firstChunkLatencyMs = 300, availableRamBeforeBytes = 1_000, availableRamAfterBytes = 800),
            InferenceSample("model", "CPU", 200, 0, 3, outcome = InferenceSample.OUTCOME_FAILURE, errorCategory = "runtime_failure"),
            InferenceSample("model", "CPU", 400, 20, 4, outcome = InferenceSample.OUTCOME_CANCELLED)
        )
        val summary = PerformanceMath.summarize(events)!!
        assertEquals(2, summary.successCount)
        assertEquals(1, summary.failureCount)
        assertEquals(1, summary.cancelledCount)
        assertEquals(1_500L, summary.medianDurationMs)
        assertEquals(200L, summary.medianFirstChunkLatencyMs)
        assertEquals(-150L, summary.medianAvailableRamChangeBytes)
    }

    @Test
    fun modelLoadEventsAreSummarizedSeparately() {
        val summary = PerformanceMath.summarizeModelLoads(listOf(
            InferenceSample("model", "CPU", 1_000, 0, 1, eventType = InferenceSample.EVENT_MODEL_LOAD, firstModelLoadThisProcess = true),
            InferenceSample("model", "CPU", 500, 0, 2, eventType = InferenceSample.EVENT_MODEL_LOAD, outcome = InferenceSample.OUTCOME_FAILURE)
        ))!!
        assertEquals(1, summary.sampleCount)
        assertEquals(1_000L, summary.medianDurationMs)
        assertEquals(1, summary.firstLoadCount)
        assertEquals(1, summary.failureCount)
    }

    @Test
    fun modelLoadSummarySeparatesFirstProcessLoadFromLaterLoads() {
        val summary = PerformanceMath.summarizeModelLoads(listOf(
            InferenceSample("a", "CPU", 1_200, 0, 1, eventType = InferenceSample.EVENT_MODEL_LOAD, firstModelLoadThisProcess = true),
            InferenceSample("b", "CPU", 700, 0, 2, eventType = InferenceSample.EVENT_MODEL_LOAD, firstModelLoadThisProcess = false),
            InferenceSample("c", "CPU", 500, 0, 3, eventType = InferenceSample.EVENT_MODEL_LOAD, firstModelLoadThisProcess = false)
        ))!!
        assertEquals(1_200L, summary.firstProcessLoadMedianMs)
        assertEquals(600L, summary.subsequentLoadMedianMs)
    }

    @Test
    fun telemetryReadsLegacyFiveColumnRowsAndSupportsClear() {
        val root = createTempDir(prefix = "breit-telemetry-legacy-")
        try {
            val file = File(root, "legacy.tsv")
            val old = listOf(
                java.util.Base64.getUrlEncoder().withoutPadding().encodeToString("old-model".toByteArray()),
                java.util.Base64.getUrlEncoder().withoutPadding().encodeToString("CPU".toByteArray()),
                "50", "20", "123"
            ).joinToString("\t")
            file.writeText(old + "\n")
            val tracker = LocalPerformanceTelemetry(file)
            assertEquals("old-model", tracker.load().single().modelName)
            tracker.clear()
            assertTrue(tracker.load().isEmpty())
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun invalidOrEmptySamplesProduceNoSummary() {
        assertEquals(null, PerformanceMath.summarize(emptyList()))
        assertEquals(null, PerformanceMath.summarize(listOf(InferenceSample("m", "CPU", 0, 5, 1))))
    }
}
