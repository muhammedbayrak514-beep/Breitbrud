package com.breitbrut5.ai

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelArtifactIntegrityTest {
    @Test fun firstLoadCreatesLocalFingerprintAndLaterVerificationSucceeds() {
        val root = createTempDir(prefix = "breit-model-integrity-")
        try {
            val model = File(root, "mock.litertlm").apply { writeText("model-bytes-for-test") }
            assertEquals(ModelArtifactIntegrity.Result.CREATED_FIRST_FINGERPRINT, ModelArtifactIntegrity.verifyOrCreate(model))
            assertTrue(ModelArtifactIntegrity.manifestFile(model).isFile)
            assertEquals(ModelArtifactIntegrity.Result.VERIFIED_EXISTING_FINGERPRINT, ModelArtifactIntegrity.verifyOrCreate(model))
        } finally { root.deleteRecursively() }
    }

    @Test fun changedModelSizeIsRejectedAgainstExistingFingerprint() {
        val root = createTempDir(prefix = "breit-model-change-")
        try {
            val model = File(root, "mock.litertlm").apply { writeText("first") }
            ModelArtifactIntegrity.initialize(model)
            model.writeText("changed-size")
            var failed = false
            try { ModelArtifactIntegrity.verifyOrCreate(model) } catch (_: IllegalArgumentException) { failed = true }
            assertTrue(failed)
        } finally { root.deleteRecursively() }
    }
}
