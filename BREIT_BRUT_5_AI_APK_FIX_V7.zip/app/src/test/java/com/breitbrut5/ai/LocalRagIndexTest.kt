package com.breitbrut5.ai

import java.io.File
import java.nio.charset.StandardCharsets
import java.util.Base64
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.io.path.createTempDirectory

class LocalRagIndexTest {
    @Test
    fun chunkIdsAreStableAndOffsetsPointIntoOriginalDocument() {
        val content = (1..24).joinToString("\n\n") { "Bölüm $it: Yerel yapay zeka belgeleri ve arama sistemi." }
        val first = LocalRagIndexStore.chunkDocument("doc-1", "notes.txt", content)
        val second = LocalRagIndexStore.chunkDocument("doc-1", "notes.txt", content)
        assertTrue(first.isNotEmpty())
        assertEquals(first.map { it.id }, second.map { it.id })
        assertTrue(first.all { it.documentId == "doc-1" })
        first.forEach { chunk ->
            assertTrue(chunk.startOffset >= 0)
            assertTrue(chunk.endOffset <= content.length)
            assertTrue(content.substring(chunk.startOffset, chunk.endOffset).contains(chunk.text))
        }
    }

    @Test
    fun hybridSearchRanksRelevantLocalChunksAndHonorsChatDocumentScope() {
        val root = createTempDirectory(prefix = "breit-rag-test-").toFile()
        try {
            val index = LocalRagIndexStore(root)
            index.upsertDocument("finance-1", "budget.txt", "The annual budget covers salaries, rent, and electricity costs.")
            index.upsertDocument("science-1", "science.txt", "Mitochondria produce ATP and help cells release usable energy.")

            val scoped = index.search("mitochondria ATP energy", setOf("science-1"))
            assertTrue(scoped.isNotEmpty())
            assertEquals("science-1", scoped.first().documentId)
            assertEquals("science.txt", scoped.first().documentName)
            assertTrue(index.search("mitochondria ATP energy", setOf("finance-1")).isEmpty())
            assertTrue(index.search("unknownterm", setOf("science-1", "finance-1")).isEmpty())
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun optionalEmbeddingRerankerCanReorderCandidates() {
        val root = createTempDirectory(prefix = "breit-rag-embed-").toFile()
        try {
            val index = LocalRagIndexStore(root)
            index.upsertDocument("doc-a", "a.txt", "The car engine consumes fuel and produces torque.")
            index.upsertDocument("doc-b", "b.txt", "The car engine uses petrol and creates rotational force.")
            val lexical = index.search("car engine fuel", setOf("doc-a", "doc-b"), topK = 2)
            assertTrue(lexical.isNotEmpty())
            assertEquals("doc-a", lexical.first().documentId)
            index.setEmbeddingReranker(LocalEmbeddingReranker { _, candidates -> candidates.reversed() })
            val reranked = index.search("car engine fuel", setOf("doc-a", "doc-b"), topK = 2)
            assertEquals(lexical.last().documentId, reranked.first().documentId)
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun failedOptionalRerankerFallsBackToHybridResults() {
        val root = createTempDirectory(prefix = "breit-rag-fallback-").toFile()
        try {
            val index = LocalRagIndexStore(root)
            index.upsertDocument("doc-a", "a.txt", "Local offline search engine and index.")
            index.setEmbeddingReranker(LocalEmbeddingReranker { _, _ -> error("embedding not available") })
            assertTrue(index.search("offline search", setOf("doc-a")).isNotEmpty())
        } finally {
            root.deleteRecursively()
        }
    }


    @Test
    fun realVectorSidecarsPersistRerankAndAreReusedAcrossIndexInstances() {
        val root = createTempDirectory(prefix = "breit-rag-vectors-").toFile()
        try {
            val embedder = object : LocalVectorEmbedder {
                override val modelId = "fake-embedding-v1"
                override fun embedDocument(text: String): FloatArray =
                    if (text.contains("beta", ignoreCase = true)) floatArrayOf(0f, 1f) else floatArrayOf(1f, 0f)
                override fun embedQuery(text: String): FloatArray = floatArrayOf(0f, 1f)
            }
            val index = LocalRagIndexStore(root)
            index.upsertDocument("doc-a", "alpha.txt", "shared banana alpha")
            index.upsertDocument("doc-b", "beta.txt", "shared banana beta")
            index.setVectorEmbedder(embedder)

            assertEquals(2, index.rebuildAllEmbeddings())
            assertTrue(File(root, "doc-a.vec").isFile)
            assertTrue(File(root, "doc-b.vec").isFile)
            // The second activation must reuse current vectors instead of re-running the model.
            assertEquals(0, index.rebuildAllEmbeddings())

            val result = LocalRagIndexStore(root).also { it.setVectorEmbedder(embedder) }
                .search("shared banana", setOf("doc-a", "doc-b"), topK = 2)
            assertEquals("doc-b", result.first().documentId)

            val reopened = LocalRagIndexStore(root)
            reopened.removeDocument("doc-b")
            assertFalse(File(root, "doc-b.vec").exists())
        } finally {
            root.deleteRecursively()
        }
    }


    @Test
    fun changingEmbeddingModelIdInvalidatesPersistedVectorSidecars() {
        val root = createTempDirectory(prefix = "breit-rag-vector-version-").toFile()
        try {
            val index = LocalRagIndexStore(root)
            index.upsertDocument("doc-version", "version.txt", "shared phrase with local semantic index")
            val firstModel = object : LocalVectorEmbedder {
                override val modelId = "embedding-model-v1"
                override fun embedDocument(text: String) = floatArrayOf(1f, 0f)
                override fun embedQuery(text: String) = floatArrayOf(1f, 0f)
            }
            index.setVectorEmbedder(firstModel)
            assertEquals(1, index.rebuildAllEmbeddings())

            val secondModel = object : LocalVectorEmbedder {
                override val modelId = "embedding-model-v2"
                override fun embedDocument(text: String) = floatArrayOf(0f, 1f)
                override fun embedQuery(text: String) = floatArrayOf(0f, 1f)
            }
            index.setVectorEmbedder(secondModel)
            assertEquals(1, index.rebuildAllEmbeddings())
            assertEquals(0, index.rebuildAllEmbeddings())
            assertTrue(index.search("shared phrase", setOf("doc-version")).isNotEmpty())
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun corruptVectorSidecarFallsBackToLexicalSearch() {
        val root = createTempDirectory(prefix = "breit-rag-vector-fallback-").toFile()
        try {
            val embedder = object : LocalVectorEmbedder {
                override val modelId = "fake-embedding-v1"
                override fun embedDocument(text: String) = floatArrayOf(1f, 0f)
                override fun embedQuery(text: String) = floatArrayOf(1f, 0f)
            }
            val index = LocalRagIndexStore(root)
            index.upsertDocument("doc-a", "a.txt", "shared banana alpha")
            index.upsertDocument("doc-b", "b.txt", "shared banana beta")
            index.setVectorEmbedder(embedder)
            index.rebuildAllEmbeddings()
            File(root, "doc-a.vec").writeBytes(byteArrayOf(1, 2, 3, 4))

            val results = index.search("shared banana", setOf("doc-a", "doc-b"), topK = 2)
            assertEquals(2, results.size)
            assertTrue(results.all { it.documentId in setOf("doc-a", "doc-b") })
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun contextBudgetIsEnforcedAtRetrievalBoundary() {
        val root = createTempDirectory(prefix = "breit-rag-budget-").toFile()
        try {
            val index = LocalRagIndexStore(root)
            val content = (1..80).joinToString("\n") { "offline retrieval system section $it includes searchable words" }
            index.upsertDocument("doc-budget", "long.txt", content)
            val results = index.search("offline retrieval system", setOf("doc-budget"), topK = 5, maxContextChars = 180)
            assertTrue(results.isNotEmpty())
            assertTrue(results.sumOf { it.text.length } <= 180)
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun upsertReplacesExistingDocumentIndexWithoutLeavingOldContent() {
        val root = createTempDirectory(prefix = "breit-rag-update-").toFile()
        try {
            val index = LocalRagIndexStore(root)
            index.upsertDocument("doc-3", "draft.txt", "Orchard apples and pears are fruit.")
            assertTrue(index.search("orchard apples", setOf("doc-3")).isNotEmpty())

            index.upsertDocument("doc-3", "updated.txt", "Electrical circuits carry voltage and current.")
            assertTrue(index.search("orchard apples", setOf("doc-3")).isEmpty())
            val updated = index.search("voltage current", setOf("doc-3"))
            assertTrue(updated.isNotEmpty())
            assertEquals("updated.txt", updated.first().documentName)
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun persistedIndexCanBeReadRemovedAndPruned() {
        val root = createTempDirectory(prefix = "breit-rag-persist-").toFile()
        try {
            LocalRagIndexStore(root).upsertDocument("doc-2", "guide.md", "Offline search retrieves relevant document passages.")
            assertTrue(LocalRagIndexStore(root).hasIndex("doc-2"))
            val results = LocalRagIndexStore(root).search("relevant document passages", setOf("doc-2"))
            assertEquals("guide.md", results.first().documentName)
            LocalRagIndexStore(root).removeDocument("doc-2")
            assertFalse(LocalRagIndexStore(root).hasIndex("doc-2"))
            assertTrue(LocalRagIndexStore(root).search("relevant document passages", setOf("doc-2")).isEmpty())

            val index = LocalRagIndexStore(root)
            index.upsertDocument("live-1", "live.txt", "persist this local search document")
            index.upsertDocument("orphan-1", "orphan.txt", "old orphan index")
            index.removeMissing(setOf("live-1"))
            assertTrue(index.hasIndex("live-1"))
            assertFalse(index.hasIndex("orphan-1"))
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun sameContentIsDetectedEvenForLegacyDocumentsWithoutStoredHash() {
        val content = "Document contents should only be attached once."
        val hash = LocalRagIndexStore.fingerprint(content)
        val alreadyHasHash = LocalDocument(
            id = "a", displayName = "a.txt", storedFileName = "legacy_a.txt", bytes = content.length.toLong(),
            characterCount = content.length, contentHash = hash
        )
        val legacy = LocalDocument(
            id = "b", displayName = "b.txt", storedFileName = "legacy_b.txt", bytes = content.length.toLong(),
            characterCount = content.length
        )
        assertEquals(alreadyHasHash, findDuplicateLocalDocument(listOf(alreadyHasHash), hash) { null })
        assertEquals(legacy, findDuplicateLocalDocument(listOf(legacy), hash) { content })
        assertNotEquals(hash, LocalRagIndexStore.fingerprint(content + " changed"))
    }



    @Test
    fun previousP3IndexFormatWithoutEndOffsetRemainsReadable() {
        val root = createTempDirectory(prefix = "breit-rag-legacy-").toFile()
        try {
            val name = Base64.getUrlEncoder().withoutPadding().encodeToString("legacy.txt".toByteArray(StandardCharsets.UTF_8))
            val text = Base64.getUrlEncoder().withoutPadding().encodeToString("old index remains searchable".toByteArray(StandardCharsets.UTF_8))
            File(root, "legacy-1.rag").writeText("BREIT_RAG_V1\t$name\toldhash\nlegacychunk_0_abcd\t0\t0\t$text\n", StandardCharsets.UTF_8)
            val result = LocalRagIndexStore(root).search("index searchable", setOf("legacy-1"))
            assertTrue(result.isNotEmpty())
            assertEquals("legacy.txt", result.first().documentName)
            assertEquals(28, result.first().endOffset)
        } finally {
            root.deleteRecursively()
        }
    }
}
