package com.breitbrut5.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SourceCitationValidatorTest {
    private fun source(label: String) = LocalSourceReference(
        label = label,
        documentId = "doc-1",
        documentName = "guide.txt",
        sectionNumber = 2,
        startOffset = 40,
        endOffset = 92,
        excerpt = "Supporting source text"
    )

    @Test
    fun labelsFromRetrievedSourcesAreRecognizedCaseInsensitively() {
        val audit = SourceCitationValidator.validate(
            answer = "The answer is grounded [S1] and further supported [s2].",
            availableSources = listOf(source("[S1]"), source("[S2]")),
            hasAttachedDocuments = true
        )!!
        assertEquals(listOf("[S1]", "[S2]"), audit.citedLabels)
        assertTrue(audit.unknownLabels.isEmpty())
        assertTrue(audit.uncitedLabels.isEmpty())
        assertFalse(audit.noMatchingSources)
    }

    @Test
    fun unknownLabelsAreReportedAndUncitedSourcesRemainVisible() {
        val audit = SourceCitationValidator.validate(
            answer = "Claims cite nonexistent sources [S9] and [S1000].",
            availableSources = listOf(source("[S1]"), source("[S2]")),
            hasAttachedDocuments = true
        )!!
        assertEquals(listOf("[S9]", "[S1000]"), audit.unknownLabels)
        assertEquals(listOf("[S1]", "[S2]"), audit.uncitedLabels)
        assertTrue(audit.hasUnknownLabels)
    }

    @Test
    fun noRetrievedMatchesAreExplicitlyFlagged() {
        val audit = SourceCitationValidator.validate(
            answer = "I cannot find that in the provided files.",
            availableSources = emptyList(),
            hasAttachedDocuments = true
        )!!
        assertTrue(audit.noMatchingSources)
        assertTrue(audit.citedLabels.isEmpty())
    }



    @Test
    fun labelsInsideFencedCodeAreNotTreatedAsCitations() {
        val audit = SourceCitationValidator.validate(
            answer = "```kotlin\nval sample = \"[S99]\"\n```\nBu yanıt cümlesinde etiket yok ve belgeye dayalı atıf yapılmadı.",
            availableSources = listOf(source("[S1]")),
            hasAttachedDocuments = true
        )!!
        assertTrue(audit.unknownLabels.isEmpty())
        assertTrue(audit.citedLabels.isEmpty())
    }

    @Test
    fun cosineSimilarityHandlesOrthogonalAndInvalidVectors() {
        assertEquals(0.0, EmbeddingMath.cosineSimilarity(floatArrayOf(1f, 0f), floatArrayOf(0f, 1f)), 1e-9)
        assertEquals(-1.0, EmbeddingMath.cosineSimilarity(floatArrayOf(1f, 0f), floatArrayOf(-1f, 0f)), 1e-9)
        assertTrue(EmbeddingMath.cosineSimilarity(floatArrayOf(1f), floatArrayOf(1f, 2f)).isNaN())
        assertTrue(EmbeddingMath.cosineSimilarity(floatArrayOf(0f, 0f), floatArrayOf(1f, 0f)).isNaN())
    }

    @Test
    fun citationAuditIsSkippedWhenNoDocumentsWereAttached() {
        assertNull(SourceCitationValidator.validate("Ordinary answer", emptyList(), hasAttachedDocuments = false))
    }
}
