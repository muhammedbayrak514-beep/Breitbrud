package com.breitbrut5.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class OoxmlTextExtractorTest {
    @Test fun docxExtractsParagraphsAndTabsWithoutUnpackingFiles() {
        val archive = zipOf(
            "word/document.xml" to """
                <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>
                <w:p><w:r><w:t>Selam</w:t><w:tab/><w:t>Dünya</w:t></w:r></w:p>
                <w:p><w:r><w:t>İkinci paragraf</w:t></w:r></w:p>
                </w:body></w:document>
            """.trimIndent()
        )
        val result = OoxmlTextExtractor.extractDocx(archive)
        assertTrue(result.text.contains("Selam\tDünya"))
        assertTrue(result.text.contains("İkinci paragraf"))
        assertEquals("docx_xml", result.method)
    }

    @Test fun pptxSlidesAreInNumericOrderAndHaveMarkers() {
        val archive = zipOf(
            "ppt/slides/slide2.xml" to slide("İkinci slayt"),
            "ppt/slides/slide1.xml" to slide("İlk slayt")
        )
        val result = OoxmlTextExtractor.extractPptx(archive)
        assertEquals(2, result.sectionCount)
        assertTrue(result.text.indexOf("İlk slayt") < result.text.indexOf("İkinci slayt"))
        assertTrue(result.text.contains("[Slayt 1]"))
        assertEquals("pptx_ooxml_text", result.method)
    }

    @Test fun pptxUsesDeclaredPresentationOrderWhenItDiffersFromFileNumbers() {
        val archive = zipOf(
            "ppt/presentation.xml" to """
                <p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
                  <p:sldIdLst><p:sldId id="2" r:id="rId2"/><p:sldId id="1" r:id="rId1"/></p:sldIdLst>
                </p:presentation>
            """.trimIndent(),
            "ppt/_rels/presentation.xml.rels" to """
                <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
                  <Relationship Id="rId1" Target="slides/slide1.xml" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide"/>
                  <Relationship Id="rId2" Target="slides/slide2.xml" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide"/>
                </Relationships>
            """.trimIndent(),
            "ppt/slides/slide1.xml" to slide("Dosya numarası bir"),
            "ppt/slides/slide2.xml" to slide("Önce gösterilen slayt")
        )
        val result = OoxmlTextExtractor.extractPptx(archive)
        assertTrue(result.text.indexOf("Önce gösterilen slayt") < result.text.indexOf("Dosya numarası bir"))
        assertTrue(result.text.contains("[Slayt 1]\nÖnce gösterilen slayt"))
        assertTrue(result.text.contains("[Slayt 2]\nDosya numarası bir"))
    }

    @Test fun xlsxResolvesSharedStringsAndWorkbookSheetNames() {
        val archive = zipOf(
            "xl/workbook.xml" to """
                <workbook xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>
                  <sheet name="Özet" sheetId="1" r:id="rId1"/>
                </sheets></workbook>
            """.trimIndent(),
            "xl/_rels/workbook.xml.rels" to """
                <Relationships><Relationship Id="rId1" Target="worksheets/sheet1.xml" Type="worksheet"/></Relationships>
            """.trimIndent(),
            "xl/sharedStrings.xml" to """
                <sst><si><t>Ürün</t></si><si><r><t>Adet</t></r><r><t> toplam</t></r></si></sst>
            """.trimIndent(),
            "xl/worksheets/sheet1.xml" to """
                <worksheet><sheetData>
                  <row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c></row>
                  <row r="2"><c r="A2" t="inlineStr"><is><t>Kalem</t></is></c><c r="B2"><v>27</v></c></row>
                </sheetData></worksheet>
            """.trimIndent()
        )
        val result = OoxmlTextExtractor.extractXlsx(archive)
        assertEquals(1, result.sectionCount)
        assertTrue(result.text.contains("[Çalışma sayfası: Özet]"))
        assertTrue(result.text.contains("A1=Ürün"))
        assertTrue(result.text.contains("B1=Adet toplam"))
        assertTrue(result.text.contains("A2=Kalem"))
        assertTrue(result.text.contains("B2=27"))
    }

    @Test fun rejectsUnsafeArchivePath() {
        val archive = zipOf("../outside.xml" to "<x>bad</x>", "word/document.xml" to "<w:document/>")
        val failure = runCatching { OoxmlTextExtractor.extractDocx(archive) }.exceptionOrNull()
        assertTrue(failure is IllegalStateException || failure is IllegalArgumentException)
        assertFalse(failure?.message.isNullOrBlank())
    }

    @Test fun rejectsArchivesWithNoSupportedMainEntries() {
        val archive = zipOf("custom.xml" to "<root>nothing</root>")
        val failure = runCatching { OoxmlTextExtractor.extractDocx(archive) }.exceptionOrNull()
        assertTrue(failure != null)
    }

    private fun slide(text: String) = """
        <p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
          <p:cSld><p:spTree><p:sp><p:txBody><a:p><a:r><a:t>$text</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld>
        </p:sld>
    """.trimIndent()

    private fun zipOf(vararg entries: Pair<String, String>): ByteArray {
        val bytes = ByteArrayOutputStream()
        ZipOutputStream(bytes).use { zip ->
            entries.forEach { (name, text) ->
                zip.putNextEntry(ZipEntry(name))
                zip.write(text.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }
        return bytes.toByteArray()
    }
}
