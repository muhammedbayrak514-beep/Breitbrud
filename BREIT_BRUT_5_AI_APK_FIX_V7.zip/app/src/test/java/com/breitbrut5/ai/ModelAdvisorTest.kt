package com.breitbrut5.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelAdvisorTest {
    @Test
    fun smallerModelIsPreferredWhenAllModelsFit() {
        val profile = DeviceProfile(
            totalRamBytes = 8L * 1_073_741_824L,
            availableRamBytes = 5L * 1_073_741_824L,
            freeStorageBytes = 8L * 1_073_741_824L
        )
        val ranked = DeviceModelAdvisor.rank(profile)
        assertEquals(ModelFit.RECOMMENDED, ranked.first().fit)
        assertTrue(ranked.first().model.approxBytes <= ranked.last().model.approxBytes)
    }

    @Test
    fun lowStorageNeverGetsRecommendedFit() {
        val profile = DeviceProfile(
            totalRamBytes = 8L * 1_073_741_824L,
            availableRamBytes = 5L * 1_073_741_824L,
            freeStorageBytes = 20L * 1_048_576L
        )
        assertTrue(DeviceModelAdvisor.rank(profile).all { it.fit == ModelFit.NOT_RECOMMENDED })
    }


    @Test
    fun recommendationRespectsTheDownloaderAbsoluteFreeSpaceGate() {
        val profile = DeviceProfile(
            totalRamBytes = 8L * 1_073_741_824L,
            availableRamBytes = 5L * 1_073_741_824L,
            freeStorageBytes = 1_200_000_000L
        )
        assertTrue(DeviceModelAdvisor.rank(profile).all { it.fit == ModelFit.NOT_RECOMMENDED })
    }

    @Test
    fun advisorUsesExactlyTheSameStorageRuleAsDownloader() {
        ModelCatalog.items.forEach { model ->
            val expected = ModelStoragePolicy.requiredFreeBytes(model.approxBytes)
            val result = DeviceModelAdvisor.assess(
                DeviceProfile(8L * 1_073_741_824L, 5L * 1_073_741_824L, expected), model
            )
            assertEquals(expected, result.requiredFreeStorageBytes)
            assertTrue(ModelStoragePolicy.hasEnoughSpace(expected, model.approxBytes))
            assertTrue(!ModelStoragePolicy.hasEnoughSpace(expected - 1L, model.approxBytes))
        }
    }

    @Test
    fun importedModelRequiresStorageAndHasHardSizeLimit() {
        assertEquals(ModelImportPolicy.Issue.TOO_LARGE, ModelImportPolicy.preflightIssue(ModelImportPolicy.MAX_IMPORTED_MODEL_BYTES + 1, 8L * 1_073_741_824L))
        assertEquals(ModelImportPolicy.Issue.LOW_STORAGE, ModelImportPolicy.preflightIssue(500L * 1_048_576L, 200L * 1_048_576L))
        assertEquals(null, ModelImportPolicy.preflightIssue(500L * 1_048_576L, 2L * 1_073_741_824L))
    }

    @Test
    fun importedModelStreamChecksDeclaredSizeReserveAndCompletion() {
        assertEquals(ModelImportPolicy.Issue.PROVIDER_SIZE_MISMATCH, ModelImportPolicy.progressIssue(101, 100, 2_000_000_000))
        assertEquals(ModelImportPolicy.Issue.FREE_SPACE_GUARD, ModelImportPolicy.progressIssue(1_800_000_000, null, 2_000_000_000))
        assertEquals(ModelImportPolicy.Issue.INCOMPLETE_COPY, ModelImportPolicy.completionIssue(99, 100))
        assertEquals(null, ModelImportPolicy.completionIssue(100, 100))
    }

    @Test
    fun readinessScoreFallsWhenFreeStorageIsLow() {
        val model = ModelCatalog.items.first()
        val okay = DeviceReadinessScorer.assess(DeviceProfile(8L * 1_073_741_824L, 4L * 1_073_741_824L, 4L * 1_073_741_824L), model)
        val low = DeviceReadinessScorer.assess(DeviceProfile(8L * 1_073_741_824L, 4L * 1_073_741_824L, 10L * 1_048_576L), model)
        assertTrue(okay.score > low.score)
        assertEquals(DeviceRisk.HIGH, low.risk)
    }

    @Test
    fun recommendedOutputTokenCapFallsWhenAvailableRamIsLow() {
        val model = ModelCatalog.items.last()
        val generous = DeviceProfile(8L * 1_073_741_824L, 4L * 1_073_741_824L, 8L * 1_073_741_824L)
        val pressured = DeviceProfile(4L * 1_073_741_824L, 700L * 1_048_576L, 8L * 1_073_741_824L)
        assertTrue(DeviceModelAdvisor.recommendedOutputTokens(generous, model) > DeviceModelAdvisor.recommendedOutputTokens(pressured, model))
        assertEquals(128, DeviceModelAdvisor.recommendedOutputTokens(pressured, model))
    }

    @Test
    fun insufficientRamCannotBeRankedAsRecommendedForLargeModel() {
        val profile = DeviceProfile(
            totalRamBytes = 2L * 1_073_741_824L,
            availableRamBytes = 500L * 1_048_576L,
            freeStorageBytes = 8L * 1_073_741_824L
        )
        val largeModel = ModelCatalog.items.maxBy { it.minimumSuggestedRamBytes }
        assertTrue(DeviceModelAdvisor.assess(profile, largeModel).fit != ModelFit.RECOMMENDED)
    }
}
