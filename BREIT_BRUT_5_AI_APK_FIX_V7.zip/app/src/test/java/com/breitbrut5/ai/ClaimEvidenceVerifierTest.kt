package com.breitbrut5.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ClaimEvidenceVerifierTest {
    private fun source(
        label: String = "[S1]",
        documentId: String = "doc-1",
        excerpt: String = "Fotosentez sürecinde bitkiler güneş ışığını kullanarak karbondioksit ve sudan glikoz üretir. Bu süreçte oksijen açığa çıkar."
    ) = LocalSourceReference(label, documentId, "biology.txt", 1, 0, excerpt.length, excerpt)

    @Test
    fun matchingCitationGetsOnlyLexicalMatchStatus() {
        val findings = ClaimEvidenceVerifier.evaluate(
            "Fotosentez sürecinde bitkiler güneş ışığını kullanarak karbondioksit ve sudan glikoz üretir [S1].",
            listOf(source())
        )
        assertEquals(1, findings.size)
        assertEquals(ClaimEvidenceStatus.LEXICAL_MATCH, findings.single().status)
        assertTrue(findings.single().bestLexicalOverlap >= ClaimEvidenceVerifier.LEXICAL_MATCH_THRESHOLD)
    }

    @Test
    fun unrelatedCitationIsNotReportedAsLexicallySupported() {
        val findings = ClaimEvidenceVerifier.evaluate(
            "Fotosentez sürecinde bitkiler güneş ışığını kullanarak karbondioksit ve sudan glikoz üretir [S1].",
            listOf(source(excerpt = "Yıllık bütçe kira, maaşlar, ulaşım giderleri ve elektrik faturasını içerir."))
        )
        assertEquals(ClaimEvidenceStatus.NO_LEXICAL_MATCH, findings.single().status)
    }

    @Test
    fun substantiveUncitedSentenceIsFlagged() {
        val findings = ClaimEvidenceVerifier.evaluate(
            "Fotosentez sürecinde bitkiler güneş ışığını kullanarak karbondioksit ve sudan glikoz üretir.",
            listOf(source())
        )
        assertEquals(ClaimEvidenceStatus.UNCITED, findings.single().status)
    }

    @Test
    fun codeBlockCitationIsNotCountedAsEvidence() {
        val findings = ClaimEvidenceVerifier.evaluate(
            "```kotlin\nval message = \"Bu iddia çok önemli ve doğrudur [S1]\"\n```\n" +
                "Fotosentez sürecinde bitkiler güneş ışığını kullanarak karbondioksit ve sudan glikoz üretir.",
            listOf(source())
        )
        assertEquals(1, findings.size)
        assertEquals(ClaimEvidenceStatus.UNCITED, findings.single().status)
    }


    @Test
    fun unsupportedNumericValuesAreFlaggedEvenWhenWordsOverlap() {
        val source = source(excerpt = "Tesis yıllık üretim miktarını belgeledi ve ürünleri düzenli olarak sevk etti.")
        val findings = ClaimEvidenceVerifier.evaluate(
            "Tesis 120 ton ürün üretmiştir ve sevkiyatı 2024 yılında tamamlamıştır [S1].",
            listOf(source)
        )
        assertEquals(ClaimEvidenceStatus.UNSUPPORTED_NUMERIC, findings.single().status)
        assertTrue(findings.single().unmatchedNumericValues.contains("120"))
        assertTrue(findings.single().unmatchedNumericValues.contains("2024"))
    }

    @Test
    fun numericValuesPresentInCitedExcerptAreNotFlagged() {
        val source = source(excerpt = "Tesis 120 ton ürün üretti. Sevkiyat 2024 yılında tamamlandı.")
        val findings = ClaimEvidenceVerifier.evaluate(
            "Tesis 120 ton ürün üretti; sevkiyat 2024 yılında tamamlandı [S1].",
            listOf(source)
        )
        assertTrue(findings.single().unmatchedNumericValues.isEmpty())
    }

    @Test
    fun citationAuditRejectsSourceFromDocumentOutsideCurrentChatScope() {
        val audit = SourceCitationValidator.validate(
            answer = "Fotosentez sürecinde bitkiler güneş ışığını kullanarak karbondioksit ve sudan glikoz üretir [S1].",
            availableSources = listOf(source(documentId = "other-chat-doc")),
            hasAttachedDocuments = true,
            allowedDocumentIds = setOf("active-chat-doc")
        )!!
        assertEquals(listOf("[S1]"), audit.invalidSourceLabels)
        assertTrue(audit.hasSourceIntegrityIssues)
    }
}
