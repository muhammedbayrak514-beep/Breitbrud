package com.breitbrut5.ai

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.io.path.createTempDirectory

class AtomicTextFileStoreTest {
    @Test
    fun writesAndReplacesTextWithoutLeavingTransactionFiles() {
        val root = createTempDirectory(prefix = "breit-atomic-store-").toFile()
        try {
            val file = File(root, "chat_store/threads.json")
            val store = AtomicTextFileStore(file)
            store.writeText("first payload")
            assertEquals("first payload", store.readTextOrNull())

            store.writeText("second payload with unicode: ğüşiöç")
            assertEquals("second payload with unicode: ğüşiöç", store.readTextOrNull())
            assertFalse(File(file.parentFile, file.name + ".tmp").exists())
            assertFalse(File(file.parentFile, file.name + ".bak").exists())
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun restoresBackupWhenPrimaryFileIsMissing() {
        val root = createTempDirectory(prefix = "breit-atomic-recovery-").toFile()
        try {
            val file = File(root, "threads.json")
            File(root, "threads.json.bak").writeText("recoverable payload")

            val recovered = AtomicTextFileStore(file).readTextOrNull()
            assertEquals("recoverable payload", recovered)
            assertTrue(file.isFile)
            assertFalse(File(root, "threads.json.bak").exists())
        } finally {
            root.deleteRecursively()
        }
    }


    @Test
    fun failedTempWriteKeepsPreviousPayload() {
        val root = createTempDirectory(prefix = "breit-atomic-failure-").toFile()
        try {
            val file = File(root, "threads.json")
            file.writeText("previous safe payload")
            val tempAsDirectory = File(root, "threads.json.tmp")
            assertTrue(tempAsDirectory.mkdirs())
            File(tempAsDirectory, "block-delete").writeText("keep temp directory non-empty")

            val failed = runCatching { AtomicTextFileStore(file).writeText("new payload") }
            assertTrue(failed.isFailure)
            assertEquals("previous safe payload", file.readText())
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun preservesCorruptSnapshotForManualRecovery() {
        val root = createTempDirectory(prefix = "breit-atomic-corrupt-").toFile()
        try {
            val file = File(root, "threads.json")
            file.writeText("{broken json")

            val recovery = AtomicTextFileStore(file).preserveCorruptCopy()
            assertTrue(recovery?.isFile == true)
            assertEquals("{broken json", recovery?.readText())
            assertEquals("{broken json", file.readText())
        } finally {
            root.deleteRecursively()
        }
    }
}
