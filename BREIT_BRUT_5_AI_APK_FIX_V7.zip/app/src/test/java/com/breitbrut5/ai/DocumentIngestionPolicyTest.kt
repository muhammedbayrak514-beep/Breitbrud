package com.breitbrut5.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DocumentIngestionPolicyTest {
    @Test fun supportsTextPdfOfficeAndImageOcrExtensions() {
        assertTrue(DocumentIngestionPolicy.isSupported("notes.TXT"))
        assertTrue(DocumentIngestionPolicy.isSupported("book.pdf"))
        assertTrue(DocumentIngestionPolicy.isSupported("paper.docx"))
        assertTrue(DocumentIngestionPolicy.isSupported("slides.pptx"))
        assertTrue(DocumentIngestionPolicy.isSupported("sheet.xlsx"))
        assertTrue(DocumentIngestionPolicy.isSupported("scan.jpg"))
        assertTrue(DocumentIngestionPolicy.isSupported("scan.WEBP"))
    }

    @Test fun sanitizesNulAndControlCharactersButKeepsLineBreaks() {
        assertEquals("hello\nworld\t!", DocumentIngestionPolicy.sanitize("hello\u0000\nworld\t\u0007!"))
    }

    @Test fun boundsBatchSizeAndPerChatDocuments() {
        assertEquals(10, DocumentIngestionPolicy.MAX_BATCH_FILES)
        assertEquals(5, DocumentIngestionPolicy.MAX_ATTACHED_PER_CHAT)
        assertEquals(200, DocumentIngestionPolicy.MAX_PDF_PAGES)
        assertEquals(30, DocumentIngestionPolicy.MAX_OCR_PAGES_PER_PDF)
        assertEquals(25 * 1_048_576, DocumentIngestionPolicy.MAX_IMAGE_BYTES)
    }
}
