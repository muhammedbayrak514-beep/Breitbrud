package com.breitbrut5.ai

/** Testable preflight/stream guards for user-selected .litertlm files. */
internal object ModelImportPolicy {
    const val MAX_IMPORTED_MODEL_BYTES = 4L * 1024L * 1024L * 1024L

    enum class Issue { TOO_LARGE, LOW_STORAGE, PROVIDER_SIZE_MISMATCH, FREE_SPACE_GUARD, INCOMPLETE_COPY }

    fun preflightIssue(expectedBytes: Long?, availableBytes: Long): Issue? {
        if (expectedBytes != null && expectedBytes > MAX_IMPORTED_MODEL_BYTES) return Issue.TOO_LARGE
        val required = ModelStoragePolicy.requiredFreeBytes(expectedBytes ?: 0L)
        if (availableBytes < required) return Issue.LOW_STORAGE
        return null
    }

    fun progressIssue(copiedBytes: Long, expectedBytes: Long?, initiallyAvailableBytes: Long): Issue? {
        if (copiedBytes < 0L || copiedBytes > MAX_IMPORTED_MODEL_BYTES) return Issue.TOO_LARGE
        if (expectedBytes != null && copiedBytes > expectedBytes) return Issue.PROVIDER_SIZE_MISMATCH
        if (copiedBytes > initiallyAvailableBytes - ModelStoragePolicy.EXTRA_HEADROOM_BYTES) return Issue.FREE_SPACE_GUARD
        return null
    }

    fun completionIssue(copiedBytes: Long, expectedBytes: Long?): Issue? =
        if (expectedBytes != null && copiedBytes != expectedBytes) Issue.INCOMPLETE_COPY else null

    fun message(issue: Issue, expectedBytes: Long?, copiedBytes: Long, availableBytes: Long): String = when (issue) {
        Issue.TOO_LARGE -> "Model dosyası 4 GB içe aktarma sınırını aşıyor."
        Issue.LOW_STORAGE -> "Modeli kopyalamak için yaklaşık ${formatBytes(ModelStoragePolicy.requiredFreeBytes(expectedBytes ?: 0L))} boş alan gerekiyor; şu an ${formatBytes(availableBytes)} boş."
        Issue.PROVIDER_SIZE_MISMATCH -> "Dosya sağlayıcısı bildirdiği boyuttan daha fazla veri verdi; aktarım durduruldu."
        Issue.FREE_SPACE_GUARD -> "Kopyalama sırasında boş alan koruma sınırına ulaşıldı."
        Issue.INCOMPLETE_COPY -> "Model aktarımı eksik kaldı (${formatBytes(copiedBytes)} / ${formatBytes(expectedBytes ?: copiedBytes)}). Tekrar dene."
    }

    private fun formatBytes(bytes: Long): String = if (bytes >= 1_073_741_824L) {
        String.format(java.util.Locale("tr", "TR"), "%.2f GB", bytes / 1_073_741_824.0)
    } else String.format(java.util.Locale("tr", "TR"), "%.0f MB", bytes / 1_048_576.0)
}
