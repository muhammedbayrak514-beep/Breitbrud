package com.breitbrut5.ai

/** Vector provider contract shared by the local RAG store and optional embedding runtimes. */
internal interface LocalVectorEmbedder {
    /** Changes whenever the embedding model/artifact contract changes. */
    val modelId: String
    fun embedDocument(text: String): FloatArray
    fun embedQuery(text: String): FloatArray
}
