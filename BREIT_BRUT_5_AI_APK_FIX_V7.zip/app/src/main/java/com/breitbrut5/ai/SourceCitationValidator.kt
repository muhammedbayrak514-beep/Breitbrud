package com.breitbrut5.ai

/**
 * Validates citation-label integrity against the sources actually supplied to the model and runs
 * a conservative lexical claim/evidence audit. Neither operation proves semantic entailment.
 */
internal object SourceCitationValidator {
    private val citationPattern = Regex("(?<![A-Za-z0-9])\\[S[0-9]+]", RegexOption.IGNORE_CASE)

    fun validate(
        answer: String,
        availableSources: List<LocalSourceReference>,
        hasAttachedDocuments: Boolean,
        allowedDocumentIds: Set<String> = availableSources.map { it.documentId }.toSet()
    ): CitationAudit? {
        if (!hasAttachedDocuments) return null
        val validLabels = availableSources.map { normalize(it.label) }.filter { it.isNotBlank() }.toSet()
        val answerWithoutCode = answer.replace(Regex("(?s)```.*?```"), " ")
        val citedLabels = citationPattern.findAll(answerWithoutCode)
            .map { normalize(it.value) }
            .distinct()
            .toList()
        val invalidSourceLabels = availableSources
            .filter { it.documentId !in allowedDocumentIds }
            .map { normalize(it.label) }
            .distinct()
        return CitationAudit(
            citedLabels = citedLabels,
            unknownLabels = citedLabels.filterNot { it in validLabels },
            uncitedLabels = validLabels.filterNot { it in citedLabels }.sortedBy { label ->
                label.removePrefix("[S").removeSuffix("]").toIntOrNull() ?: Int.MAX_VALUE
            },
            noMatchingSources = availableSources.isEmpty(),
            invalidSourceLabels = invalidSourceLabels,
            claimFindings = ClaimEvidenceVerifier.evaluate(answer, availableSources)
        )
    }

    private fun normalize(label: String): String = label.trim().uppercase().replace(Regex("\\s+"), "")
}

internal fun interface EmbeddingFunction {
    fun embed(text: String): FloatArray
}

/** Pure math helper so vector behavior can be regression-tested without loading native ML libraries. */
internal object EmbeddingMath {
    fun cosineSimilarity(left: FloatArray, right: FloatArray): Double {
        if (left.isEmpty() || left.size != right.size) return Double.NaN
        var dot = 0.0
        var leftNorm = 0.0
        var rightNorm = 0.0
        for (index in left.indices) {
            val a = left[index].toDouble()
            val b = right[index].toDouble()
            if (!a.isFinite() || !b.isFinite()) return Double.NaN
            dot += a * b
            leftNorm += a * a
            rightNorm += b * b
        }
        val denominator = kotlin.math.sqrt(leftNorm) * kotlin.math.sqrt(rightNorm)
        return if (denominator <= 1e-12) Double.NaN else (dot / denominator).coerceIn(-1.0, 1.0)
    }
}
