package com.breitbrut5.ai

/** One storage policy shared by recommendations and downloads, so advice matches enforcement. */
internal object ModelStoragePolicy {
    const val MINIMUM_FREE_BYTES = 1_300_000_000L
    const val EXTRA_HEADROOM_BYTES = 350L * 1_048_576L

    fun requiredFreeBytes(modelBytes: Long): Long = maxOf(
        MINIMUM_FREE_BYTES,
        modelBytes.coerceAtLeast(0L) + EXTRA_HEADROOM_BYTES
    )

    fun hasEnoughSpace(freeBytes: Long, modelBytes: Long): Boolean = freeBytes >= requiredFreeBytes(modelBytes)
}

internal enum class DeviceRisk { LOW, MODERATE, HIGH }

internal data class DeviceReadiness(
    val risk: DeviceRisk,
    val score: Int,
    val checks: List<String>,
    val warning: String
)

/** Simple transparent readiness indicator, not a claim that a model is guaranteed to run. */
internal object DeviceReadinessScorer {
    fun assess(profile: DeviceProfile, model: ModelCatalogItem): DeviceReadiness {
        var score = 100
        val checks = mutableListOf<String>()
        val ramRatio = profile.totalRamBytes.toDouble() / model.minimumSuggestedRamBytes.coerceAtLeast(1L)
        when {
            ramRatio < 0.65 -> { score -= 55; checks += "Toplam RAM model önerisinin çok altında." }
            ramRatio < 1.0 -> { score -= 30; checks += "Toplam RAM önerilen seviyenin altında." }
            ramRatio < 1.35 -> { score -= 10; checks += "RAM payı sınırlı; arka plandaki uygulamaları kapatmak yardımcı olabilir." }
            else -> checks += "Toplam RAM önerilen seviyeye göre yeterli görünüyor."
        }
        val availableFloor = maxOf(750L * 1_048_576L, model.minimumSuggestedRamBytes / 3)
        if (profile.availableRamBytes < availableFloor) {
            score -= 25
            checks += "Şu anki kullanılabilir RAM düşük."
        } else checks += "Kullanılabilir RAM ilk kontrolü geçti."
        val required = ModelStoragePolicy.requiredFreeBytes(model.approxBytes)
        if (profile.freeStorageBytes < required) {
            score -= 60
            checks += "Boş alan yetersiz: en az ${formatBytes(required)} gerekiyor."
        } else checks += "Boş alan indirme eşiğini karşılıyor."
        score = score.coerceIn(0, 100)
        val risk = when {
            score >= 80 -> DeviceRisk.LOW
            score >= 50 -> DeviceRisk.MODERATE
            else -> DeviceRisk.HIGH
        }
        return DeviceReadiness(
            risk = risk,
            score = score,
            checks = checks,
            warning = when (risk) {
                DeviceRisk.LOW -> "İlk değerlendirme iyi; gerçek çalışma modeli ve arka uca göre değişebilir."
                DeviceRisk.MODERATE -> "Model çalışabilir ancak yavaşlık veya bellek hatası riski var."
                DeviceRisk.HIGH -> "Daha küçük model seç veya önce depolamada yer aç."
            }
        )
    }

    private fun formatBytes(bytes: Long): String = if (bytes >= 1_073_741_824L) {
        String.format(java.util.Locale("tr", "TR"), "%.1f GB", bytes / 1_073_741_824.0)
    } else String.format(java.util.Locale("tr", "TR"), "%.0f MB", bytes / 1_048_576.0)
}
