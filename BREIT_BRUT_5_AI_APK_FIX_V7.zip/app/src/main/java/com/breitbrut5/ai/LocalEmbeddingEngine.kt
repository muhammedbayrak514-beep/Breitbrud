package com.breitbrut5.ai

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.EmbeddingEngine
import com.google.ai.edge.litertlm.EmbeddingEngineConfig
import com.google.ai.edge.litertlm.InputData
import java.io.File
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicReference

/**
 * Official LiteRT-LM EmbeddingGemma 2 adapter. All native engine operations are serialized on one
 * dedicated worker because native model engines are not assumed to be thread-safe.
 */
internal class LiteRtLocalTextEmbedder(private val modelFile: File) : LocalVectorEmbedder {
    private val workerThread = AtomicReference<Thread?>()
    private val executor = Executors.newSingleThreadExecutor(ThreadFactory { runnable ->
        Thread(runnable, "breit-brut-embedding").apply { isDaemon = true; workerThread.set(this) }
    })
    @Volatile private var engine: EmbeddingEngine? = null

    override val modelId: String = "embeddinggemma2-text-270m-v1:litertlm-0.18.1"

    val isReady: Boolean get() = engine != null

    fun initialize() = onWorker {
        if (engine != null) return@onWorker
        require(modelFile.isFile && modelFile.length() >= LocalEmbeddingModelCatalog.MIN_VALID_BYTES) {
            "Embedding modeli bulunamadı veya dosya eksik."
        }
        require(LocalEmbeddingModelCatalog.verifyModelFile(modelFile)) {
            "Embedding modeli SHA-256 doğrulamasından geçmedi. Dosya etkinleştirilmedi."
        }
        // This text-only model uses CPU by default; it does not require GPU/native optional libraries.
        val candidate = EmbeddingEngine(
            EmbeddingEngineConfig(
                modelPath = modelFile.absolutePath,
                backend = Backend.CPU(),
                visionBackend = Backend.CPU(),
                audioBackend = Backend.CPU()
            )
        )
        // LiteRT-LM documents that an Engine whose initialize() failed must not be closed.
        candidate.initialize()
        engine = candidate
    }

    override fun embedDocument(text: String): FloatArray = embed(
        taskPrefix = DOCUMENT_PREFIX,
        text = text
    )

    override fun embedQuery(text: String): FloatArray = embed(
        taskPrefix = QUERY_PREFIX,
        text = text
    )

    private fun embed(taskPrefix: String, text: String): FloatArray = onWorker {
        require(text.isNotBlank()) { "Embedding için boş metin gönderilemez." }
        val active = engine ?: error("Anlamsal arama modeli yüklü değil.")
        val response = active.computeEmbedding(listOf(InputData.Text(taskPrefix + text.trim())))
        val raw: Any = response.embedding
        val vector = when (raw) {
            is FloatArray -> raw.copyOf()
            is DoubleArray -> FloatArray(raw.size) { raw[it].toFloat() }
            is List<*> -> raw.map { (it as? Number)?.toFloat() ?: Float.NaN }.toFloatArray()
            is Array<*> -> raw.map { (it as? Number)?.toFloat() ?: Float.NaN }.toFloatArray()
            else -> error("LiteRT-LM beklenmeyen embedding biçimi döndürdü: ${raw::class.java.name}")
        }
        require(vector.isNotEmpty() && vector.all { it.isFinite() }) {
            "Embedding modeli geçersiz veya boş bir vektör döndürdü."
        }
        vector
    }

    /** Close exactly once on the same worker which owns the native engine. */
    fun closeModel() = onWorker {
        val current = engine
        engine = null
        current?.close()
    }

    fun shutdown() {
        runCatching { closeModel() }
        executor.shutdown()
    }

    private fun <T> onWorker(block: () -> T): T {
        if (Thread.currentThread() === workerThread.get()) return block()
        try {
            return executor.submit(Callable { block() }).get()
        } catch (e: ExecutionException) {
            throw (e.cause ?: e)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            throw IllegalStateException("Embedding işlemi beklerken görev kesildi.", e)
        }
    }

    companion object {
        const val DOCUMENT_PREFIX = "task: search result | text: "
        const val QUERY_PREFIX = "task: search query | text: "
    }
}

/** Official LiteRT Community model artifact used for textual RAG. */
internal object LocalEmbeddingModelCatalog {
    const val FILE_NAME = "embeddinggemma-2-text-270m.litertlm"
    const val APPROX_BYTES = 165L * 1_048_576L
    const val MIN_VALID_BYTES = APPROX_BYTES * 8L / 10L
    const val MIN_SUGGESTED_RAM_BYTES = 2_000_000_000L
    const val LICENSE = "Apache-2.0"
    // SHA-256 from the published LiteRT Community model artifact. Refuse to activate a partial or
    // unexpected file so that a changed upstream artifact must be reviewed deliberately.
    const val SHA256 = "2d079ee2f6f066b1f368e8d7c819f55214eaef1d0513b312321901f30ab286fb"
    const val DOWNLOAD_URL = "https://huggingface.co/litert-community/embeddinggemma-2-text-270m-litert-lm/resolve/main/embeddinggemma-2-text-270m.litertlm?download=true"

    private fun markerFile(file: File) = File(file.parentFile, file.name + ".verified")

    /** Verifies first use, then uses an app-private length/mtime marker to avoid hashing 165 MB on every launch. */
    fun verifyModelFile(file: File): Boolean {
        if (!file.isFile || file.length() < MIN_VALID_BYTES) return false
        val marker = markerFile(file)
        val expectedRecord = "${file.length()}|${file.lastModified()}|$SHA256"
        if (marker.isFile && runCatching { marker.readText().trim() == expectedRecord }.getOrDefault(false)) {
            return true
        }
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(128 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        val actual = digest.digest().joinToString("") { byte -> "%02x".format(byte) }
        if (!actual.equals(SHA256, ignoreCase = true)) {
            marker.delete()
            return false
        }
        writeVerifiedMarker(file)
        return true
    }

    fun writeVerifiedMarker(file: File) {
        if (!file.isFile) return
        val marker = markerFile(file)
        val temp = File(file.parentFile, marker.name + ".tmp")
        temp.writeText("${file.length()}|${file.lastModified()}|$SHA256")
        if (!temp.renameTo(marker)) {
            marker.writeText(temp.readText())
            temp.delete()
        }
    }

    fun hasVerifiedMarker(file: File): Boolean {
        if (!file.isFile || file.length() < MIN_VALID_BYTES) return false
        val expectedRecord = "${file.length()}|${file.lastModified()}|$SHA256"
        return markerFile(file).let { marker ->
            marker.isFile && runCatching { marker.readText().trim() == expectedRecord }.getOrDefault(false)
        }
    }
}
