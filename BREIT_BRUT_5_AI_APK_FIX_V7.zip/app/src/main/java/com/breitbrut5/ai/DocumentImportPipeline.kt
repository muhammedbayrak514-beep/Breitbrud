package com.breitbrut5.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

/** Plain extracted content and provenance metadata prepared for local RAG indexing. */
internal data class ExtractedLocalDocument(
    val text: String,
    val mimeType: String,
    val extractionMethod: String,
    val pageCount: Int? = null,
    val sectionCount: Int? = null,
    val warnings: List<String> = emptyList()
)

/**
 * P4.4 local document ingestion. Text extraction and OCR run locally; only the extracted text is
 * passed to the existing RAG index. All inputs and decompressed content have explicit size limits.
 */
internal class DocumentImportPipeline(private val context: Context) {
    fun extract(uri: Uri, displayName: String): ExtractedLocalDocument {
        val extension = DocumentIngestionPolicy.extension(displayName)
        return when (extension) {
            "pdf" -> extractPdf(uri)
            "docx", "pptx", "xlsx" -> extractOffice(uri, extension)
            in IMAGE_EXTENSIONS -> extractImage(uri, extension)
            in PLAIN_TEXT_EXTENSIONS -> {
                val bytes = readBoundedBytes(uri, MAX_PLAIN_FILE_BYTES)
                val text = String(bytes, StandardCharsets.UTF_8).removePrefix("\uFEFF")
                ExtractedLocalDocument(
                    text = text,
                    mimeType = mimeFor(extension),
                    extractionMethod = "utf8_text"
                )
            }
            else -> throw IllegalArgumentException(
                "Bu dosya türü desteklenmiyor. TXT/MD/CSV/kod, metin tabanlı veya taranmış PDF, DOCX/PPTX/XLSX ve PNG/JPEG/WebP/BMP görsellerini deneyebilirsin."
            )
        }
    }

    /** Spool compressed Office input to an app-private temporary file so the full ZIP is not held in RAM. */
    private fun extractOffice(uri: Uri, extension: String): ExtractedLocalDocument {
        val source = File(context.cacheDir, "office-${System.nanoTime()}.$extension")
        try {
            copyUriToFile(uri, source, MAX_OFFICE_FILE_BYTES)
            val result = FileInputStream(source).use { input ->
                when (extension) {
                    "docx" -> OoxmlTextExtractor.extractDocx(input)
                    "pptx" -> OoxmlTextExtractor.extractPptx(input)
                    "xlsx" -> OoxmlTextExtractor.extractXlsx(input)
                    else -> error("Bilinmeyen Office dosyası.")
                }
            }
            val mime = when (extension) {
                "docx" -> DOCX_MIME
                "pptx" -> PPTX_MIME
                else -> XLSX_MIME
            }
            return ExtractedLocalDocument(
                text = result.text,
                mimeType = mime,
                extractionMethod = result.method,
                sectionCount = result.sectionCount.takeIf { it > 0 }
            )
        } finally {
            source.delete()
        }
    }

    private fun extractPdf(uri: Uri): ExtractedLocalDocument {
        val source = File(context.cacheDir, "document-${System.nanoTime()}.pdf")
        try {
            copyUriToFile(uri, source, MAX_PDF_FILE_BYTES)
            synchronized(PDF_INIT_LOCK) {
                if (!pdfInitialized) {
                    PDFBoxResourceLoader.init(context.applicationContext)
                    pdfInitialized = true
                }
            }
            PDDocument.load(source).use { document ->
                if (document.isEncrypted) error("Şifreli PDF okunamıyor. Şifresiz bir kopyasını seç.")
                val pages = document.numberOfPages
                if (pages <= 0) error("PDF içinde sayfa bulunamadı.")
                if (pages > MAX_PDF_PAGES) error("PDF en fazla $MAX_PDF_PAGES sayfa olabilir. Daha küçük bir bölüm seç.")

                val textByPage = Array(pages) { "" }
                val emptyPages = mutableListOf<Int>()
                var extractedCharacters = 0
                for (page in 1..pages) {
                    val stripper = PDFTextStripper().apply {
                        startPage = page
                        endPage = page
                        setSortByPosition(true)
                    }
                    val pageText = stripper.getText(document).trim()
                    textByPage[page - 1] = pageText
                    extractedCharacters += pageText.length
                    if (pageText.isBlank()) emptyPages += page
                    if (extractedCharacters > MAX_EXTRACTED_TEXT_CHARS) {
                        error("PDF'den çıkarılan metin ${MAX_EXTRACTED_TEXT_CHARS} karakter sınırını aşıyor.")
                    }
                }

                val ocrTextByPage = mutableMapOf<Int, String>()
                val warnings = mutableListOf<String>()
                var ocrAttempted = 0
                if (emptyPages.isNotEmpty()) {
                    var rendererFailure: String? = null
                    try {
                        ParcelFileDescriptor.open(source, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                            PdfRenderer(descriptor).use { renderer ->
                                withTextRecognizer { recognizer ->
                                    emptyPages.take(MAX_OCR_PAGES_PER_PDF).forEach { pageNumber ->
                                        val bitmap = try {
                                            renderPdfPage(renderer, pageNumber - 1)
                                        } catch (e: OutOfMemoryError) {
                                            rendererFailure = "OCR için bellek yetersiz kaldı."
                                            null
                                        } catch (e: Exception) {
                                            rendererFailure = e.message ?: "PDF sayfası görüntüye dönüştürülemedi."
                                            null
                                        } ?: return@forEach
                                        try {
                                            ocrAttempted++
                                            val recognized = recognize(recognizer, bitmap)
                                            if (recognized.isNotBlank()) ocrTextByPage[pageNumber] = recognized
                                        } catch (e: OutOfMemoryError) {
                                            rendererFailure = "OCR çalışırken bellek yetersiz kaldı."
                                        } catch (e: Exception) {
                                            rendererFailure = e.message ?: "OCR işlemi başarısız oldu."
                                        } finally {
                                            bitmap.recycle()
                                        }
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        rendererFailure = e.message ?: "PDF OCR başlatılamadı."
                    }
                    if (emptyPages.size > MAX_OCR_PAGES_PER_PDF) {
                        warnings += "Performans sınırı nedeniyle yalnızca ilk $MAX_OCR_PAGES_PER_PDF metinsiz sayfa OCR ile denendi."
                    }
                    val stillEmpty = emptyPages.filter { ocrTextByPage[it].isNullOrBlank() }
                    if (stillEmpty.isNotEmpty()) {
                        warnings += "Metin çıkarılamayan sayfalar (OCR sonrası): ${stillEmpty.take(12).joinToString()}${if (stillEmpty.size > 12) " ve ${stillEmpty.size - 12} sayfa daha" else ""}. Görüntü kalitesi veya el yazısı sonucu etkileyebilir."
                    }
                    if (ocrTextByPage.isNotEmpty()) {
                        warnings += "Bazı sayfalarda metin cihaz içi OCR ile çıkarıldı; sayfa görüntüsü ve dil kalitesi tanımayı etkileyebilir."
                    }
                    if (ocrAttempted == 0 && stillEmpty.isNotEmpty()) {
                        rendererFailure?.let { warnings += "OCR ayrıntısı: ${it.take(180)}" }
                    }
                }

                val output = StringBuilder()
                for (page in 1..pages) {
                    appendBounded(output, "\n\n[PDF sayfa $page]\n")
                    val pageText = textByPage[page - 1]
                    val ocrText = ocrTextByPage[page]
                    when {
                        pageText.isNotBlank() -> appendBounded(output, "$pageText\n")
                        !ocrText.isNullOrBlank() -> appendBounded(output, "[OCR ile çıkarıldı]\n$ocrText\n")
                        else -> appendBounded(output, "[Bu sayfadan metin çıkarılamadı]\n")
                    }
                }
                val finalText = output.toString().trim()
                if (textByPage.all { it.isBlank() } && ocrTextByPage.isEmpty()) {
                    val suffix = warnings.firstOrNull()?.let { " $it" }.orEmpty()
                    error("PDF'den okunabilir metin çıkarılamadı. Dosya taranmış, düşük çözünürlüklü veya el yazısı içerebilir.$suffix")
                }
                val method = when {
                    ocrTextByPage.isNotEmpty() && textByPage.any { it.isNotBlank() } -> "pdfbox_text+mlkit_ocr"
                    ocrTextByPage.isNotEmpty() -> "mlkit_ocr_pdf"
                    else -> "pdfbox_text"
                }
                return ExtractedLocalDocument(finalText, "application/pdf", method, pageCount = pages, warnings = warnings.distinct())
            }
        } finally {
            source.delete()
        }
    }

    private fun extractImage(uri: Uri, extension: String): ExtractedLocalDocument {
        val source = File(context.cacheDir, "ocr-image-${System.nanoTime()}.$extension")
        try {
            copyUriToFile(uri, source, MAX_IMAGE_FILE_BYTES)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(source.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) error("Görsel açılamadı veya biçimi desteklenmiyor.")
            if (bounds.outWidth.toLong() * bounds.outHeight.toLong() > MAX_IMAGE_PIXELS.toLong() * 64L) {
                error("Görsel çözünürlüğü güvenli işleme sınırının çok üzerinde.")
            }
            val sample = calculateSampleSize(bounds.outWidth, bounds.outHeight)
            val bitmap = try {
                BitmapFactory.decodeFile(source.absolutePath, BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }) ?: error("Görsel belleğe alınamadı.")
            } catch (_: OutOfMemoryError) {
                error("Görsel cihaz belleği için çok büyük. Daha küçük çözünürlüklü bir görsel seç.")
            }
            val text = try {
                withTextRecognizer { recognizer -> recognize(recognizer, bitmap) }
            } catch (_: OutOfMemoryError) {
                error("OCR için cihaz belleği yetersiz. Diğer uygulamaları kapatıp daha küçük bir görsel dene.")
            } finally {
                bitmap.recycle()
            }
            if (text.isBlank()) error("Görselden okunabilir metin çıkarılamadı. Daha net veya düz açıyla çekilmiş bir görüntü dene.")
            if (text.length > MAX_EXTRACTED_TEXT_CHARS) error("Görselden çıkarılan metin karakter sınırını aşıyor.")
            return ExtractedLocalDocument(
                text = "[Görsel OCR: ${extension.uppercase()}]\n$text",
                mimeType = mimeFor(extension),
                extractionMethod = "mlkit_ocr_image",
                warnings = listOf("Metin cihaz içi OCR ile çıkarıldı. Görüntü kalitesi, eğiklik ve el yazısı tanımayı etkileyebilir.")
            )
        } finally {
            source.delete()
        }
    }

    private fun renderPdfPage(renderer: PdfRenderer, index: Int): Bitmap {
        renderer.openPage(index).use { page ->
            val maxEdge = maxOf(page.width, page.height).coerceAtLeast(1)
            val scale = minOf(2.0, MAX_OCR_RENDER_EDGE.toDouble() / maxEdge.toDouble())
            val width = (page.width * scale).toInt().coerceAtLeast(1)
            val height = (page.height * scale).toInt().coerceAtLeast(1)
            val bitmap = try {
                Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            } catch (_: OutOfMemoryError) {
                error("PDF sayfası OCR için belleğe alınamadı. Daha küçük bir PDF bölümü seç.")
            }
            try {
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bitmap
            } catch (e: Exception) {
                bitmap.recycle()
                throw e
            }
        }
    }

    private fun calculateSampleSize(width: Int, height: Int): Int {
        var sample = 1
        while (sample < MAX_BITMAP_SAMPLE_SIZE && (width / sample > MAX_OCR_RENDER_EDGE * 2 || height / sample > MAX_OCR_RENDER_EDGE * 2 ||
            (width.toLong() / sample) * (height.toLong() / sample) > MAX_IMAGE_PIXELS)) {
            sample *= 2
        }
        if (width / sample > MAX_OCR_RENDER_EDGE * 2 || height / sample > MAX_OCR_RENDER_EDGE * 2 ||
            (width.toLong() / sample) * (height.toLong() / sample) > MAX_IMAGE_PIXELS) {
            error("Görsel cihazda güvenli OCR için çok yüksek çözünürlüklü. Daha küçük bir kopya seç.")
        }
        return sample
    }

    private fun <T> withTextRecognizer(block: (TextRecognizer) -> T): T {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            return block(recognizer)
        } finally {
            recognizer.close()
        }
    }

    private fun recognize(recognizer: TextRecognizer, bitmap: Bitmap): String {
        val image = InputImage.fromBitmap(bitmap, 0)
        return Tasks.await(recognizer.process(image), OCR_TIMEOUT_SECONDS, TimeUnit.SECONDS).text.trim()
    }

    private fun readBoundedBytes(uri: Uri, limit: Int): ByteArray {
        val input = context.contentResolver.openInputStream(uri) ?: error("Seçilen dosya açılamadı.")
        input.use { source ->
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val count = source.read(buffer)
                if (count < 0) break
                total += count
                if (total > limit) error("Dosya ${limit / 1_048_576} MB boyut sınırını aşıyor.")
                output.write(buffer, 0, count)
            }
            return output.toByteArray()
        }
    }

    private fun copyUriToFile(uri: Uri, outputFile: File, limit: Int) {
        val input = context.contentResolver.openInputStream(uri) ?: error("Seçilen dosya açılamadı.")
        input.use { source ->
            FileOutputStream(outputFile).use { output ->
                val buffer = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val count = source.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > limit) error("Dosya ${limit / 1_048_576} MB boyut sınırını aşıyor.")
                    output.write(buffer, 0, count)
                }
                output.fd.sync()
            }
        }
    }

    private fun appendBounded(output: StringBuilder, value: String) {
        val remaining = MAX_EXTRACTED_TEXT_CHARS - output.length
        if (remaining <= 0 || value.length > remaining) error("Belgeden çıkarılan metin $MAX_EXTRACTED_TEXT_CHARS karakter sınırını aşıyor.")
        output.append(value)
    }

    private fun mimeFor(extension: String): String = when (extension) {
        "md", "markdown" -> "text/markdown"
        "csv" -> "text/csv"
        "json" -> "application/json"
        "xml" -> "application/xml"
        "html", "htm" -> "text/html"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "bmp" -> "image/bmp"
        else -> "text/plain"
    }

    companion object {
        private val PDF_INIT_LOCK = Any()
        @Volatile private var pdfInitialized = false
        const val OCR_TIMEOUT_SECONDS = 45L
        const val MAX_OCR_PAGES_PER_PDF = DocumentIngestionPolicy.MAX_OCR_PAGES_PER_PDF
        const val MAX_OCR_RENDER_EDGE = 1800
        const val MAX_IMAGE_PIXELS = 4_000_000L
        const val MAX_BITMAP_SAMPLE_SIZE = 64
        const val MAX_IMAGE_FILE_BYTES = DocumentIngestionPolicy.MAX_IMAGE_BYTES
        const val MAX_PLAIN_FILE_BYTES = DocumentIngestionPolicy.MAX_PLAIN_BYTES
        const val MAX_PDF_FILE_BYTES = DocumentIngestionPolicy.MAX_PDF_BYTES
        const val MAX_OFFICE_FILE_BYTES = DocumentIngestionPolicy.MAX_OFFICE_BYTES
        const val MAX_EXTRACTED_TEXT_CHARS = DocumentIngestionPolicy.MAX_EXTRACTED_CHARS
        const val MAX_PDF_PAGES = DocumentIngestionPolicy.MAX_PDF_PAGES
        const val DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        const val PPTX_MIME = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        const val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        val PLAIN_TEXT_EXTENSIONS = DocumentIngestionPolicy.plainTextExtensions
        val IMAGE_EXTENSIONS = DocumentIngestionPolicy.imageExtensions
    }
}
