package com.breitbrut5.ai

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Local corruption/change detection for model files. The digest is not a publisher signature and
 * cannot prove that the first downloaded/imported bytes were authentic; it detects later changes.
 */
internal object ModelArtifactIntegrity {
    enum class Result { VERIFIED_EXISTING_FINGERPRINT, CREATED_FIRST_FINGERPRINT }

    private data class CachedValidation(val size: Long, val modifiedAt: Long, val digest: String)
    private val validated = ConcurrentHashMap<String, CachedValidation>()

    fun manifestFile(modelFile: File): File = File(modelFile.parentFile, modelFile.name + ".integrity")

    fun initialize(modelFile: File): String {
        require(modelFile.isFile && modelFile.length() > 0L) { "Model dosyası boş veya bulunamadı." }
        val digest = sha256(modelFile)
        writeManifest(modelFile, digest)
        remember(modelFile, digest)
        return digest
    }

    fun verifyOrCreate(modelFile: File): Result {
        require(modelFile.isFile && modelFile.length() > 0L) { "Model dosyası boş veya bulunamadı." }
        val manifest = manifestFile(modelFile)
        if (!manifest.isFile) {
            initialize(modelFile)
            return Result.CREATED_FIRST_FINGERPRINT
        }
        val lines = manifest.readLines(Charsets.UTF_8)
        require(lines.size >= 2) { "Model bütünlük kaydı bozuk; modeli yeniden içe aktar." }
        val expectedSize = lines[0].toLongOrNull() ?: error("Model bütünlük kaydındaki boyut geçersiz.")
        val expectedDigest = lines[1].trim().lowercase()
        require(expectedDigest.matches(Regex("[0-9a-f]{64}"))) { "Model bütünlük kaydındaki SHA-256 geçersiz." }
        require(modelFile.length() == expectedSize) { "Model dosyasının boyutu bütünlük kaydıyla eşleşmiyor. Yeniden indir veya içe aktar." }
        val key = modelFile.absolutePath
        val cached = validated[key]
        if (cached != null && cached.size == modelFile.length() && cached.modifiedAt == modelFile.lastModified() && cached.digest == expectedDigest) {
            return Result.VERIFIED_EXISTING_FINGERPRINT
        }
        val actual = sha256(modelFile)
        require(actual == expectedDigest) { "Model dosyası son kontrolden sonra değişmiş veya bozulmuş. Dosyayı yeniden indir/içe aktar." }
        remember(modelFile, actual)
        return Result.VERIFIED_EXISTING_FINGERPRINT
    }

    fun deleteManifest(modelFile: File) {
        validated.remove(modelFile.absolutePath)
        manifestFile(modelFile).delete()
    }

    private fun writeManifest(file: File, digest: String) {
        AtomicTextFileStore(manifestFile(file)).writeText("${file.length()}\n$digest\n")
    }

    private fun remember(file: File, digest: String) {
        validated[file.absolutePath] = CachedValidation(file.length(), file.lastModified(), digest)
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
