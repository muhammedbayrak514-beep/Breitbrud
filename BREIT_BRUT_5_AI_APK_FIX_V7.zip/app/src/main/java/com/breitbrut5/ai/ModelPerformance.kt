package com.breitbrut5.ai

import java.io.File
import java.nio.charset.StandardCharsets
import java.util.Base64
import kotlin.math.ceil

/** Privacy-preserving runtime event. Never put prompts, answers, document text or raw exception messages here. */
internal data class InferenceSample(
    val modelName: String,
    val backendLabel: String,
    val durationMs: Long,
    val outputCharacters: Int,
    val completedAt: Long,
    val eventType: String = EVENT_INFERENCE,
    val outcome: String = OUTCOME_SUCCESS,
    /** Android system available RAM snapshots, not model-specific peak allocation. */
    val availableRamBeforeBytes: Long = -1L,
    val availableRamAfterBytes: Long = -1L,
    /** Time until the first non-empty model chunk; -1 means unavailable. */
    val firstChunkLatencyMs: Long = -1L,
    /** True only for the first model initialization in this app process. */
    val firstModelLoadThisProcess: Boolean = false,
    /** Bounded category (e.g. backend_failure), not raw exception text. */
    val errorCategory: String = ""
) {
    companion object {
        const val EVENT_INFERENCE = "inference"
        const val EVENT_MODEL_LOAD = "model_load"
        const val OUTCOME_SUCCESS = "success"
        const val OUTCOME_FAILURE = "failure"
        const val OUTCOME_CANCELLED = "cancelled"
    }
}

internal data class PerformanceSummary(
    val sampleCount: Int,
    val medianDurationMs: Long,
    val charactersPerSecond: Double,
    val successCount: Int = sampleCount,
    val failureCount: Int = 0,
    val cancelledCount: Int = 0,
    val p90DurationMs: Long = medianDurationMs,
    val medianFirstChunkLatencyMs: Long? = null,
    /** Signed available-system-RAM change; not a peak-memory measurement. */
    val medianAvailableRamChangeBytes: Long? = null
)

internal data class ModelLoadSummary(
    val sampleCount: Int,
    val medianDurationMs: Long,
    val firstLoadCount: Int,
    val failureCount: Int,
    val cancelledCount: Int,
    val firstProcessLoadMedianMs: Long? = null,
    val subsequentLoadMedianMs: Long? = null
)

internal object PerformanceMath {
    fun summarize(samples: List<InferenceSample>): PerformanceSummary? {
        val inference = samples.filter { it.eventType == InferenceSample.EVENT_INFERENCE }
        if (inference.isEmpty()) return null
        val successful = inference.filter { it.outcome == InferenceSample.OUTCOME_SUCCESS && it.durationMs > 0 }
        if (successful.isEmpty() && inference.none { it.outcome == InferenceSample.OUTCOME_FAILURE || it.outcome == InferenceSample.OUTCOME_CANCELLED }) return null
        val durations = successful.map { it.durationMs }.sorted()
        val median = median(durations) ?: 0L
        val totalDuration = successful.sumOf { it.durationMs }.coerceAtLeast(1L)
        val totalCharacters = successful.sumOf { it.outputCharacters.coerceAtLeast(0).toLong() }
        val firstChunks = successful.map { it.firstChunkLatencyMs }.filter { it > 0 }
        val ramChanges = successful.mapNotNull { sample ->
            if (sample.availableRamBeforeBytes >= 0 && sample.availableRamAfterBytes >= 0) {
                sample.availableRamAfterBytes - sample.availableRamBeforeBytes
            } else null
        }
        return PerformanceSummary(
            sampleCount = successful.size,
            medianDurationMs = median,
            charactersPerSecond = totalCharacters * 1000.0 / totalDuration,
            successCount = successful.size,
            failureCount = inference.count { it.outcome == InferenceSample.OUTCOME_FAILURE },
            cancelledCount = inference.count { it.outcome == InferenceSample.OUTCOME_CANCELLED },
            p90DurationMs = percentile90(durations) ?: 0L,
            medianFirstChunkLatencyMs = median(firstChunks),
            medianAvailableRamChangeBytes = median(ramChanges)
        )
    }

    fun summarizeModelLoads(samples: List<InferenceSample>): ModelLoadSummary? {
        val loads = samples.filter { it.eventType == InferenceSample.EVENT_MODEL_LOAD }
        if (loads.isEmpty()) return null
        val successful = loads.filter { it.outcome == InferenceSample.OUTCOME_SUCCESS && it.durationMs > 0 }
        val processFirst = successful.filter { it.firstModelLoadThisProcess }
        val subsequent = successful.filterNot { it.firstModelLoadThisProcess }
        return ModelLoadSummary(
            sampleCount = successful.size,
            medianDurationMs = median(successful.map { it.durationMs }) ?: 0L,
            firstLoadCount = processFirst.size,
            failureCount = loads.count { it.outcome == InferenceSample.OUTCOME_FAILURE },
            cancelledCount = loads.count { it.outcome == InferenceSample.OUTCOME_CANCELLED },
            firstProcessLoadMedianMs = median(processFirst.map { it.durationMs }),
            subsequentLoadMedianMs = median(subsequent.map { it.durationMs })
        )
    }

    private fun median(values: List<Long>): Long? {
        if (values.isEmpty()) return null
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 1) sorted[middle]
        else ((sorted[middle - 1].toDouble() + sorted[middle].toDouble()) / 2.0).toLong()
    }

    private fun percentile90(sortedValues: List<Long>): Long? {
        if (sortedValues.isEmpty()) return null
        return sortedValues[(ceil(sortedValues.size * 0.90).toInt() - 1).coerceIn(sortedValues.indices)]
    }
}

/** Bounded atomic telemetry. V1 five-field records are still read during upgrade. */
internal class LocalPerformanceTelemetry(private val file: File, private val maxSamples: Int = 120) {
    private val store = AtomicTextFileStore(file)
    private val lock = Any()

    fun load(): List<InferenceSample> = synchronized(lock) {
        store.readTextOrNull().orEmpty().lineSequence()
            .filter { it.isNotBlank() }
            .mapNotNull(::decode)
            .toList()
            .takeLast(maxSamples.coerceAtLeast(1))
    }

    fun record(sample: InferenceSample) = synchronized(lock) {
        require(sample.durationMs >= 0L) { "durationMs cannot be negative" }
        require(sample.outputCharacters >= 0) { "outputCharacters cannot be negative" }
        val current = store.readTextOrNull().orEmpty().lineSequence()
            .filter { it.isNotBlank() }
            .mapNotNull(::decode)
            .toList()
        val next = (current + sample).takeLast(maxSamples.coerceAtLeast(1))
        store.writeText(next.joinToString(separator = "\n", postfix = if (next.isEmpty()) "" else "\n", transform = ::encode))
    }

    fun clear() = synchronized(lock) { store.writeText("") }

    private fun encode(sample: InferenceSample): String = listOf(
        b64(sample.modelName), b64(sample.backendLabel), sample.durationMs.toString(),
        sample.outputCharacters.toString(), sample.completedAt.toString(), b64(sample.eventType),
        b64(sample.outcome), sample.availableRamBeforeBytes.toString(), sample.availableRamAfterBytes.toString(),
        sample.firstChunkLatencyMs.toString(), if (sample.firstModelLoadThisProcess) "1" else "0", b64(sample.errorCategory.ifBlank { "-" })
    ).joinToString("\t")

    private fun decode(line: String): InferenceSample? = runCatching {
        val fields = line.split('\t')
        require(fields.size == 5 || fields.size == 12)
        InferenceSample(
            modelName = unb64(fields[0]),
            backendLabel = unb64(fields[1]),
            durationMs = fields[2].toLong().also { require(it >= 0) },
            outputCharacters = fields[3].toInt().also { require(it >= 0) },
            completedAt = fields[4].toLong(),
            eventType = if (fields.size == 12) unb64(fields[5]) else InferenceSample.EVENT_INFERENCE,
            outcome = if (fields.size == 12) unb64(fields[6]) else InferenceSample.OUTCOME_SUCCESS,
            availableRamBeforeBytes = if (fields.size == 12) fields[7].toLong() else -1L,
            availableRamAfterBytes = if (fields.size == 12) fields[8].toLong() else -1L,
            firstChunkLatencyMs = if (fields.size == 12) fields[9].toLong() else -1L,
            firstModelLoadThisProcess = fields.size == 12 && fields[10] == "1",
            errorCategory = if (fields.size == 12) unb64(fields[11]).let { if (it == "-") "" else it } else ""
        ).also {
            require(it.eventType in setOf(InferenceSample.EVENT_INFERENCE, InferenceSample.EVENT_MODEL_LOAD))
            require(it.outcome in setOf(InferenceSample.OUTCOME_SUCCESS, InferenceSample.OUTCOME_FAILURE, InferenceSample.OUTCOME_CANCELLED))
        }
    }.getOrNull()

    private fun b64(value: String): String = Base64.getUrlEncoder().withoutPadding()
        .encodeToString(value.toByteArray(StandardCharsets.UTF_8))
    private fun unb64(value: String): String = String(Base64.getUrlDecoder().decode(value), StandardCharsets.UTF_8)
}
