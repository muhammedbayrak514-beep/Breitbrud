package com.breitbrut5.ai

/** Device-aware recommendation is advisory only; real model fit depends on runtime/backend. */
internal enum class ModelFit(val label: String) {
    RECOMMENDED("Önerilen"),
    CAUTION("Dikkatli dene"),
    NOT_RECOMMENDED("Şimdilik önerilmez")
}

internal data class ModelSuitability(
    val model: ModelCatalogItem,
    val fit: ModelFit,
    val reasons: List<String>,
    val requiredFreeStorageBytes: Long,
    val recommendedOutputTokens: Int
)

internal object DeviceModelAdvisor {
    fun rank(profile: DeviceProfile, catalog: List<ModelCatalogItem> = ModelCatalog.items): List<ModelSuitability> =
        catalog.map { assess(profile, it) }.sortedWith(
            compareBy<ModelSuitability> { it.fit.ordinal }
                .thenBy { it.model.approxBytes }
        )

    fun assess(profile: DeviceProfile, model: ModelCatalogItem): ModelSuitability {
        // Must align with the current downloader's hard 1.3 GB free-space gate as well as model size.
        val requiredStorage = ModelStoragePolicy.requiredFreeBytes(model.approxBytes)
        val ramFloor = maxOf(MIN_ABSOLUTE_AVAILABLE_RAM_BYTES, model.minimumSuggestedRamBytes / 3)
        val enoughTotalRam = profile.totalRamBytes >= model.minimumSuggestedRamBytes
        val enoughAvailableRam = profile.availableRamBytes >= ramFloor
        val enoughStorage = profile.freeStorageBytes >= requiredStorage
        val reasons = buildList {
            if (!enoughTotalRam) add("Önerilen toplam RAM: ${formatBytes(model.minimumSuggestedRamBytes)}; bu cihaz daha düşük görünüyor.")
            if (!enoughAvailableRam) add("Şu anki boş RAM düşük; diğer uygulamaları kapatıp tekrar değerlendir.")
            if (!enoughStorage) add("İndirme için yaklaşık ${formatBytes(requiredStorage)} boş depolama gerekiyor.")
            if (enoughTotalRam && enoughAvailableRam && enoughStorage) add("RAM ve boş depolama ilk değerlendirmede yeterli görünüyor.")
        }
        val fit = when {
            profile.totalRamBytes < model.minimumSuggestedRamBytes * 2 / 3 -> ModelFit.NOT_RECOMMENDED
            !enoughStorage -> ModelFit.NOT_RECOMMENDED
            enoughTotalRam && enoughAvailableRam && enoughStorage -> ModelFit.RECOMMENDED
            else -> ModelFit.CAUTION
        }
        return ModelSuitability(
            model = model,
            fit = fit,
            reasons = reasons,
            requiredFreeStorageBytes = requiredStorage,
            recommendedOutputTokens = recommendedOutputTokens(profile, model)
        )
    }


    /** Conservative output cap suggestion from current available memory, not a model capability guarantee. */
    fun recommendedOutputTokens(profile: DeviceProfile, model: ModelCatalogItem): Int {
        val available = profile.availableRamBytes
        val minRam = model.minimumSuggestedRamBytes
        return when {
            available < MIN_ABSOLUTE_AVAILABLE_RAM_BYTES || profile.totalRamBytes < minRam * 2 / 3 -> 128
            available < 1_500L * 1_048_576L || profile.totalRamBytes < minRam -> 256
            available < 2_500L * 1_048_576L -> 512
            available < 3_500L * 1_048_576L -> 768
            else -> 1024
        }
    }

    private fun formatBytes(bytes: Long): String = if (bytes >= 1_073_741_824L) {
        String.format(java.util.Locale("tr", "TR"), "%.1f GB", bytes / 1_073_741_824.0)
    } else String.format(java.util.Locale("tr", "TR"), "%.0f MB", bytes / 1_048_576.0)

    const val MIN_DOWNLOAD_HEADROOM_BYTES = ModelStoragePolicy.EXTRA_HEADROOM_BYTES
    const val MIN_ABSOLUTE_FREE_STORAGE_BYTES = ModelStoragePolicy.MINIMUM_FREE_BYTES
    const val MIN_ABSOLUTE_AVAILABLE_RAM_BYTES = 750L * 1_048_576L
}
