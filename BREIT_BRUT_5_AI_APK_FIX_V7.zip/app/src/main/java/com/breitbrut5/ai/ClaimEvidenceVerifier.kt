package com.breitbrut5.ai

import java.util.Locale

/**
 * Conservative lexical evidence audit for answer sentences.
 *
 * This is deliberately NOT called semantic fact verification: token overlap can detect obvious
 * source mismatches but cannot determine entailment, negation, causality or numerical correctness.
 */
internal object ClaimEvidenceVerifier {
    private val labelPattern = Regex("(?<![A-Za-z0-9])\\[S[0-9]+]", RegexOption.IGNORE_CASE)
    private val sentenceBoundary = Regex("(?<=[.!?])\\s+|\\n+")
    private val tokenPattern = Regex("[\\p{L}\\p{N}]{2,}")
    private val numericPattern = Regex("(?<![\\p{L}])\\d+(?:[.,]\\d+)?\\s?%?")
    private val stopWords = setOf(
        "ve", "veya", "ile", "için", "ama", "ancak", "fakat", "gibi", "olan", "olarak", "daha", "çok", "az",
        "bir", "bu", "şu", "o", "da", "de", "ki", "mi", "mı", "mu", "mü", "ise", "her", "hem", "en",
        "the", "and", "or", "for", "with", "from", "that", "this", "are", "was", "were", "has", "have", "had",
        "into", "not", "but", "can", "will", "its", "their", "they", "you", "your", "about", "than", "then"
    )

    fun evaluate(answer: String, sources: List<LocalSourceReference>, maxFindings: Int = 30): List<ClaimEvidenceFinding> {
        if (answer.isBlank() || sources.isEmpty()) return emptyList()
        val withoutCode = answer.replace(Regex("(?s)```.*?```"), " ")
        val normalizedAnswer = withoutCode.replace(Regex("(?m)^\\s{0,3}#{1,6}\\s+"), "")
        val sourceByLabel = sources.associateBy { normalizeLabel(it.label) }
        val findings = mutableListOf<ClaimEvidenceFinding>()

        normalizedAnswer.split(sentenceBoundary).forEach { rawSentence ->
            if (findings.size >= maxFindings) return@forEach
            val sentence = rawSentence.trim()
                .replace(Regex("^\\s*(?:[-*+]\\s+|\\d+[.)]\\s+)"), "")
                .replace(Regex("\\s+"), " ")
            if (sentence.length < 24) return@forEach
            if (sentence.startsWith("http://", true) || sentence.startsWith("https://", true)) return@forEach
            val labels = labelPattern.findAll(sentence).map { normalizeLabel(it.value) }.distinct().toList()
            val claimTokens = contentTokens(labelPattern.replace(sentence, " "))
            if (claimTokens.size < 4) return@forEach
            if (labels.isEmpty()) {
                findings += ClaimEvidenceFinding(
                    claimExcerpt = sentence.take(220),
                    citedLabels = emptyList(),
                    matchedLabels = emptyList(),
                    bestLexicalOverlap = 0.0,
                    status = ClaimEvidenceStatus.UNCITED
                )
                return@forEach
            }

            val resolvedSources = labels.mapNotNull { sourceByLabel[it] }
            if (resolvedSources.isEmpty() || labels.any { it !in sourceByLabel }) {
                findings += ClaimEvidenceFinding(
                    claimExcerpt = sentence.take(220), citedLabels = labels.map(::displayLabel),
                    matchedLabels = emptyList(), bestLexicalOverlap = 0.0,
                    status = ClaimEvidenceStatus.UNKNOWN_SOURCE
                )
                return@forEach
            }
            val sourceScores = resolvedSources.map { source ->
                val sourceTokens = contentTokens(source.excerpt)
                val overlap = if (claimTokens.isEmpty()) 0.0 else claimTokens.count { it in sourceTokens }.toDouble() / claimTokens.size
                source.label to overlap
            }
            val bestScore = sourceScores.maxOfOrNull { it.second } ?: 0.0
            val matchedLabels = sourceScores.filter { it.second >= LEXICAL_MATCH_THRESHOLD }
                .map { it.first }
                .distinct()
            val claimNumbers = numericPattern.findAll(labelPattern.replace(sentence, " "))
                .map { normalizeNumber(it.value) }.distinct().toList()
            val citedSourceNumbers = resolvedSources.flatMap { source ->
                numericPattern.findAll(source.excerpt).map { normalizeNumber(it.value) }.toList()
            }.toSet()
            val unmatchedNumbers = claimNumbers.filterNot { it in citedSourceNumbers }
            val status = when {
                unmatchedNumbers.isNotEmpty() -> ClaimEvidenceStatus.UNSUPPORTED_NUMERIC
                bestScore >= LEXICAL_MATCH_THRESHOLD -> ClaimEvidenceStatus.LEXICAL_MATCH
                bestScore >= WEAK_MATCH_THRESHOLD -> ClaimEvidenceStatus.WEAK_LEXICAL_MATCH
                else -> ClaimEvidenceStatus.NO_LEXICAL_MATCH
            }
            findings += ClaimEvidenceFinding(
                claimExcerpt = sentence.take(220),
                citedLabels = labels.map(::displayLabel),
                matchedLabels = matchedLabels,
                bestLexicalOverlap = bestScore,
                status = status,
                unmatchedNumericValues = unmatchedNumbers
            )
        }
        return findings
    }

    internal fun contentTokens(value: String): Set<String> = tokenPattern.findAll(value.lowercase(Locale("tr", "TR")))
        .map { it.value }
        .filter { it !in stopWords && !it.all(Char::isDigit) }
        .toSet()

    private fun normalizeLabel(value: String): String = value.trim().uppercase(Locale.ROOT).replace(Regex("\\s+"), "")
    private fun normalizeNumber(value: String): String = value.replace(Regex("\\s+"), "").replace(',', '.')
    private fun displayLabel(normalized: String): String = normalized

    const val LEXICAL_MATCH_THRESHOLD = 0.30
    const val WEAK_MATCH_THRESHOLD = 0.12
}
