package com.breitbrut5.ai

/** Pure limits and normalization rules shared by the P4.4 ingestion pipeline and tests. */
internal object DocumentIngestionPolicy {
    const val MAX_BATCH_FILES = 10
    const val MAX_ATTACHED_PER_CHAT = 5
    const val MAX_EXTRACTED_CHARS = 1_500_000
    const val MAX_PDF_PAGES = 200
    const val MAX_PLAIN_BYTES = 1_500_000
    const val MAX_PDF_BYTES = 25 * 1_048_576
    const val MAX_OFFICE_BYTES = 20 * 1_048_576
    const val MAX_IMAGE_BYTES = 25 * 1_048_576
    const val MAX_OCR_PAGES_PER_PDF = 30

    val imageExtensions = setOf("png", "jpg", "jpeg", "webp", "bmp")

    val officeExtensions = setOf("docx", "pptx", "xlsx")

    val plainTextExtensions = setOf(
        "txt", "md", "markdown", "csv", "json", "xml", "html", "htm", "css", "js",
        "kt", "kts", "java", "py", "sql", "log", "yaml", "yml", "toml", "sh", "properties"
    )

    fun extension(displayName: String): String = displayName.substringAfterLast('.', "").lowercase()
    fun isSupported(displayName: String): Boolean = extension(displayName) in plainTextExtensions ||
        extension(displayName) in setOf("pdf") || extension(displayName) in officeExtensions || extension(displayName) in imageExtensions

    fun sanitize(content: String): String = content
        .replace("\u0000", "")
        .filter { ch -> ch == '\n' || ch == '\r' || ch == '\t' || !Character.isISOControl(ch) }
        .trim()
}
