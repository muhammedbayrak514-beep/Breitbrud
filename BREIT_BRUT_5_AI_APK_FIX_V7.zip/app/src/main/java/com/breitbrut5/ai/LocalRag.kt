package com.breitbrut5.ai

import java.io.File
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Base64
import java.util.Locale
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

/** One persisted, stable chunk. Offsets refer to the original document's UTF-16 character range. */
internal data class RagChunk(
    val id: String,
    val documentId: String,
    val documentName: String,
    val ordinal: Int,
    val startOffset: Int,
    val text: String,
    val endOffset: Int = startOffset + text.length
)

/** Test/fallback reranker seam; the production path uses persisted vectors from LocalVectorEmbedder. */
internal fun interface LocalEmbeddingReranker {
    fun rerank(query: String, lexicalCandidates: List<RagChunk>): List<RagChunk>
}

/** Prevent repeated imports in one chat, including P2 documents which have no stored fingerprint yet. */
internal fun findDuplicateLocalDocument(
    documents: List<LocalDocument>,
    requestedContentHash: String,
    loadLegacyContent: (LocalDocument) -> String?
): LocalDocument? {
    if (requestedContentHash.isBlank()) return null
    return documents.firstOrNull { document ->
        val knownHash = document.contentHash.takeIf { it.isNotBlank() }
            ?: loadLegacyContent(document)?.let(LocalRagIndexStore::fingerprint)
        knownHash == requestedContentHash
    }
}

/**
 * Dependency-free local retrieval index. BM25 + TF-IDF cosine form the always-available hybrid baseline.
 * A local embedding reranker can optionally be injected; failures always fall back to lexical ranking.
 * No network service, API key, hosted vector database, or embedding model is required by the default path.
 */
internal class LocalRagIndexStore(
    private val directory: File,
    embeddingReranker: LocalEmbeddingReranker? = null
) {
    @Volatile private var optionalEmbeddingReranker: LocalEmbeddingReranker? = embeddingReranker
    @Volatile private var vectorEmbedder: LocalVectorEmbedder? = null

    init { directory.mkdirs() }

    /** Compatibility seam for tests and secondary rerankers; the production path uses persisted vectors. */
    fun setEmbeddingReranker(reranker: LocalEmbeddingReranker?) {
        optionalEmbeddingReranker = reranker
    }

    /** Attach or detach the real local embedding runtime. Existing lexical search never depends on it. */
    fun setVectorEmbedder(embedder: LocalVectorEmbedder?) {
        vectorEmbedder = embedder
    }

    /** Rebuilds vector sidecars for every persisted document using the currently attached model. */
    @Synchronized
    fun rebuildAllEmbeddings(): Int {
        val provider = vectorEmbedder ?: return 0
        var rebuilt = 0
        directory.listFiles().orEmpty().filter { it.isFile && it.name.endsWith(".rag") }.forEach { file ->
            val id = file.name.removeSuffix(".rag")
            if (!isSafeId(id)) return@forEach
            val chunks = readDocumentChunks(id).orEmpty()
            if (chunks.isEmpty()) {
                vectorFile(id).delete()
                return@forEach
            }
            // Keep reusable vectors across app launches. Re-embed only when the document chunks or
            // embedding model contract changed, avoiding a full 165 MB model pass at every startup.
            if (hasCompleteVectors(id, chunks, provider.modelId)) return@forEach
            runCatching { persistVectors(id, chunks, provider) }
                .onSuccess { rebuilt++ }
                .onFailure { vectorFile(id).delete() }
        }
        return rebuilt
    }

    /** Removes cached vectors without touching the BM25/TF-IDF index. */
    @Synchronized
    fun clearAllEmbeddings() {
        directory.listFiles().orEmpty().filter {
            it.name.endsWith(".vec") || it.name.endsWith(".vec.tmp")
        }.forEach { it.delete() }
    }

    @Synchronized
    fun hasIndex(documentId: String): Boolean = isSafeId(documentId) && indexFile(documentId).isFile

    @Synchronized
    fun upsertDocument(documentId: String, documentName: String, content: String) {
        require(isSafeId(documentId)) { "Geçersiz belge kimliği." }
        val chunks = chunkDocument(documentId, documentName, content)
        val target = indexFile(documentId)
        val temp = File(directory, "${documentId}.rag.tmp")
        val encoder = Base64.getUrlEncoder().withoutPadding()
        temp.bufferedWriter(StandardCharsets.UTF_8).use { writer ->
            writer.append(HEADER).append('\t')
                .append(encode(encoder, documentName)).append('\t')
                .append(fingerprint(content)).append('\n')
            for (chunk in chunks) {
                writer.append(chunk.id).append('\t')
                    .append(chunk.ordinal.toString()).append('\t')
                    .append(chunk.startOffset.toString()).append('\t')
                    .append(chunk.endOffset.toString()).append('\t')
                    .append(encode(encoder, chunk.text)).append('\n')
            }
        }
        try {
            java.nio.file.Files.move(
                temp.toPath(), target.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                java.nio.file.StandardCopyOption.ATOMIC_MOVE
            )
        } catch (_: java.nio.file.AtomicMoveNotSupportedException) {
            java.nio.file.Files.move(temp.toPath(), target.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        }
        // An old vector sidecar must never survive a content replacement when embedding is disabled
        // or the runtime fails. Lexical retrieval remains intact in either case.
        vectorFile(documentId).delete()
        File(directory, "$documentId.vec.tmp").delete()
        vectorEmbedder?.let { provider ->
            runCatching { persistVectors(documentId, chunks, provider) }
                .onFailure { vectorFile(documentId).delete(); File(directory, "$documentId.vec.tmp").delete() }
        }
    }

    @Synchronized
    fun removeDocument(documentId: String) {
        if (isSafeId(documentId)) {
            indexFile(documentId).delete()
            vectorFile(documentId).delete()
            File(directory, "$documentId.rag.tmp").delete()
            File(directory, "$documentId.vec.tmp").delete()
        }
    }

    @Synchronized
    fun removeMissing(validDocumentIds: Set<String>) {
        directory.listFiles().orEmpty().forEach { file ->
            when {
                file.name.endsWith(".rag.tmp") || file.name.endsWith(".vec.tmp") -> file.delete()
                file.name.endsWith(".rag") || file.name.endsWith(".vec") -> {
                    val id = file.name.substringBeforeLast('.')
                    if (id !in validDocumentIds) file.delete()
                }
            }
        }
    }

    /**
     * Search is strictly limited to the supplied document IDs (the active chat's attachment list).
     * Lexical rank = 65% normalized BM25 + 35% TF-IDF cosine. An optional on-device reranker may
     * reorder a small candidate pool; if it is absent or throws, the lexical results remain usable.
     */
    @Synchronized
    fun search(
        query: String,
        allowedDocumentIds: Set<String>,
        topK: Int = DEFAULT_TOP_K,
        maxContextChars: Int = MAX_RETRIEVED_CHARS
    ): List<RagChunk> {
        if (query.isBlank() || allowedDocumentIds.isEmpty() || topK <= 0 || maxContextChars <= 0) return emptyList()
        val queryTerms = tokenize(query)
        if (queryTerms.isEmpty()) return emptyList()

        val chunks = allowedDocumentIds.asSequence()
            .filter(::isSafeId)
            .mapNotNull(::readDocumentChunks)
            .flatten()
            .toList()
        if (chunks.isEmpty()) return emptyList()

        val tokenLists = chunks.map { tokenize(it.text) }
        val documentFrequency = HashMap<String, Int>()
        tokenLists.forEach { terms -> terms.toSet().forEach { term -> documentFrequency[term] = (documentFrequency[term] ?: 0) + 1 } }
        val frequencies = tokenLists.map { terms -> terms.groupingBy { it }.eachCount() }
        val averageLength = tokenLists.sumOf { it.size }.toDouble() / tokenLists.size.coerceAtLeast(1)
        val k1 = 1.2
        val b = 0.75

        val rawBm25 = DoubleArray(chunks.size)
        val rawTfIdf = DoubleArray(chunks.size)
        val queryCounts = queryTerms.groupingBy { it }.eachCount()
        val idf = documentFrequency.mapValues { (_, df) -> ln(1.0 + (chunks.size + 1.0) / (df + 1.0)) + 1.0 }
        val queryWeights = queryCounts.mapValues { (term, count) -> (1.0 + ln(count.toDouble())) * (idf[term] ?: 1.0) }
        val queryNorm = sqrt(queryWeights.values.sumOf { it * it }).coerceAtLeast(1e-12)

        chunks.indices.forEach { index ->
            val terms = tokenLists[index]
            val tf = frequencies[index]
            var bm25 = 0.0
            queryCounts.keys.forEach { term ->
                val frequency = tf[term] ?: 0
                if (frequency > 0) {
                    val df = documentFrequency[term] ?: 0
                    val bm25Idf = ln(1.0 + (chunks.size - df + 0.5) / (df + 0.5))
                    val lengthNorm = 1.0 - b + b * terms.size / max(averageLength, 1.0)
                    bm25 += bm25Idf * frequency * (k1 + 1.0) / (frequency + k1 * lengthNorm)
                }
            }
            rawBm25[index] = bm25

            var dot = 0.0
            var docNormSquared = 0.0
            tf.forEach { (term, count) ->
                val weight = (1.0 + ln(count.toDouble())) * (idf[term] ?: 1.0)
                docNormSquared += weight * weight
                dot += weight * (queryWeights[term] ?: 0.0)
            }
            rawTfIdf[index] = if (docNormSquared > 0) dot / (sqrt(docNormSquared) * queryNorm) else 0.0
        }

        val bm25 = normalizeScores(rawBm25)
        val tfidf = normalizeScores(rawTfIdf)
        val lexicalRanked = chunks.indices.mapNotNull { index ->
            if (rawBm25[index] <= 0.0 && rawTfIdf[index] <= 0.0) null
            else ScoredChunk(chunks[index], 0.65 * bm25[index] + 0.35 * tfidf[index])
        }.sortedWith(
            compareByDescending<ScoredChunk> { it.score }
                .thenBy { it.chunk.documentId }
                .thenBy { it.chunk.ordinal }
        )

        if (lexicalRanked.isEmpty()) return emptyList()
        val lexicalPool = lexicalRanked.take(max(topK * EMBEDDING_CANDIDATE_MULTIPLIER, topK))
        val provider = vectorEmbedder
        val vectorRanked = if (provider != null) runCatching {
            rerankWithPersistedVectors(query, lexicalPool, provider)
        }.getOrNull() else null
        val lexicalChunks = lexicalPool.map { it.chunk }
        val legacyReranker = optionalEmbeddingReranker
        val reranked = when {
            vectorRanked != null -> vectorRanked
            legacyReranker != null -> runCatching {
                val validIds = lexicalChunks.map { it.id }.toSet()
                val supplied = legacyReranker.rerank(query, lexicalChunks)
                    .filter { it.id in validIds }.distinctBy { it.id }
                supplied + lexicalChunks.filterNot { candidate -> supplied.any { it.id == candidate.id } }
            }.getOrDefault(lexicalChunks)
            else -> lexicalChunks
        }

        val selected = ArrayList<RagChunk>()
        var usedChars = 0
        for (candidate in reranked) {
            if (selected.size >= topK || usedChars >= maxContextChars) break
            // Don't waste most of the prompt on overlapping adjacent chunks from the same document.
            if (selected.any { it.documentId == candidate.documentId && kotlin.math.abs(it.ordinal - candidate.ordinal) <= 1 }) continue
            val room = maxContextChars - usedChars
            val excerpt = candidate.text.take(room)
            if (excerpt.isBlank()) continue
            selected += candidate.copy(text = excerpt, endOffset = candidate.startOffset + excerpt.length)
            usedChars += excerpt.length
        }
        if (selected.isEmpty() && reranked.isNotEmpty()) {
            val best = reranked.first()
            val excerpt = best.text.take(maxContextChars)
            selected += best.copy(text = excerpt, endOffset = best.startOffset + excerpt.length)
        }
        return selected
    }

    private fun readDocumentChunks(documentId: String): List<RagChunk>? {
        val file = indexFile(documentId)
        if (!file.isFile) return null
        return runCatching {
            val lines = file.readLines(StandardCharsets.UTF_8)
            if (lines.isEmpty()) return@runCatching emptyList()
            val header = lines.first().split('\t')
            if (header.size != 3 || header[0] != HEADER) return@runCatching emptyList()
            val name = decode(header[1])
            lines.drop(1).mapNotNull { line ->
                val parts = line.split('\t', limit = 5)
                if (parts.size == 5) {
                    val ordinal = parts[1].toIntOrNull() ?: return@mapNotNull null
                    val offset = parts[2].toIntOrNull() ?: return@mapNotNull null
                    val end = parts[3].toIntOrNull() ?: return@mapNotNull null
                    val text = decode(parts[4])
                    RagChunk(parts[0], documentId, name, ordinal, offset, text, end)
                } else if (parts.size == 4) {
                    // Backward compatibility with the first P3 index format (without end offsets).
                    val ordinal = parts[1].toIntOrNull() ?: return@mapNotNull null
                    val offset = parts[2].toIntOrNull() ?: return@mapNotNull null
                    val text = decode(parts[3])
                    RagChunk(parts[0], documentId, name, ordinal, offset, text)
                } else null
            }
        }.getOrNull()
    }

    private fun rerankWithPersistedVectors(
        query: String,
        lexicalPool: List<ScoredChunk>,
        provider: LocalVectorEmbedder
    ): List<RagChunk>? {
        if (lexicalPool.isEmpty()) return emptyList()
        val vectorMapByDocument = HashMap<String, Map<String, FloatArray>>()
        lexicalPool.map { it.chunk.documentId }.distinct().forEach { documentId ->
            val vectors = readVectors(documentId, provider.modelId) ?: return null
            vectorMapByDocument[documentId] = vectors
        }
        if (lexicalPool.any { candidate ->
                vectorMapByDocument[candidate.chunk.documentId]?.containsKey(candidate.chunk.id) != true
            }) return null

        val queryVector = provider.embedQuery(query)
        if (queryVector.isEmpty()) return null
        val semantic = lexicalPool.map { candidate ->
            val stored = vectorMapByDocument.getValue(candidate.chunk.documentId).getValue(candidate.chunk.id)
            candidate to cosineSimilarity(queryVector, stored)
        }
        if (semantic.any { !it.second.isFinite() }) return null
        val normalizedSemantic = normalizeScores(DoubleArray(semantic.size) { semantic[it].second })
        return semantic.indices.map { i ->
            val lexical = semantic[i].first
            // Semantic similarity is deliberately slightly more influential than lexical rank.
            // BM25/TF-IDF still gates the candidate pool and remains the complete fallback.
            val score = 0.40 * lexical.score + 0.60 * normalizedSemantic[i]
            ScoredChunk(lexical.chunk, score)
        }.sortedWith(
            compareByDescending<ScoredChunk> { it.score }
                .thenBy { it.chunk.documentId }
                .thenBy { it.chunk.ordinal }
        ).map { it.chunk }
    }

    private fun hasCompleteVectors(documentId: String, chunks: List<RagChunk>, modelId: String): Boolean {
        val persisted = readVectors(documentId, modelId) ?: return false
        return persisted.size == chunks.size && chunks.all { chunk ->
            persisted[chunk.id]?.let { vector -> vector.isNotEmpty() && vector.all { it.isFinite() } } == true
        }
    }

    private fun persistVectors(documentId: String, chunks: List<RagChunk>, provider: LocalVectorEmbedder) {
        val target = vectorFile(documentId)
        val temp = File(directory, "$documentId.vec.tmp")
        val vectors = chunks.map { chunk -> chunk.id to provider.embedDocument(chunk.text) }
        val dimensions = vectors.firstOrNull()?.second?.size ?: 0
        require(dimensions in 1..MAX_VECTOR_DIMENSIONS) { "Embedding boyutu desteklenmiyor: $dimensions" }
        require(vectors.all { it.second.size == dimensions && it.second.all { value -> value.isFinite() } }) {
            "Belge parçalarının embedding boyutları tutarlı değil."
        }
        java.io.DataOutputStream(java.io.BufferedOutputStream(java.io.FileOutputStream(temp))).use { output ->
            output.writeUTF(VECTOR_HEADER)
            output.writeUTF(provider.modelId)
            output.writeInt(vectors.size)
            output.writeInt(dimensions)
            vectors.forEach { (chunkId, vector) ->
                output.writeUTF(chunkId)
                vector.forEach(output::writeFloat)
            }
        }
        try {
            java.nio.file.Files.move(temp.toPath(), target.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                java.nio.file.StandardCopyOption.ATOMIC_MOVE)
        } catch (_: java.nio.file.AtomicMoveNotSupportedException) {
            java.nio.file.Files.move(temp.toPath(), target.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        }
    }

    private fun readVectors(documentId: String, expectedModelId: String): Map<String, FloatArray>? {
        val file = vectorFile(documentId)
        if (!file.isFile) return null
        return try {
            java.io.DataInputStream(java.io.BufferedInputStream(java.io.FileInputStream(file))).use { input ->
                if (input.readUTF() != VECTOR_HEADER || input.readUTF() != expectedModelId) return null
                val count = input.readInt()
                val dimensions = input.readInt()
                if (count !in 1..MAX_VECTOR_COUNT || dimensions !in 1..MAX_VECTOR_DIMENSIONS) return null
                val result = LinkedHashMap<String, FloatArray>(count)
                repeat(count) {
                    val chunkId = input.readUTF()
                    val vector = FloatArray(dimensions) { input.readFloat() }
                    if (vector.any { !it.isFinite() }) return null
                    result[chunkId] = vector
                }
                // Treat truncation, duplicate chunk keys, and unexpected trailing bytes as corrupt;
                // the caller will automatically fall back to the lexical candidate order.
                if (result.size != count || input.read() != -1) return null
                result
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun cosineSimilarity(left: FloatArray, right: FloatArray): Double =
        EmbeddingMath.cosineSimilarity(left, right)

    private fun indexFile(documentId: String): File = File(directory, "$documentId.rag")
    private fun vectorFile(documentId: String): File = File(directory, "$documentId.vec")
    private fun isSafeId(id: String): Boolean = id.matches(Regex("[A-Za-z0-9-]{1,100}"))

    private fun encode(encoder: Base64.Encoder, value: String): String =
        encoder.encodeToString(value.toByteArray(StandardCharsets.UTF_8))

    private fun decode(value: String): String =
        String(Base64.getUrlDecoder().decode(value), StandardCharsets.UTF_8)

    companion object {
        const val CHUNK_SIZE = 900
        const val CHUNK_OVERLAP = 140
        const val DEFAULT_TOP_K = 5
        const val MAX_RETRIEVED_CHARS = 2_400
        const val EMBEDDING_CANDIDATE_MULTIPLIER = 4
        private const val HEADER = "BREIT_RAG_V1"
        private const val VECTOR_HEADER = "BREIT_VECTOR_V1"
        private const val MAX_VECTOR_DIMENSIONS = 4_096
        private const val MAX_VECTOR_COUNT = 50_000

        internal fun fingerprint(value: String): String = sha256(value)

        internal fun chunkDocument(documentId: String, name: String, text: String): List<RagChunk> {
            if (text.isBlank()) return emptyList()
            val chunks = mutableListOf<RagChunk>()
            var start = 0
            var ordinal = 0
            while (start < text.length) {
                var end = minOf(start + CHUNK_SIZE, text.length)
                if (end < text.length) {
                    val floor = start + CHUNK_SIZE / 2
                    val paragraph = text.lastIndexOf("\n\n", startIndex = end)
                    val line = text.lastIndexOf('\n', startIndex = end)
                    val sentence = text.lastIndexOf(". ", startIndex = end)
                    val boundary = listOf(
                        paragraph.takeIf { it >= floor }?.plus(2),
                        line.takeIf { it >= floor }?.plus(1),
                        sentence.takeIf { it >= floor }?.plus(1)
                    ).filterNotNull().maxOrNull()
                    if (boundary != null) end = boundary.coerceAtMost(text.length)
                }
                val raw = text.substring(start, end)
                val chunkText = raw.trim()
                if (chunkText.isNotEmpty()) {
                    val leadingTrim = raw.indexOf(chunkText).coerceAtLeast(0)
                    val exactStart = start + leadingTrim
                    val exactEnd = exactStart + chunkText.length
                    val stableId = "${documentId}_${exactStart}_${sha256(chunkText).take(16)}"
                    chunks += RagChunk(stableId, documentId, name, ordinal, exactStart, chunkText, exactEnd)
                    ordinal++
                }
                if (end >= text.length) break
                val next = end - CHUNK_OVERLAP
                start = if (next > start) next else minOf(start + CHUNK_SIZE, text.length)
            }
            return chunks
        }

        internal fun tokenize(text: String): List<String> =
            Regex("[\\p{L}\\p{N}_]{2,}").findAll(text.lowercase(Locale.ROOT)).map { it.value }.toList()

        private fun normalizeScores(scores: DoubleArray): DoubleArray {
            if (scores.isEmpty()) return scores
            val min = scores.minOrNull() ?: 0.0
            val max = scores.maxOrNull() ?: 0.0
            if (max <= min) return DoubleArray(scores.size) { if (scores[it] > 0.0) 1.0 else 0.0 }
            return DoubleArray(scores.size) { ((scores[it] - min) / (max - min)).coerceIn(0.0, 1.0) }
        }

        private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(StandardCharsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    private data class ScoredChunk(val chunk: RagChunk, val score: Double)
}
