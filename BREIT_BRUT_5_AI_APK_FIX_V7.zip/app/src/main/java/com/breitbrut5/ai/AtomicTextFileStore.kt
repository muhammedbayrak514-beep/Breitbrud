package com.breitbrut5.ai

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.charset.StandardCharsets

/** Small crash-safe UTF-8 text store using temp-write + same-directory rename + rollback backup. */
internal class AtomicTextFileStore(private val baseFile: File) {
    private val lock = Any()
    private val backupFile get() = File(baseFile.parentFile, baseFile.name + ".bak")
    private val tempFile get() = File(baseFile.parentFile, baseFile.name + ".tmp")

    fun readTextOrNull(): String? = synchronized(lock) {
        if (!baseFile.exists() && backupFile.isFile) {
            baseFile.parentFile?.mkdirs()
            if (!backupFile.renameTo(baseFile)) {
                backupFile.copyTo(baseFile, overwrite = true)
                backupFile.delete()
            }
        }
        if (!baseFile.isFile) null else baseFile.readText(StandardCharsets.UTF_8)
    }

    fun writeText(value: String) {
        synchronized(lock) {
            val parent = baseFile.parentFile ?: throw IOException("Depolama klasörü bulunamadı.")
            if (!parent.exists() && !parent.mkdirs()) {
                throw IOException("Depolama klasörü oluşturulamadı: ${parent.absolutePath}")
            }
            tempFile.delete()
            val bytes = value.toByteArray(StandardCharsets.UTF_8)
            FileOutputStream(tempFile).use { output ->
                output.write(bytes)
                output.fd.sync()
            }

            if (backupFile.exists() && !backupFile.delete()) {
                tempFile.delete()
                throw IOException("Eski kurtarma dosyası temizlenemedi.")
            }
            if (baseFile.exists()) {
                if (!baseFile.renameTo(backupFile)) {
                    try {
                        baseFile.copyTo(backupFile, overwrite = true)
                    } catch (e: Exception) {
                        tempFile.delete()
                        throw IOException("Mevcut sohbet kaydı için yedek oluşturulamadı.", e)
                    }
                    if (!baseFile.delete()) {
                        backupFile.delete()
                        tempFile.delete()
                        throw IOException("Eski sohbet kaydı güvenli biçimde değiştirilemedi.")
                    }
                }
            }
            if (!tempFile.renameTo(baseFile)) {
                if (backupFile.exists() && !baseFile.exists()) backupFile.renameTo(baseFile)
                tempFile.delete()
                throw IOException("Yeni sohbet kaydı etkinleştirilemedi; önceki kayıt geri yüklenmeye çalışıldı.")
            }
            // The new file is durable; backup is only needed for a failed replacement transaction.
            backupFile.delete()
        }
    }

    /** Keeps a recovery copy when a file exists but its contents cannot be parsed. */
    fun preserveCorruptCopy(maxCopies: Int = 3): File? = synchronized(lock) {
        if (!baseFile.isFile) return@synchronized null
        val parent = baseFile.parentFile ?: return@synchronized null
        val recovery = File(parent, "${baseFile.nameWithoutExtension}.corrupt-${System.currentTimeMillis()}.json")
        baseFile.copyTo(recovery, overwrite = false)
        parent.listFiles().orEmpty()
            .filter { it.isFile && it.name.startsWith(baseFile.nameWithoutExtension + ".corrupt-") }
            .sortedByDescending { it.lastModified() }
            .drop(maxCopies.coerceAtLeast(1))
            .forEach { it.delete() }
        recovery
    }
}
