package com.breitbrut5.ai

import org.xml.sax.Attributes
import org.xml.sax.InputSource
import org.xml.sax.helpers.DefaultHandler
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.StringReader
import java.net.URI
import java.util.zip.ZipInputStream
import javax.xml.XMLConstants
import javax.xml.parsers.SAXParserFactory

/** Results extracted from Office Open XML packages without unpacking paths to disk. */
internal data class OoxmlExtraction(
    val text: String,
    val method: String,
    val sectionCount: Int
)

/**
 * Minimal, bounded OOXML reader for DOCX/PPTX/XLSX text. It is intentionally not a layout renderer:
 * images, SmartArt, embedded objects, macros, comments and tracked-change semantics are not decoded.
 * ZIP paths are never written to disk; decompressed sizes, selected XML entries and entry counts are capped.
 */
internal object OoxmlTextExtractor {
    const val MAX_ARCHIVE_ENTRIES = 3_000
    const val MAX_TOTAL_EXPANDED_BYTES = 60L * 1_048_576L
    const val MAX_SINGLE_XML_BYTES = 10 * 1_048_576
    const val MAX_TOTAL_SELECTED_XML_BYTES = 30L * 1_048_576L
    const val MAX_OUTPUT_CHARS = DocumentIngestionPolicy.MAX_EXTRACTED_CHARS
    private const val MAX_SHEETS_OR_SLIDES = 200

    fun extractDocx(archive: ByteArray): OoxmlExtraction = extractDocx(ByteArrayInputStream(archive))

    fun extractDocx(archive: InputStream): OoxmlExtraction {
        val entry = readRelevantEntries(archive) { it == "word/document.xml" }["word/document.xml"]
            ?: error("DOCX dosyasında Word ana metni bulunamadı.")
        val text = extractTextRuns(entry, paragraphTag = "p", tabTag = "tab")
            .take(MAX_OUTPUT_CHARS)
            .trim()
        if (text.isBlank()) error("DOCX dosyasında okunabilir metin bulunamadı.")
        return OoxmlExtraction(text, "docx_xml", 0)
    }

    fun extractPptx(archive: ByteArray): OoxmlExtraction = extractPptx(ByteArrayInputStream(archive))

    fun extractPptx(archive: InputStream): OoxmlExtraction {
        val entries = readRelevantEntries(archive) { name ->
            name == "ppt/presentation.xml" || name == "ppt/_rels/presentation.xml.rels" ||
                name.matches(Regex("ppt/slides/slide[0-9]+\\.xml"))
        }
        val slidePaths = entries.keys.filter { it.matches(Regex("ppt/slides/slide[0-9]+\\.xml")) }.toSet()
        val orderedPaths = resolveSlideOrder(entries, slidePaths)
        // Presentation order, not ZIP entry/file numbering, determines the visible slide number.
        val slides = orderedPaths.mapIndexedNotNull { orderIndex, name ->
            val bytes = entries[name]
            if (bytes == null) null else Triple(orderIndex + 1, name, bytes)
        }
        if (slides.isEmpty()) error("PPTX içinde okunabilir slayt bulunamadı.")
        if (slides.size > MAX_SHEETS_OR_SLIDES) error("PPTX en fazla $MAX_SHEETS_OR_SLIDES slayt için destekleniyor.")
        val output = StringBuilder()
        var written = 0
        slides.forEach { (number, _, xml) ->
            val slideText = extractTextRuns(xml, paragraphTag = "p", tabTag = "tab").trim()
            if (slideText.isNotBlank()) {
                appendBounded(output, "\n\n[Slayt $number]\n$slideText\n")
                written++
            } else {
                appendBounded(output, "\n\n[Slayt $number]\n[Slayttan metin çıkarılamadı]\n")
            }
        }
        val clean = output.toString().trim()
        if (clean.isBlank()) error("PPTX içinde okunabilir metin bulunamadı.")
        return OoxmlExtraction(clean, "pptx_ooxml_text", slides.size)
    }

    fun extractXlsx(archive: ByteArray): OoxmlExtraction = extractXlsx(ByteArrayInputStream(archive))

    fun extractXlsx(archive: InputStream): OoxmlExtraction {
        val entries = readRelevantEntries(archive) { name ->
            name == "xl/sharedStrings.xml" || name == "xl/workbook.xml" ||
                name == "xl/_rels/workbook.xml.rels" ||
                name.matches(Regex("xl/worksheets/sheet[0-9]+\\.xml"))
        }
        val worksheets = entries.filterKeys { it.matches(Regex("xl/worksheets/sheet[0-9]+\\.xml")) }
        if (worksheets.isEmpty()) error("XLSX içinde çalışma sayfası bulunamadı.")
        if (worksheets.size > MAX_SHEETS_OR_SLIDES) error("XLSX en fazla $MAX_SHEETS_OR_SLIDES çalışma sayfası için destekleniyor.")
        val sharedStrings = entries["xl/sharedStrings.xml"]?.let(::parseSharedStrings).orEmpty()
        val orderedSheets = resolveWorksheetOrder(entries, worksheets.keys)
        val output = StringBuilder()
        orderedSheets.forEachIndexed { index, (name, path) ->
            val xml = worksheets[path] ?: return@forEachIndexed
            val sheetText = parseWorksheet(xml, sharedStrings)
            appendBounded(output, "\n\n[Çalışma sayfası: ${safeLabel(name, "Sayfa ${index + 1}")}]\n")
            if (sheetText.isBlank()) appendBounded(output, "[Bu çalışma sayfasında okunabilir hücre metni bulunamadı]\n")
            else appendBounded(output, sheetText)
        }
        val clean = output.toString().trim()
        if (clean.isBlank()) error("XLSX içinde okunabilir hücre bulunamadı.")
        return OoxmlExtraction(clean, "xlsx_ooxml_cells", orderedSheets.size)
    }

    private fun readRelevantEntries(archive: InputStream, keep: (String) -> Boolean): Map<String, ByteArray> {
        val result = linkedMapOf<String, ByteArray>()
        var selectedExpanded = 0L
        var totalExpanded = 0L
        var entryCount = 0
        ZipInputStream(archive).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                entryCount++
                if (entryCount > MAX_ARCHIVE_ENTRIES) error("Office arşivinde izin verilen dosya sayısı aşıldı.")
                val name = entry.name.replace('\\', '/')
                if (name.startsWith('/') || name.split('/').any { it == ".." }) error("Office arşivinde güvenli olmayan yol bulundu.")
                val selected = keep(name)
                val out = if (selected) ByteArrayOutputStream() else null
                val buffer = ByteArray(8 * 1024)
                var selectedBytes = 0
                while (true) {
                    val count = zip.read(buffer)
                    if (count < 0) break
                    totalExpanded += count.toLong()
                    if (totalExpanded > MAX_TOTAL_EXPANDED_BYTES) error("Office arşivinin açılmış toplam boyutu güvenlik sınırını aşıyor.")
                    if (selected) {
                        selectedBytes += count
                        selectedExpanded += count.toLong()
                        if (selectedBytes > MAX_SINGLE_XML_BYTES) error("Office içindeki bir metin/XML bölümü çok büyük.")
                        if (selectedExpanded > MAX_TOTAL_SELECTED_XML_BYTES) error("Office içindeki metin bölümlerinin toplamı güvenlik sınırını aşıyor.")
                        out!!.write(buffer, 0, count)
                    }
                }
                if (selected) {
                    if (result.containsKey(name)) error("Office arşivinde yinelenen XML girdisi bulundu: $name")
                    result[name] = out!!.toByteArray()
                }
                zip.closeEntry()
            }
        }
        return result
    }


    /** Resolve the presentation's declared slide order; fall back to slide file numbers for minimal archives. */
    private fun resolveSlideOrder(entries: Map<String, ByteArray>, slidePaths: Set<String>): List<String> {
        val presentation = entries["ppt/presentation.xml"]
        val relationships = entries["ppt/_rels/presentation.xml.rels"]
        if (presentation == null || relationships == null) return numericSlideFallback(slidePaths)
        val targets = linkedMapOf<String, String>()
        secureXml(relationships, object : DefaultHandler() {
            override fun startElement(uri: String?, localName: String?, qName: String?, attributes: Attributes) {
                if (local(localName, qName) == "Relationship") {
                    val id = attr(attributes, "Id")
                    val target = attr(attributes, "Target")
                    val resolved = normalizeSlideTarget(target)
                    if (id.isNotBlank() && resolved in slidePaths) targets[id] = resolved
                }
            }
        })
        val ordered = mutableListOf<String>()
        secureXml(presentation, object : DefaultHandler() {
            override fun startElement(uri: String?, localName: String?, qName: String?, attributes: Attributes) {
                if (local(localName, qName) == "sldId") {
                    val relationshipId = attrByNamespace(
                        attributes,
                        "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
                        "id"
                    )
                    targets[relationshipId]?.let(ordered::add)
                }
            }
        })
        return ordered.distinct().takeIf { it.isNotEmpty() } ?: numericSlideFallback(slidePaths)
    }

    private fun normalizeSlideTarget(target: String): String {
        val clean = target.replace('\\', '/')
        val resolved = runCatching {
            URI("ppt/presentation.xml").resolve(clean).normalize().path.removePrefix("/")
        }.getOrDefault("")
        return resolved.takeIf {
            it.startsWith("ppt/slides/") && it.matches(Regex("ppt/slides/slide[0-9]+\\.xml"))
        }.orEmpty()
    }

    private fun numericSlideFallback(slidePaths: Set<String>): List<String> = slidePaths.sortedBy {
        it.substringAfterLast("slide").substringBefore('.').toIntOrNull() ?: Int.MAX_VALUE
    }

    private fun resolveWorksheetOrder(entries: Map<String, ByteArray>, sheetPaths: Set<String>): List<Pair<String, String>> {
        val workbook = entries["xl/workbook.xml"]
        val relationships = entries["xl/_rels/workbook.xml.rels"]
        if (workbook == null || relationships == null) {
            return sheetPaths.sortedBy { it.substringAfterLast("sheet").substringBefore('.').toIntOrNull() ?: Int.MAX_VALUE }
                .mapIndexed { index, path -> "Sayfa ${index + 1}" to path }
        }
        val rels = linkedMapOf<String, String>()
        secureXml(relationships, object : DefaultHandler() {
            override fun startElement(uri: String?, localName: String?, qName: String?, attributes: Attributes) {
                if (local(localName, qName) == "Relationship") {
                    val id = attr(attributes, "Id")
                    val target = attr(attributes, "Target")
                    if (id.isNotBlank() && target.isNotBlank()) rels[id] = normalizeWorksheetTarget(target)
                }
            }
        })
        val declared = mutableListOf<Pair<String, String>>()
        secureXml(workbook, object : DefaultHandler() {
            override fun startElement(uri: String?, localName: String?, qName: String?, attributes: Attributes) {
                if (local(localName, qName) == "sheet") {
                    val title = attr(attributes, "name").ifBlank { "Sayfa ${declared.size + 1}" }
                    val relId = attr(attributes, "id")
                    val path = rels[relId]
                    if (path != null && path in sheetPaths) declared += title to path
                }
            }
        })
        if (declared.isNotEmpty()) return declared.distinctBy { it.second }
        return sheetPaths.sortedBy { it.substringAfterLast("sheet").substringBefore('.').toIntOrNull() ?: Int.MAX_VALUE }
            .mapIndexed { index, path -> "Sayfa ${index + 1}" to path }
    }

    private fun normalizeWorksheetTarget(target: String): String {
        val clean = target.replace('\\', '/').removePrefix("/")
        if (clean.startsWith("xl/")) return clean
        val resolved = runCatching { URI("xl/workbook.xml").resolve(clean).normalize().path.removePrefix("/") }.getOrDefault("")
        return when {
            resolved.startsWith("xl/worksheets/") -> resolved
            clean.startsWith("worksheets/") -> "xl/$clean"
            clean.startsWith("../worksheets/") -> "xl/${clean.removePrefix("../")}"
            else -> clean
        }
    }

    private fun parseSharedStrings(xml: ByteArray): List<String> {
        val values = mutableListOf<String>()
        var item: StringBuilder? = null
        var inText = false
        secureXml(xml, object : DefaultHandler() {
            override fun startElement(uri: String?, localName: String?, qName: String?, attributes: Attributes) {
                when (local(localName, qName)) {
                    "si" -> item = StringBuilder()
                    "t" -> if (item != null) inText = true
                }
            }
            override fun characters(ch: CharArray, start: Int, length: Int) {
                if (inText) item?.append(ch, start, length)
            }
            override fun endElement(uri: String?, localName: String?, qName: String?) {
                when (local(localName, qName)) {
                    "t" -> inText = false
                    "si" -> {
                        values += item?.toString().orEmpty()
                        item = null
                        if (values.size > 250_000) error("XLSX paylaşılan metin tablosu çok büyük.")
                    }
                }
            }
        })
        return values
    }

    private fun parseWorksheet(xml: ByteArray, sharedStrings: List<String>): String {
        val output = StringBuilder()
        var rowNumber: String? = null
        var currentCellRef: String? = null
        var currentCellType: String = ""
        var currentCellValue: StringBuilder? = null
        var inValue = false
        var rowCells: MutableList<String>? = null
        secureXml(xml, object : DefaultHandler() {
            override fun startElement(uri: String?, localName: String?, qName: String?, attributes: Attributes) {
                when (local(localName, qName)) {
                    "row" -> {
                        rowNumber = attr(attributes, "r").ifBlank { "?" }
                        rowCells = mutableListOf()
                    }
                    "c" -> {
                        currentCellRef = attr(attributes, "r")
                        currentCellType = attr(attributes, "t")
                        currentCellValue = StringBuilder()
                    }
                    "v", "t" -> if (currentCellValue != null) inValue = true
                }
            }
            override fun characters(ch: CharArray, start: Int, length: Int) {
                if (inValue) currentCellValue?.append(ch, start, length)
            }
            override fun endElement(uri: String?, localName: String?, qName: String?) {
                when (local(localName, qName)) {
                    "v", "t" -> inValue = false
                    "c" -> {
                        val raw = currentCellValue?.toString().orEmpty()
                        val value = when (currentCellType) {
                            "s" -> raw.toIntOrNull()?.let { sharedStrings.getOrNull(it) }.orEmpty()
                            "b" -> if (raw == "1") "TRUE" else if (raw == "0") "FALSE" else raw
                            else -> raw
                        }
                        if (value.isNotBlank()) rowCells?.add("${currentCellRef.orEmpty()}=${value.replace('\n', ' ')}")
                        currentCellRef = null
                        currentCellType = ""
                        currentCellValue = null
                    }
                    "row" -> {
                        val cells = rowCells.orEmpty()
                        if (cells.isNotEmpty()) appendBounded(output, "Satır ${rowNumber ?: "?"}: ${cells.joinToString(" | ")}\n")
                        rowNumber = null
                        rowCells = null
                    }
                }
            }
        })
        return output.toString()
    }

    private fun extractTextRuns(xml: ByteArray, paragraphTag: String, tabTag: String): String {
        val output = StringBuilder()
        var inText = false
        secureXml(xml, object : DefaultHandler() {
            override fun startElement(uri: String?, localName: String?, qName: String?, attributes: Attributes) {
                when (local(localName, qName)) {
                    "t" -> inText = true
                    tabTag -> output.append('\t')
                    "br", "cr" -> output.append('\n')
                }
            }
            override fun characters(ch: CharArray, start: Int, length: Int) {
                if (inText) appendBounded(output, String(ch, start, length))
            }
            override fun endElement(uri: String?, localName: String?, qName: String?) {
                when (local(localName, qName)) {
                    "t" -> inText = false
                    paragraphTag -> appendBounded(output, "\n")
                }
            }
        })
        return output.toString()
    }

    private fun secureXml(bytes: ByteArray, handler: DefaultHandler) {
        require(bytes.size <= MAX_SINGLE_XML_BYTES) { "Office XML bölümü desteklenen sınırı aşıyor." }
        val factory = SAXParserFactory.newInstance().apply {
            isNamespaceAware = true
            runCatching { setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true) }
            runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
            runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }
            runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
        }
        val reader = factory.newSAXParser().xmlReader
        reader.entityResolver = org.xml.sax.EntityResolver { _, _ -> InputSource(StringReader("")) }
        reader.contentHandler = handler
        reader.parse(InputSource(ByteArrayInputStream(bytes)))
    }

    private fun local(localName: String?, qName: String?): String =
        (localName?.takeIf { it.isNotBlank() } ?: qName.orEmpty().substringAfter(':')).substringAfter(':')

    private fun attrByNamespace(attributes: Attributes, namespace: String, target: String): String {
        for (index in 0 until attributes.length) {
            if (attributes.getLocalName(index) == target && attributes.getURI(index) == namespace) {
                return attributes.getValue(index).orEmpty()
            }
        }
        return ""
    }

    private fun attr(attributes: Attributes, target: String): String {
        for (index in 0 until attributes.length) {
            val name = attributes.getLocalName(index).ifBlank { attributes.getQName(index).substringAfter(':') }
            if (name == target) return attributes.getValue(index).orEmpty()
        }
        return ""
    }

    private fun safeLabel(label: String, fallback: String): String = label
        .replace('\n', ' ').replace('\r', ' ').replace(Regex("[\\p{Cntrl}]"), " ")
        .trim().take(100).ifBlank { fallback }

    private fun appendBounded(output: StringBuilder, value: String) {
        val remaining = MAX_OUTPUT_CHARS - output.length
        if (remaining <= 0) error("Office belgesinden çıkarılan metin ${MAX_OUTPUT_CHARS} karakter sınırını aşıyor.")
        if (value.length > remaining) error("Office belgesinden çıkarılan metin ${MAX_OUTPUT_CHARS} karakter sınırını aşıyor.")
        output.append(value)
    }
}
