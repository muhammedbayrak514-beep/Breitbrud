# BREİT BRUT 5 AI — v0.15.0 (P4.3 + P4.4)

BREİT BRUT 5 AI is an Android app that runs a compatible LiteRT-LM model locally on the device. The app does not require a hosted AI API key for local inference. Model downloads are explicitly initiated by the user; local document extraction and local RAG indexing stay on-device.

## What's included in this release

### P4.3 — Device-aware model management and diagnostics
- Model suitability scoring based on total RAM, currently available system RAM and free internal storage. The recommendation is advisory and does not guarantee a model will initialize or run quickly.
- Consistent model-storage policy shared between recommendations and downloads: minimum available storage threshold plus model-size-aware headroom.
- User-selected `.litertlm` model import guarded by a 4 GiB size ceiling, provider-reported-size checks, copy-progress bounds, incomplete-copy checks and temporary-file cleanup.
- SHA-256 artifact fingerprint metadata for detecting later changes to model files. The locally computed digest is not a publisher signature.
- Local performance records for model initialization and inference: first non-empty output chunk latency, total duration, median/P90, output characters per second, success/failure/cancel counts and available-system-RAM snapshots.
- Telemetry records bounded to the latest 120 events and exclude prompts, answers, document contents and raw exceptions. History can be cleared from the model manager.
- Suggested output-token cap per model/device profile, applied only when the user presses the UI action.

### P4.4 — Local multi-document extraction
- Android Storage Access Framework multi-select: up to 10 picked files per batch; the existing maximum of 5 attached documents per chat still applies.
- Supported input: TXT, Markdown, CSV, JSON, XML, HTML, CSS/JS/Kotlin/Java/Python/SQL/log/config text; PDF; DOCX; PPTX; XLSX; PNG/JPEG/WebP/BMP images.
- PDF text extraction with page markers. Pages with no extracted text are rendered with Android `PdfRenderer` and passed to bundled on-device Latin-script ML Kit OCR, limited to 30 blank-text pages per PDF.
- Standalone supported images are OCR'd locally with the bundled Latin-script ML Kit model.
- DOCX paragraphs/tabs, PPTX text in presentation order, and XLSX cell values with worksheet names, rows and cell coordinates are extracted from Office Open XML archives without unpacking archive paths to disk.
- Decompression, XML-entry, output text, file size, page count, image pixel and OCR limits are enforced. File/section metadata and extraction warnings persist with each local document.
- Extracted text flows into the existing per-chat BM25 + TF-IDF index and optional local embedding reranker.

## Important limitations

- The V4 diagnostics first showed missing Compose `getValue`/`setValue` delegate imports; V5 added those imports. V5 compilation then exposed JVM setter-signature clashes because `ChatViewModel` had explicit methods named `setBackendPreference(...)` and `setMaxOutputTokens(...)`, which collided with generated property setters. V6 renames these explicit operations to `updateBackendPreference(...)` and `updateMaxOutputTokens(...)` and updates UI call sites. V7 replaces all 18 deprecated `createTempDir(...)` calls in four unit-test files with `createTempDirectory(...).toFile()`, retaining the existing cleanup blocks. A full Android Gradle build must still pass in GitHub Actions before the APK can be considered verified.
- On-device OCR quality depends on resolution, text orientation, language, contrast and handwriting. Only pages with no PDF text layer are automatically OCR'd; mixed pages that already contain some PDF text are not additionally OCR'd in this release.
- PPTX parsing extracts text only; it does not reconstruct layout, diagrams, speaker notes or text embedded in images. XLSX extraction reads stored cell values; it does not recalculate formulas or reproduce styles, charts and pivots. DOCX layout, headers/footers, comments, tracked changes and image text are not fully reconstructed.
- Embedding search and source-evidence checks remain advisory systems. Lexical overlap is not proof that a claim is true.
- The local SHA-256 sidecar detects subsequent file changes; it cannot authenticate the first downloaded/imported file without a separately trusted expected digest or signature.
- System-available RAM snapshots are not process RSS or peak model memory; the throughput metric is characters/second, not tokens/second.

## Build and test

Requirements: JDK 17, Android SDK (compile SDK 36) and internet access for first-time Gradle distribution/dependency downloads.

```bash
./gradlew testDebugUnitTest --no-daemon
./gradlew assembleDebug --no-daemon
```

The GitHub Actions workflow at `.github/workflows/android-ci.yml` runs both commands and uploads `app-debug.apk` and unit-test reports as workflow artifacts. Open the repository's **Actions** tab, select the workflow run and download the APK under **Artifacts** after a successful run.

## Install

Transfer the generated debug APK to the Android tablet and install it. Open the app, import a compatible `.litertlm` model, then send a short test question. APK installation alone does not confirm that the local model initializes successfully.

## Build an APK with GitHub Actions

The workflow is `.github/workflows/android-ci.yml`. Upload the project files to a GitHub repository, then open **Actions** and run **BREIT BRUT 5 AI - Android APK V7**, or push to `main`, `master`, or `develop`. The V7 workflow requires `BREIT_BRUT_5_AI_APK_FIX_V7.zip` in the repository root. When the run finishes, download the `BREIT_BRUT_5_AI-debug.apk` artifact from the run summary. This is a debug APK, not a Play Store release build.
