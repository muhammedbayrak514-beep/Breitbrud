# P4.3 foundation — device-aware model recommendations and runtime telemetry

## Implemented starting point

- `DeviceModelAdvisor` ranks the existing model catalog using total RAM, currently available RAM and free internal storage.
- Each model receives one of three advisory fit states: `RECOMMENDED`, `CAUTION`, or `NOT_RECOMMENDED`, alongside human-readable reasons and an estimated free-storage requirement that includes a headroom allowance.
- The model manager displays the first candidate that is not classified as `NOT_RECOMMENDED`; if none qualifies, the UI does not misleadingly claim a recommended model exists.
- `LocalPerformanceTelemetry` records successful completed turns only. It stores model filename, runtime/backend label, elapsed milliseconds, output character count and completion timestamp. It never stores prompt text, answer text or local document contents.
- Telemetry is capped to the latest 40 samples, URL-safe Base64 encodes string fields and uses the app's atomic text-file store.
- `PerformanceMath` reports sample count, median end-to-end turn duration and aggregate output characters per second. The UI explicitly says characters/sec is not tokens/sec.
- Model Manager shows an overall summary plus recent per-model/per-backend groups so different models are not evaluated only through one blended number.
- Measurement is integrated into the normal response lifecycle and shown in Model Manager.

## Known limits / next P4.3 work

- Recommendations are heuristics, not guarantees; they do not know the model's full KV-cache/runtime memory footprint, thermals, device-specific kernel support or OS pressure changes.
- Elapsed time includes question handling/retrieval through answer completion, and does not yet isolate model cold-start, prefill, token generation and embedding latency.
- No sampled peak memory, thermal throttling, battery consumption or backend error-rate metrics yet.
- Telemetry has no UI clear/export control yet; metrics are private local metadata only.
- Next: cold vs warm load timings, cancellation/error samples, opt-in export/clear, runtime RAM samples and a tablet matrix test.
