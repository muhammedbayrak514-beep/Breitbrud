# P2 test plan

## Unit tests

Run `./gradlew testDebugUnitTest` after Gradle can resolve the configured distribution and dependencies.

- Coding mode includes coding-specific quality instructions.
- Attached local files are clearly framed as reference data, not higher-priority instructions.
- Combined document prompt text never exceeds the configured hard cap.

## Android manual tests

1. Install a debug APK and load a known-compatible small `.litertlm` model.
2. Create one chat per mode, change modes, restart the app, and confirm each thread's mode is retained.
3. Import each supported text extension; verify its chip appears in the active chat and survives app restart.
4. Attempt a PDF, image, binary file, empty text file, and a file larger than 1.5 MB; each should be rejected with a readable message and leave no partial document behind.
5. Ask a question answered in a text document and confirm the model can use the provided excerpt; ask about absent information and confirm the prompt tells the model to state that it is absent.
6. Attach two documents where the first is larger than 2,000 characters; verify prompt context stays within the 1,800-character aggregate cap and only a bounded recent history is restored.
7. Remove one document and confirm subsequent answers no longer have that document in the model's initial context.
8. Copy one assistant answer and share a chat; verify the generated text has the expected role labels and does not include document contents.
9. Delete a chat with attachments and confirm associated app-owned files are cleaned up.
10. Regression-test P1.1 model download, CPU/GPU selection, retry, cancellation, and conversation history.
11. Test rotation, backgrounding, low-storage conditions, and at least one low-RAM device.

## Release criteria

Do not mark P2 as build-verified until `assembleDebug` and `testDebugUnitTest` finish successfully. Do not mark it device-verified until the manual list has been exercised on a real Android device.
