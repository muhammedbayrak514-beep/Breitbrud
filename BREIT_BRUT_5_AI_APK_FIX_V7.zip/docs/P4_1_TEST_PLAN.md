# P4.1 test and acceptance plan

## Regression tests added

- [x] Stable chunk IDs and exact source offsets remain valid.
- [x] Search remains scoped to the active chat's document IDs.
- [x] BM25/TF-IDF retrieval is usable without an embedding model.
- [x] Fake embedder creates persistent vector sidecars and can rerank candidates.
- [x] Valid vector sidecars are reused across index instances instead of re-embedding at every startup.
- [x] Changing the embedding model ID invalidates and rebuilds the vector sidecar.
- [x] Corrupt/missing vector data falls back to lexical ranking.
- [x] Replacing/removing documents does not leave related vector files behind.
- [x] Cosine math rejects empty, mismatched, zero-norm, and non-finite vectors.
- [x] Source label audit recognizes valid labels, flags unknown labels, marks unused sources, and reports no-match cases.
- [x] Source audit is skipped when there are no attached documents.

## Required on CI

- [ ] `./gradlew testDebugUnitTest --no-daemon`
- [ ] `./gradlew assembleDebug --no-daemon`
- [ ] Verify real `EmbeddingEngineConfig`, `EmbeddingEngine.computeEmbedding`, and return vector type with LiteRT-LM 0.18.1 AAR.

## Required on a physical tablet

- [ ] Download the model and confirm SHA-256 installation gate succeeds.
- [ ] Enable semantic retrieval and ask paraphrase questions in Turkish and English.
- [ ] Compare BM25/TF-IDF-only results against embedding reranking using the same questions and documents.
- [ ] Confirm no crash on low-memory model load failure and that lexical search still answers.
- [ ] Restart the app and verify vector cache reuse, model status, chat history, and citation audit.
- [ ] Measure warm-up duration, query latency, RAM pressure and battery impact.

## Reporting rules

Standalone Kotlin harness results are not Android/Gradle tests. Do not call the feature device-tested until the checklist above has been completed on a real Android tablet.
