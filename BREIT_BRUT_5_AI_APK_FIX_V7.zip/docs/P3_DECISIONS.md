# P3 technical decisions

- **Chunk boundaries:** Split at paragraph, line, or sentence boundaries when close to the target size, preserving overlap for continuity. Store character offsets against the original text and stable chunk IDs based on document ID, offset, and chunk-text hash.
- **Duplicate imports:** Store a SHA-256 fingerprint in local document metadata. Check it before creating a new file/index for the active chat. If an older P2 record has no fingerprint, compute it from the existing local file.
- **Hybrid lexical retrieval:** Always compute BM25 and TF-IDF cosine locally; combine normalized scores at 65/35. Both work without an embedding model.
- **Optional embedding hook:** `LocalEmbeddingReranker` accepts a candidate pool and returns it in semantic order. It is optional and fault-tolerant. A concrete offline embedding model/runtime is not included/configured yet, and the default is disabled. No embedding capability is claimed for the shipped baseline.
- **Per-document index files:** Index files are in app-private storage and are atomically replaced per document, avoiding a database dependency. The old P3 format without stored end offsets remains readable.
- **Active-chat isolation:** Search only receives the document IDs attached to the current thread. Tests exercise this boundary directly.
- **Source metadata:** `[S1]`, `[S2]` are assigned in retrieval order for each user question. Each answer stores its source file, chunk/section, character offsets, and excerpt so the user can inspect the context after reopening chat history.
- **Prompt safety:** Document contents are framed as untrusted evidence, not instructions. The assistant is told not to cite sources that were not supplied and to state clearly when retrieval found no matching passage.
- **Context budget:** Retrieve at most five chunks and 2,400 excerpt characters. Chat history is separately bounded when documents are attached. Since no verified model-tokenizer adapter is currently exposed in this flow, the budget is explicitly a character limit, not exact token count.
