# P4.1 — implementation status

P4.1 source implementation has been added to this project. See `P4_1_IMPLEMENTATION.md` and `P4_1_TEST_PLAN.md`.

## Active source components

- Real LiteRT-LM `EmbeddingEngine` adapter for EmbeddingGemma 2 Text 270M.
- Download, cancellation, SHA-256 verification, load/disable/remove controls, separate private model folder, and optional semantic mode.
- Persistent per-document vector sidecars with model version and stable chunk IDs.
- BM25 + TF-IDF candidate retrieval followed by cosine-similarity reranking; any failure returns to lexical order.
- P4.2 source-label validator and persisted citation audit groundwork.

## Current verification status

- 17 pure Kotlin retrieval/citation regression tests passed in a standalone harness.
- Embedding adapter source syntax passed a Kotlin compile against API-shaped stubs only.
- Full Gradle/JUnit build and Android/Compose compilation remain unverified because Gradle distribution download currently fails DNS resolution for `services.gradle.org`.
- Real EmbeddingGemma model loading and tablet performance remain untested.

## Required next actions

1. Run the repository's GitHub Actions workflow to validate the real LiteRT-LM dependency/API and produce a debug APK.
2. Install APK on the tablet and run `docs/P4_1_TEST_PLAN.md` device checks.
3. Continue P4.2 with claim-to-source support checks after the label-integrity layer is verified.

The model artifact is not bundled with the source ZIP; it is optionally downloaded in-app. Official references: https://developers.google.com/edge/litert-lm/embedding_models and https://huggingface.co/litert-community/embeddinggemma-2-text-270m-litert-lm.
