# P3.1–P3.5 feature map

## P3.1 — Smart documents and stable chunks

- Documents are split at practical paragraph/line/sentence boundaries near 900 characters, with a 140-character overlap.
- Every indexed chunk carries a stable chunk ID, document ID, source text, section number, and start/end character offsets in the original text.
- The sanitized document content receives a SHA-256 fingerprint. Re-importing the same content into the same chat is detected before creating another file or index. Legacy P2 documents without fingerprints are compared by reading their local source file.
- Updating a document replaces the existing index atomically under the same document ID; it does not append a second index. Removing a document removes its index file.

## P3.2 — Hybrid offline retrieval

- BM25 and TF-IDF cosine similarity are computed on-device and combined as a weighted lexical rank (65% normalized BM25, 35% normalized TF-IDF).
- The default path requires no model, API key, vector database, or network connection.
- `LocalEmbeddingReranker` is an injectable optional interface. It can reorder a candidate pool with a real local embedding model; errors safely fall back to the hybrid lexical result. No concrete embedding model is bundled/configured in this revision, so embedding reranking is not active by default.

## P3.3 — Existing AI integration and chat isolation

- Before each answer, the current question is searched against only document IDs attached to that chat.
- Up to five ranked excerpts, capped at 2,400 source-text characters, are passed to the existing LiteRT-LM conversation as part of the system instruction.
- The pre-existing chat history remains in the conversation with a reduced character budget when documents are attached.
- Per-document index files live in app-private storage; missing indexes can be rebuilt for older P2 imports and orphan indexes are pruned.

## P3.4 — Visible source citations

- The prompt assigns question-local labels such as `[S1]` and `[S2]`, includes file name, section, and source character range, and instructs the model not to invent citations.
- If retrieval returns no matching excerpts, the system instruction explicitly says that no local passage matched and that the model must not pretend the documents support an answer.
- Citation metadata and a short excerpt are stored with the assistant message. A **Kaynaklar** panel in the chat bubble shows the file name, section, character range, and retrieved excerpt. It remains available when chat history is reopened.

## P3.5 — Test and error checks

`LocalRagIndexTest` and `AssistantPromptBuilderTest` cover stable IDs and offsets, hybrid retrieval, chat document scope, no-hit behavior, optional reranker order and fallback, duplicate detection for both fingerprinted and legacy documents, update/delete/pruning, source labels/ranges, and context budgets.

## Context-budget limitation

The integrated LiteRT-LM API in this project has no verified tokenizer adapter wired into this retrieval path. The limits are therefore expressed in characters, not claimed as exact token counts. The actual answer quality and whether the model follows citation directions depend on the installed `.litertlm` model.
