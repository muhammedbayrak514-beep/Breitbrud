# P1.1 doğrulama planı

Bu liste gerçek Android cihazında ve Android Studio'da çalıştırılmalıdır. Bu teslimatta aşağıdaki derleme ve cihaz testleri tamamlanmadı.

## Derleme / paket
- [ ] JDK 17 ve Android SDK 36 bulunuyor.
- [ ] Gradle `assembleDebug` başarılı.
- [ ] Debug APK gerçek cihazda kuruluyor ve başlıyor.
- [ ] Uygulama ilk açılışta model yokken çökmeden model kataloğunu gösteriyor.

## Model indirme / içe aktarma
- [ ] Üç modelin HTTPS indirme bağlantısı doğru dosyayı döndürüyor.
- [ ] İndirme ilerlemesi ekranda ilerliyor.
- [ ] İndirme iptali socket okumayı sonlandırıyor ve `.part` dosyası siliniyor.
- [ ] Hatalı HTTP cevabı, bağlantı kesilmesi veya depolama dolması kullanıcıya açıklanıyor.
- [ ] İndirilen dosya tamamlanmadan etkin model olarak kaydedilmiyor.
- [ ] `.litertlm` dışındaki dosya reddediliyor.
- [ ] Model uygulama yeniden başlatıldığında hatasız yeniden yükleniyor.

## Yanıt durdurma
- [ ] Aktif üretimde `cancelProcess()` çağrısı native inference'i sonlandırıyor.
- [ ] Durdur sonrası Flow terminal callback'i geliyor ve gecikmesi ölçülüyor.
- [ ] Kısmi metin korunuyor ve yanıt durduruldu olarak işaretleniyor.
- [ ] İptal edilmiş Conversation kapatılıyor; aynı nesne yeniden kullanılmıyor.
- [ ] Yeni Conversation aktif sohbetin son geçerli geçmişiyle oluşturuluyor.
- [ ] Native terminal callback 12 saniye içinde gelmezse uygulama yanlış biçimde başarı bildirmiyor ve yeni üretim kilitli kalıyor.
- [ ] Tekrarlı Durdur tıklamaları çakışma oluşturmuyor.
- [ ] İptal tamamlanırsa yeniden dene akışı çalışıyor.

## Arka uç
- [ ] CPU tercihi sadece CPU ile model yükler.
- [ ] GPU tercihi GPU'yu önce dener; başlatma hatasında CPU yedeğini raporlar.
- [ ] Otomatik tercih katalog önerisini takip eder ve ikinci arka ucu gerektiğinde dener.
- [ ] GPU ilk inference sırasında hata verirse anlaşılır hata gösterilir; bu sürümde otomatik CPU inference retry beklenmez.
- [ ] Yeniden başlatmada arka uç tercihi korunur.

## Sohbet / donanım
- [ ] Türkçe prompt ile akışlı yanıt üretiliyor.
- [ ] Sohbet geçmişi yeniden başlatmada korunur.
- [ ] Yeni sohbet, seçme, silme ve temizleme çalışır.
- [ ] Düşük RAM uyarısı görünür; uyarı gerçek uyumluluk garantisi olarak sunulmaz.
- [ ] Her model için açılış süresi, ilk token, token/s, tepe RAM ve sıcaklık kaydedilir.
- [ ] Uçak modunda önceden indirilmiş model yanıt verebilir.
