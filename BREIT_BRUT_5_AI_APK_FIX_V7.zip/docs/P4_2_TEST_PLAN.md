# P4.2 test plan

## Automated

- Known, unknown, duplicate/case-varied labels; code-fenced example labels should not count.
- Claims whose cited excerpt has high, weak, or no lexical overlap.
- Substantive sentences without citations.
- Number/year values supported or missing from cited excerpts.
- Source metadata pointing to a document not attached to the active chat.
- Serialize/reload audit fields and backwards compatibility with messages that predate claim findings.
- Turkish diacritics, common suffixes, English sentences and markdown lists.

## Manual on tablet

- Import a small text file with a few factual statements; ask questions that are explicitly answered and not answered by that file.
- Check that citations point to the right retrieved excerpt and that missing/unrelated evidence triggers warnings.
- Include a numeric claim in a test document, then ask for an altered number and verify the UI raises a review warning.
- Test long answers, cancellation and retry so the audit is attached only to the completed response.

## Release gate

Do not mark P4.2 complete until Gradle/JUnit tests pass, debug APK is produced, and the actual tablet UI and old-history migration are tested. Lexical overlap results must never be labelled as proof of correctness.
