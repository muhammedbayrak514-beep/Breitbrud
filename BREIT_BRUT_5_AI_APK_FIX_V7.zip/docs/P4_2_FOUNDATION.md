# P4.2 — kaynak ve iddia doğruluğu

## Mevcut katman

P4.2, kaynak etiketinin geçerliliğiyle kanıt niteliğini ayrı kontroller olarak ele alır. Kaynağın gerçek etiketi olması, tek başına cümleyi doğruladığı anlamına gelmez.

- `SourceCitationValidator` cevapta kullanılan `[S1]`, `[S2]` etiketlerini gerçek retrieved source listesiyle karşılaştırır; fenced code block içindeki örnekleri kaynak atfı saymaz.
- Kaynak referanslarının `documentId` değerleri aktif sohbete bağlı belge kümesiyle karşılaştırılır. Başka sohbetten yanlışlıkla gelen bir referans bütünlük hatası üretir.
- `ClaimEvidenceVerifier` yanıtı cümle/iddia adaylarına böler. Her cümlede kaynak atfı aranır ve atfedilen kaynak parçalarıyla kelime örtüşme oranı hesaplanır.
- Sayılar/yıllar/tarih biçimli sayısal ifadeler, aynı atıf yapılan kaynak parçasında bulunmuyorsa ayrıca işaretlenir.
- `CitationAudit` ve her `ClaimEvidenceFinding` sohbet kaydına yazılır; eski kayıtlar alanlar eksikken varsayılan değerlerle okunur.
- UI'daki **İddia denetimi** bölümü cümle örneğini, atıf yapılan etiketleri, kelime örtüşme oranını, eşleşen kaynak etiketlerini ve bulunamayan sayısal ifadeleri gösterir.

## Durumların anlamı

- `LEXICAL_MATCH`: en az %30 iddia token'ı kaynak parçasında da bulunuyor; semantik destek garantisi değildir.
- `WEAK_LEXICAL_MATCH`: %12–%30 arası token örtüşmesi.
- `NO_LEXICAL_MATCH`: %12'den az token örtüşmesi.
- `UNCITED`: anlamlı cümlede kaynak etiketi saptanmadı.
- `UNKNOWN_SOURCE`: atıf etiketi o yanıt için sağlanan kaynaklar arasında değil.
- `UNSUPPORTED_NUMERIC`: cümledeki sayısal ifadelerden en az biri atıf yapılan parçalarda aynı biçimde bulunmadı.

## Bilinen sınırlamalar

Bu katman anlamsal entailment, yalan/doğru kararı veya olgusal kesinlik puanı değildir. Benzer kelimeler, iddianın gerçekten desteklendiğini kanıtlamaz. Morfoloji, eş anlamlılar, olumsuzluk, çelişki, sayı birimi/yuvarlama ve tarihlerin farklı biçimlerde yazılması yanlış uyarılara sebep olabilir. Sonraki adımda iddia-kaynak eşleştirmeyi, yerel doğrulayıcı modeli ve kontrollü düzeltme akışını değerlendirmek gerekir.
