# APK Build Fix V7

## Root cause addressed

The V6 Actions log showed unit-test compilation errors in Kotlin 2.4.0 because `kotlin.io.createTempDir()` is deprecated with error-level severity. The affected files were `AtomicTextFileStoreTest.kt`, `LocalRagIndexTest.kt`, `ModelArtifactIntegrityTest.kt`, and `ModelPerformanceTest.kt`.

## Change

- Replaced all 18 `createTempDir(prefix = ...)` calls with `createTempDirectory(prefix = ...).toFile()`.
- Added `import kotlin.io.path.createTempDirectory` to each affected test file.
- Kept existing `try/finally` cleanup logic (`deleteRecursively()`).
- Updated the GitHub Actions workflow to require the V7 ZIP, identify artifacts as V7, and fail early if deprecated calls remain in test sources.
- Kept diagnostics capture for dependency resolution, AAR metadata, unit-test compilation, and APK assembly.

## Validation status

Source-level checks can confirm there are 18 replacement calls and no `createTempDir(` usage remains in Kotlin unit tests. This report does not claim a successful Android build; the GitHub Actions V7 workflow must finish with exit code 0 and upload the debug APK for that verification.
