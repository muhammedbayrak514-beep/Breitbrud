# BREİT BRUT 5 AI — P3.1–P3.5 entegrasyon raporu

## Sonuç

P3'ün akıllı belge alma, yerel hibrit arama, mevcut yerel AI'ye bağlama, kaynak ayrıntıları ve test kapsamı üzerinde kaynak kod değişiklikleri yapıldı. Yeni paket `BREIT_BRUT_5_AI_P3_1.zip` Android Studio kaynak projesidir; APK değildir.

## P3.1 — Akıllı belge sistemi

- Metinler yaklaşık 900 karakterlik, 140 karakter örtüşmeli ve paragraf/satır/cümle sınırlarını gözeten parçalara ayrılır.
- Her parçada sabit parça kimliği, belge kimliği, sıra/bölüm ve orijinal metindeki başlangıç/bitiş karakter konumu tutulur.
- İçerik SHA-256 parmak iziyle aynı sohbet içinde yinelenen belge içe aktarımları önlenir. Parmak izi olmayan eski P2 kayıtları mevcut yerel dosyanın içeriğiyle karşılaştırılır.
- Belge yenileme aynı belge indeksini değiştirir; ek kayıt biriktirmez. Önceki P3 indeks biçimi de okunabilir.

## P3.2 — Hibrit yerel arama

- BM25 ve TF-IDF kosinüs benzerliği çevrimdışı hesaplanır; sıralama %65 normalize BM25 + %35 normalize TF-IDF olarak birleştirilir.
- İsteğe bağlı `LocalEmbeddingReranker` adaptör noktası adayları yerel embedding modeliyle yeniden sıralamak için hazırdır ve hata durumunda hibrit aramaya geri döner.
- **Gerçek bir embedding modeli ve çıkarım adaptörü bu sürüme dahil değildir.** Bu yüzden anlamsal embedding yeniden sıralaması varsayılan olarak etkin değil; temel BM25 + TF-IDF araması bağımsız çalışır.

## P3.3 — AI entegrasyonu

- Kullanıcının sorusu her gönderildiğinde arama, yalnızca aktif sohbete eklenmiş belge kimlikleri üzerinde yapılır.
- En fazla beş parça ve 2.400 kaynak metni karakteri mevcut LiteRT-LM sohbetine sistem bağlamı olarak eklenir.
- Sohbet geçmişi korunur; belgeli sohbetlerde geçmiş için ayrı karakter bütçesi kullanılır.

## P3.4 — Kaynak gösterimi

- Model isteminde `[S1]`, `[S2]` gibi soru başına kaynak etiketleri, dosya adı, bölüm ve karakter aralığı bulunur.
- Eşleşen belge parçası yoksa AI'nin belge içeriğini uydurmaması söylenir.
- Kaynak bilgisi ve alınan pasaj, AI mesajıyla beraber yerel geçmişe kaydedilir. Mesajdaki **Kaynaklar** düğmesi dosya adını, bölüm numarasını, karakter aralığını ve pasaj önizlemesini gösterir.

## P3.5 — Doğrulama

- `LocalRag.kt` yüklü Kotlin derleyicisiyle derlendi.
- RAG ve prompt test sınıflarındaki 15 test metodu bir assertion uyumlu yerel test kabuğunda çalıştırıldı; tümü geçti. Bu, Gradle/JUnit Android testi değildir.
- `./gradlew testDebugUnitTest` denendi; Gradle başlamadan `services.gradle.org` DNS çözümlemesi başarısız oldu.
- Tam Android/Compose derlemesi, APK üretimi ve fiziksel tablet testi **doğrulanmadı**.

## Bilinen sınırlamalar

- Gerçek embedding modeli henüz bağlanmadı.
- LiteRT-LM akışında doğrulanmış tokenizer entegrasyonu olmadığından bağlam sınırı karakterle ölçülür; token sayısı olarak sunulmaz.
- AI'nin kaynak etiketlerine uyma kalitesi kurulu `.litertlm` modeline bağlıdır.
- Aynı içerik yinelenmesi şu anda aynı sohbet kapsamındaki belge iliştirmelerinde engellenir.
