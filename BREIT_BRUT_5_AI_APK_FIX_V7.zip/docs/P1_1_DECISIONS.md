# P1.1 karar notları

## 1. İptal için neden native API?
LiteRT-LM Android API'sinde `Conversation.cancelProcess()` mevcut. Native başlık, `CancelProcess()` sonrası aynı Conversation nesnesinin tekrar kullanılmasını desteklemediğini ve durumun bozulabileceğini açıkça belirtiyor. Bu nedenle arayüzde yalnızca Flow collector'ını durdurmak yerine native iptal çağrısı yapılır, terminal callback beklenir ve yeni Conversation oluşturulur.

**Kabul edilen sınırlama:** native callback gelmeme/çok geç gelme durumu gerçek cihazda ölçülmeden tam güvenilirlik garantisi verilemez. 12 saniyede watchdog uyarır ama native oturumu zorla kapatmanın güvenli olduğu varsayılmaz. Kullanıcıya başarı uydurulmaz.

## 2. CPU/GPU tercihi
- Varsayılan `Otomatik`: model kartının önerisini dener; engine başlatma hatasında diğer backend'e geçer.
- `GPU`: GPU öncelikli, engine başlatma hatasında CPU yedeği.
- `CPU`: yalnızca CPU.
- Aktif arka uç durum satırında gösterilir; GPU başarısız olup CPU açılırsa yedek kullanıldığı açıklanır.

Engine initialization fallback ile ilk inference sırasındaki hata fallback'i farklıdır. P1.1 yalnızca ilkini yönetir; inference hatasında otomatik yeniden deneme sonraki aşamada ancak güvenli native session reseti test edilirse eklenmelidir.

## 3. Model seçenekleri
Model kartlarına göre dosya boyutları yaklaşık değerlerdir. İlk öneri küçük Qwen3-0.6B INT4 (329 MB) seçeneğidir. INT8 (586 MB) karşılaştırma alternatifi; Qwen3-1.7B INT4 (932 MB) daha büyük seçenektir. İndirme boyutları RAM kullanımını doğrudan tahmin etmez.

## 4. Görsel karşılaştırmalar
- Uygulamadaki yatay çubuklar model indirme boyutlarını kıyaslar.
- Donanım testinde ayrıca açılış süresi, ilk token gecikmesi, token/s ve tepe RAM ölçülmelidir. Bu değerler henüz ölçülmedi ve boyut grafiği performans grafiği olarak kullanılmamalıdır.

## 5. Derleme durumu
Bu çalışma ortamında `./gradlew assembleDebug --stacktrace` denendi; wrapper, `services.gradle.org` alan adını çözemediği için Gradle dağıtımı indirilemedi (`curl: (6) Could not resolve host`). Bu, Kotlin derleme hatası sonucu değildir; aynı zamanda derlemenin başarılı olduğunu da kanıtlamaz. APK ve cihaz testleri beklemede olarak işaretlenir.
