# P2 source validation report

Date: 2026-10-28

## Checks completed in this environment

- Android manifest parsed successfully as XML.
- All Kotlin source files scanned for embedded NUL bytes; none found.
- Prompt builder source includes a hard bound of 1,800 document-context characters overall and 1,400 per document.
- Kotlin source was passed to the locally installed Kotlin compiler for a parser-level scan. Full compilation could not be evaluated because this environment has no Android/Compose/LiteRT-LM/JUnit classpath; diagnostics were dominated by unresolved Android and third-party symbols. No `expecting`, `unexpected tokens`, or other obvious parser-error diagnostics were found.
- Prompt-builder behavior was additionally checked in an isolated JVM harness with a small `AssistantMode` stub; mode instructions, untrusted-document framing, and the 1,800-character source-text cap passed. This does not replace Gradle/JUnit tests.
- ZIP archive will be checked with `unzip -t` after packaging.

## Build/test blocker

Attempted command:

```bash
./gradlew testDebugUnitTest --no-daemon --stacktrace
```

The project's bootstrap script failed before Gradle startup because it could not resolve `services.gradle.org` (`curl: (6) Could not resolve host: services.gradle.org`). As a result:

- No Android APK was produced.
- Gradle/JUnit tests did not run.
- No real Android device or emulator tests were run.

## Required checks before claiming a verified build

1. Open the project in Android Studio with JDK 17 and Android SDK 36 installed.
2. Complete Gradle sync and resolve any build API incompatibilities.
3. Run `./gradlew testDebugUnitTest`.
4. Run `./gradlew assembleDebug` and install the APK on a real device.
5. Test all five assistant modes; import/remove each supported text type; rotate phone/tablet UI; restart app and confirm local document metadata and files persist correctly.
6. Test cancel during generation, restart generation after cancel, model load failures, low-storage rejection, offline use after model download, and GPU-startup failure fallback to CPU.
7. Verify model download URLs and hashes against the source model cards before production use; the app currently checks HTTP status, approximate size, and final file size but does not pin SHA-256 hashes.
