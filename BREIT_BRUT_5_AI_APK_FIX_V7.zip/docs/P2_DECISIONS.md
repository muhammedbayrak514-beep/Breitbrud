# P2 design decisions

## Chosen defaults

- **Per-chat modes:** General, Coding, Study, Writing, Analysis. Keeps mode context distinct between threads.
- **Local text references:** copy a bounded text file into app-private storage; no external URI permission is needed later.
- **Limits:** 1.5 MB per imported file, five documents per chat, at most 1,800 source characters in the prompt (1,400 per source). This protects small local models from enormous prompts. Chat history and user-message limits also tighten when references are attached.
- **Supported file types:** plain text, common source-code formats, CSV/JSON/XML/HTML and simple configuration/log files.
- **Share behavior:** exports message text and document names only, never the contents of imported local files.
- **Safety boundary:** reference text is framed as data in the system prompt. This mitigates prompt injection but is not a formal guarantee; local model behavior still depends on the model.
- **Model operation:** still fully local after model installation; the network permission remains only for a user-initiated model download.

## Deferred decisions for P2.1

1. Local PDF parsing vs. PDF page-to-text conversion. The current stage rejects PDFs instead of implying that it can read them.
2. Room/SQLite database and optional encrypted storage vs. retaining the current private SharedPreferences JSON store.
3. Retrieval-based local document search (chunking + embeddings) vs. continuing with bounded prompt injection for small documents.
4. Android speech input/output vs. completing text workflow robustness first.
