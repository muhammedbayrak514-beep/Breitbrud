# P4.0 regression and acceptance test plan

## Storage

- [x] Atomic text-file writes create parent directories.
- [x] Replacement leaves the new full payload and removes transaction `.tmp`/`.bak` files after success.
- [x] UTF-8 Turkish characters survive round-trip.
- [x] Missing primary file with a rollback backup restores the backup.
- [x] Invalid content can be copied to a separate recovery file without modifying the source.
- [ ] Android SharedPreferences P2/P3 migration test on device/emulator.
- [ ] Deliberately corrupt a real `threads.json` file and verify the UI warning/copy recovery.
- [ ] Large thread archive test with multiple thousands of messages and forced low-storage write failure.
- [ ] Kill app during repeated streamed saves and verify latest durable state.

## Model files

- [x] Static review: only plain `.litertlm` filenames are accepted by `loadModel`/`removeModel`.
- [x] Startup cleanup targets only `.part` and `.importing` scratch files.
- [ ] Simulate interrupted download/import on Android and verify completed models remain untouched.

## Build and runtime

- [x] Standalone Kotlin compile/runtime harness for `AtomicTextFileStore` passed.
- [x] `sh -n ./gradlew` passed.
- [ ] `./gradlew testDebugUnitTest` — blocked by DNS resolution of `services.gradle.org` in the current environment.
- [ ] `./gradlew assembleDebug` — blocked before Gradle startup by the same network error.
- [ ] GitHub Actions run and debug APK artifact download.
- [ ] Physical tablet test with local model load, several chats, imported documents, stop/retry, restart, and offline answer generation.

## Acceptance rule

P4.0 is source-implemented, but it must not be described as fully build-verified until GitHub Actions or a developer environment passes both `testDebugUnitTest` and `assembleDebug`. Physical-device verification remains a separate sign-off.
