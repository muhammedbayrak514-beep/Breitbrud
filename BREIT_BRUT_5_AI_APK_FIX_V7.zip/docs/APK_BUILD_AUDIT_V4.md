# APK build audit V4

## Changes

- Kotlin Android and Compose plugins are pinned to Kotlin 2.4.0 to match `litertlm-android:0.18.1`, whose published artifact carries Kotlin 2.4.0 metadata.
- Kept Android Gradle Plugin 8.13.2, Gradle 8.14.4, JDK 17 and compileSdk 36. Kotlin's current compatibility table allows Kotlin Gradle Plugin 2.4.0 with Gradle 8.14.4 and AGP 8.13.2.
- Kept Compose BOM 2026.04.01, the Compose 1.11 release line targeting API 36 rather than the API-37 Compose 1.12 line.
- CI now saves dependency resolution, AAR metadata, unit-test, and assembleDebug output to `ci-diagnostics/` and uploads it even when APK generation fails.
- The workflow accepts only `BREIT_BRUT_5_AI_APK_FIX_V4.zip`, preventing the silent selection of an older source ZIP.

## Validation limits

The source archive and YAML are structurally checked. This environment cannot download Gradle/Maven dependencies, so a full Android compile was not executable here. The workflow is designed to surface the exact Gradle failure as a downloadable diagnostics artifact rather than treating the final “APK was not produced” line as the root cause.
