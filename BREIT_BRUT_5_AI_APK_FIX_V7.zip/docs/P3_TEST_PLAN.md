# P3.1–P3.5 test plan

## Automated tests

- Stable chunk IDs and accurate original-document offsets.
- BM25 + TF-IDF retrieval, ranking, no-hit behavior, and chat-scope isolation.
- Optional reranker can reorder the lexical candidate pool; reranker exceptions fall back to lexical ranking.
- Duplicate detection for new records with a saved fingerprint and legacy P2 records without one.
- Index persistence/reload, upsert replacing old content, deletion, and orphan pruning.
- Source citation labels and character offsets appear in the system instruction; no-hit instruction avoids false claims.
- Character budgets are enforced both in retrieval output and source excerpt prompt construction.

Run the full Android unit-test task once Gradle can resolve its distribution: `./gradlew testDebugUnitTest`.

## Device acceptance tests (not performed in this environment)

1. Import a `.txt` or `.md`, verify indexing status, then import the same content again into the same chat and verify it is rejected as a duplicate without creating another attachment.
2. Ask a question about content located in the middle/end of a document. Check both lexical retrieval and whether the installed model follows `[S1]` / `[S2]` instructions.
3. Open the answer's **Kaynaklar** panel and verify file name, section, character range, and excerpt.
4. Add different documents to separate chats and verify a question in one chat cannot retrieve the other chat's documents.
5. Replace an attached document, then verify the previous content is no longer retrievable and the new content is retrievable.
6. Remove a document, restart the app, and verify removed content stays absent while remaining documents are still indexed.
7. After the model and documents have been installed, turn off network connectivity and repeat retrieval and answer generation.

## Validation report policy

Compilation, local logic test execution, Gradle/JUnit execution, APK generation, and physical-device acceptance are reported separately. A passing pure-Kotlin harness is not presented as a successful Android build.
