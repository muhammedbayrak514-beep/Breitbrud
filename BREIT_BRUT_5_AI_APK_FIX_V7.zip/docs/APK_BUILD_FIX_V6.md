# APK Build Fix V6

## Confirmed root cause

Kotlin compilation reported JVM platform declaration clashes in `ChatViewModel.kt`:

- `backendPreference` is a mutable Compose state property. Its generated setter has the JVM signature `setBackendPreference(BackendPreference)`.
- `maxOutputTokens` is a mutable Compose state property. Its generated setter has the JVM signature `setMaxOutputTokens(int)`.
- Explicit methods with those same JVM names/signatures caused the compiler errors.

## Fix applied

- Renamed the explicit method `setBackendPreference(...)` to `updateBackendPreference(...)`.
- Renamed the explicit method `setMaxOutputTokens(...)` to `updateMaxOutputTokens(...)`.
- Updated the two call sites in `MainActivity.kt` to use the renamed methods.
- Updated `settings.gradle.kts` project name to `BREIT_BRUT_5_AI_APK_FIX_V6`.
- Updated the GitHub Actions workflow to require the exact V6 ZIP and store V6-specific diagnostics/artifacts.

## Validation performed

- Static search confirms the old explicit method names are absent in the source and call sites.
- Static search confirms both renamed methods are declared and call sites point to them.
- ZIP integrity and YAML syntax are checked after packaging.

A full Android Gradle build was not run in this environment; the generated APK must be confirmed by the GitHub Actions run.
