# APK build audit V3

## Changes
- Pinned Compose BOM to `2026.04.01`, the Compose 1.11 release aligned with API 36. Compose 1.12 moved to API 37 and requires AGP 9.1.1.
- Aligned Kotlin Android and Compose compiler plugins to `2.3.21`, because LiteRT-LM Android 0.18.1 carries Kotlin 2.4 metadata and requires a Kotlin 2.3-or-newer compiler. AGP 8.13.2 is kept with API 36 and Gradle 8.14.4.
- Migrated the module to typed `kotlin.compilerOptions` with JVM target 17.
- Aligned Gradle wrapper metadata to 8.14.4.
- CI extracts only the exact V3 source ZIP, prints resolved dependency versions, runs `checkDebugAarMetadata` with detailed logs, then unit tests and `assembleDebug`; it uploads APK only if present and uploads test reports even on failure.

## Important verification status
The ZIP archive structure and configuration consistency were checked locally. This environment did not complete a network-backed Android Gradle build, so this is a targeted compatibility correction, not a claim that an APK has already been built successfully. If CI still fails at `checkDebugAarMetadata`, the task's expanded log should identify the exact AAR and required `minCompileSdk`/AGP value.
