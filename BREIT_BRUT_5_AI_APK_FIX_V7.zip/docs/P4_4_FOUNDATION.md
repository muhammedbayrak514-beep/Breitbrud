# P4.4 — Multi-document local extraction and indexing

## Implemented in source

### Multi-select and persistence
- The Android Storage Access Framework multi-select picker accepts up to 10 selected URIs in a batch. The existing per-chat limit of 5 attached documents remains enforced.
- Per-file exceptions are recorded individually; successful files in the same batch are not discarded when another file fails.
- Duplicate extracted content is fingerprinted inside the active chat. Extracted text is saved in app-private storage and indexed through the existing local RAG path.
- `LocalDocument` persists MIME type, page count, Office section count, extraction method and warnings with backward-compatible defaults for previous saved chat data.

### Format support
- **Plain text/code:** TXT, MD, CSV, JSON, XML, HTML, CSS, JS, Kotlin, Java, Python, SQL, logs, shell and configuration text. UTF-8 BOM is removed.
- **PDF:** PdfBox-Android extracts selectable text page-by-page and prepends `[PDF sayfa N]` markers. Password-encrypted PDFs are rejected. The PDF is copied to an app-private temporary file and removed in `finally`.
- **Scanned/blank-text PDF pages:** Android `PdfRenderer` renders pages with no selectable text; bundled ML Kit Latin-script OCR is attempted locally for up to 30 such pages. Warnings identify pages where OCR produced no text or the page limit was reached.
- **Images:** PNG, JPG/JPEG, WebP and BMP are imported locally and processed through bundled Latin-script ML Kit OCR. File bytes and decoded pixel dimensions are limited; bitmaps are sampled down and recycled.
- **DOCX:** reads `word/document.xml`, including text runs, paragraph breaks and tabs.
- **PPTX:** reads slide XML and uses `presentation.xml` plus its relationship table to preserve the actual presentation slide order. If a minimal archive lacks those files, it falls back to numeric slide filenames.
- **XLSX:** reads workbook relationships, sheet names, shared strings and worksheet cells. Output includes worksheet labels, row numbers and cell coordinates.

### Archive and content limits
- Selection batch: 10 files.
- Documents per chat: 5.
- Plain text: 1.5 MB input cap.
- PDF: 25 MiB input, 200 pages, 1.5 million extracted characters.
- Office packages: 20 MiB compressed input; 3,000 archive entries; 60 MiB expanded total; 10 MiB per selected XML entry; 30 MiB combined selected XML; 1.5 million extracted characters; 200 slides/sheets.
- Images: 25 MiB file input, 4 million working pixels after sampling, 1.5 million extracted characters.
- PDF OCR: at most 30 blank-text pages per PDF, render edge capped to 1,800 pixels and 45-second recognizer wait.
- XML parsing disables DTD/external entities where supported and uses an empty entity resolver. ZIP entries are never extracted as paths; suspicious traversal paths are rejected.

## UI metadata
- A document chip shows PDF page count, PPTX slide count, XLSX worksheet count or image OCR label.
- An info action opens import warnings when extraction was partial or OCR had limitations.

## Known limits and follow-up
- The bundled ML Kit model is Latin-script OCR. Handwriting and low-resolution scans may yield incomplete text. This OCR path only runs for PDF pages where the text layer was blank; it does not merge OCR text from a scan background when a page already has some selectable text.
- DOCX extraction is text-oriented; headers/footers, comments, tracked changes, images, SmartArt and full layout aren't faithfully represented.
- PPTX extracts text from slides only; it doesn't parse speaker notes, image text, chart values or embedded media.
- XLSX reads stored cell values and shared strings but doesn't recalculate formula results or preserve number formatting, charts, merged-cell layout or pivot tables.
- Per-file processing is sequential on the I/O dispatcher; no pause/resume background document queue exists yet.
- The parser and pipeline source passed a local Kotlin syntax check using stand-in Android/PDF/OCR API stubs. Actual Android library signatures, runtime OCR and physical-device behavior still need Gradle/device verification.
