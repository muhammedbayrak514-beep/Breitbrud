# P4.3 — Device-aware model selection, integrity and performance diagnostics

## Implemented in source

### 1. Model and device suitability
- `DeviceModelAdvisor` ranks the shipped model catalogue by suitability and estimated storage requirements.
- `DeviceReadinessScorer` produces a transparent 0–100 readiness score and a `LOW` / `MODERATE` / `HIGH` risk summary using total RAM, available system RAM and free internal storage.
- Each model has a conservative suggested output-token cap of 128–1024 based on the current device snapshot and the catalogue's suggested memory floor. It is advice, not a prediction of runtime context capacity. It only changes app settings after the user presses the action.
- `ModelStoragePolicy` is shared by the model advisor and downloader: `max(1.3 GB, model-size + 350 MiB)`.

### 2. Safer user-imported model files
- `ModelImportPolicy` checks provider-reported size, 4 GiB maximum, preflight free space, copied bytes during streaming and whether final copied size matches the provider's reported size.
- Import uses an app-private temporary `.importing` file; failed or cancelled imports remove partial/target files and integrity sidecars.
- `ModelArtifactIntegrity` stores SHA-256, size and mtime metadata in app-private sidecars. It detects subsequent model changes and verifies when needed.
- The digest is calculated from the first received artifact; it is not signed metadata and cannot prove provenance. A future release can compare against a trusted expected digest delivered independently of the model file.

### 3. Local-only performance diagnostics
`InferenceSample` records bounded metadata for model loads and inference:
- successful initial model load within this process and later successful loads;
- inference duration and first non-empty chunk latency;
- output character count and characters/second;
- median and P90 duration, success/failure/cancel counts;
- available system RAM before and after an event;
- bounded error categories with no raw stack trace or exception message.

`LocalPerformanceTelemetry` stores at most 120 events in an atomic app-private file. Five-column legacy rows remain readable. The user can clear history in the model manager.

## Known limits
- The model-fit score is advisory; it cannot guarantee LiteRT-LM backend initialization, free memory after context allocation, sustained thermal performance or speed.
- RAM samples are system `availMem`, not process RSS or peak memory. There is no token/sec, battery, thermal-state or ANR monitor yet.
- First-vs-subsequent load classification refers to the first successful model initialization recorded in the app process, not a formal cold-boot/warm-cache benchmark.
- Model integrity metadata does not authenticate a download unless compared against a trusted external hash/signature.
- Real Android/Gradle and device tests are still required. The local Gradle attempt currently fails before Gradle starts because `services.gradle.org` cannot be resolved in the build environment.
