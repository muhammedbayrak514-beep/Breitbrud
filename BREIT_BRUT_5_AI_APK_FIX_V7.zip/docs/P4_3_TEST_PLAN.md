# P4.3 validation plan

## Pure logic
- Model ranking with abundant/low RAM and abundant/low storage.
- Suggested output-token cap decreases under RAM pressure and remains advisory.
- Storage policy matches the downloader threshold.
- Imported model preflight, declared-size mismatch, 4 GiB cap, copy progress, incomplete copy and reserve checks.
- Artifact SHA-256 remains stable for unchanged bytes, detects changed bytes, and handles legacy sidecars.
- Telemetry migration from legacy rows, bounded persistence, clearing, first/subsequent load summary, median/P90, failure/cancel categories, first-chunk latency and available-system-RAM change.

## Required Android integration
- Run `./gradlew testDebugUnitTest --no-daemon` and `./gradlew assembleDebug --no-daemon` in GitHub Actions.
- On device, test model import with known size, unknown size, truncated copy, low storage, cancellation, re-import and post-import load failure.
- Compare CPU/GPU/AUTO performance for the same local prompt and model on the tablet; record thermal state and peak process memory externally if needed.

## Current validation state
- P4.3 and core logic tests were compiled and run in a local lightweight Kotlin test harness with stand-in Android primitives. This does not substitute for the official Gradle/JUnit task.
- The actual Gradle task is blocked before startup by DNS resolution failure for `services.gradle.org` in this environment.
