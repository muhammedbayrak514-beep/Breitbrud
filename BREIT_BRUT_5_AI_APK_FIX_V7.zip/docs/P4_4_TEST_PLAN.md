# P4.4 validation plan

## Local/unit coverage
- Validate supported extensions and file byte/page/pixel/OCR limits.
- Build minimal OOXML ZIP archives for DOCX, PPTX and XLSX parsing.
- Verify Unicode, paragraphs/tabs, true presentation slide order, workbook sheet names, shared and inline strings, row/cell positions, missing main entries and ZIP path traversal rejection.
- Validate per-file failures don't discard successful siblings, duplicate text doesn't create a second attached document, index rollback occurs when document persistence fails, and chat-scoped indexes remain isolated.

## Android integration/device cases required
- Use Android Storage Access Framework to select 1, 5, 6, and 10 files; confirm the 5-per-chat ceiling remains active.
- Import normal text PDF, scanned PDF, mixed PDF, encrypted PDF, corrupted PDF, long PDF and >30 blank-text pages.
- Import PNG/JPG/WebP/BMP with readable Latin-script print, rotated/low-contrast text, no text, corrupt bytes and oversize dimensions.
- Import DOCX with normal paragraphs, tables and large XML; PPTX with reordered slides and empty slides; XLSX with multiple sheets, shared strings, inline strings, formulas with cached values and invalid relationships.
- Verify warnings, section markers and correct RAG sources after restart. Confirm temporary files are removed on success, failure and cancellation.

## Current validation state
- `OoxmlTextExtractor.kt` and the document pipeline passed a local Kotlin syntax check using stand-in Android/PDF/OCR API stubs. OOXML logic ran against generated ZIP samples, including an explicit presentation-order case and traversal rejection.
- The app-level Gradle/JUnit build and real ML Kit/PDFBox runtime were not verified because the Gradle distribution could not be resolved in this environment.
