# P1.1 mimarisi — BREİT BRUT 5 AI

```mermaid
flowchart TD
    UI[Jetpack Compose arayüzü] --> VM[ChatViewModel]
    VM --> Store[LocalRepository]
    Store --> Prefs[SharedPreferences / JSON]
    VM --> Files[filesDir/models/*.litertlm]
    VM --> Catalog[Model kataloğu]
    Catalog --> Download[İsteğe bağlı HTTPS indirme]
    Download --> Part[Geçici .part dosyası]
    Part -->|Boyut kontrolü| Files
    VM --> Backend{Arka uç tercihi}
    Backend --> GPU[GPU]
    Backend --> CPU[CPU]
    GPU --> Engine[LiteRT-LM Engine]
    CPU --> Engine
    Engine --> Conversation[Conversation / yanıt Flow'u]
    Conversation --> UI
    UI -->|Durdur| Cancel[cancelProcess()]
    Cancel --> Wait[Native terminal callback bekle]
    Wait --> Rebuild[Conversation yeniden oluştur]
    Rebuild --> Conversation
```

## Güven sınırları
- Sohbet için bulut API çağrısı yapılmaz.
- Model indirme ancak kullanıcı açıkça başlatırsa yapılır.
- Modeller uygulamanın özel alanında tutulur; sohbet geçmişi cihaz içi JSON deposundadır.
- Android yedeklemesi kapalıdır.

## İptal ve hata işleme
1. Durdur düğmesi `Conversation.cancelProcess()` çağırır; sadece UI collector'ı iptal ederek native modelin çalıştığı iddia edilmez.
2. Terminal callback beklenir. Bu sırada yeni mesaj/model değiştirme işlemi engellenir.
3. LiteRT-LM açıklaması iptal edilmiş Conversation nesnesinin yeniden kullanılmamasını söylüyor. Akış sonlandıktan sonra aktif sohbet geçmişiyle yeni bir Conversation oluşturulur.
4. 12 saniye içinde callback gelmezse watchdog bir zaman aşımı bildirir. Bu bir başarı sinyali değildir; belirsiz native oturumla çakışmayı engellemek için uygulama yeni iş başlatmaz.
5. Conversation yeniden oluşturulamazsa model hazır durumu kaldırılır ve kullanıcıdan modeli yeniden yüklemesi istenir.

## Arka uç kararı
- **CPU:** yalnızca `Backend.CPU()`.
- **GPU:** önce `Backend.GPU()`, başlatma hatasında CPU yedeği.
- **Otomatik:** model kartının önerisine göre ilk arka ucu belirler, başlatma başarısızsa diğerini dener.
- İlk inference sırasında ortaya çıkan GPU hataları bu sürümde otomatik retry ile CPU'ya taşınmaz; ayrı bir güvenli retry akışı gerekir.

## Kaynaklar
- `MainActivity.kt`: sohbet, geçmiş, model kataloğu, boyut grafiği ve ayarlar.
- `ChatViewModel.kt`: engine/conversation sahipliği, model indirme, iptal akışı ve thread yönetimi.
- `AppModels.kt`: model kataloğu, cihaz profili ve yerel veri deposu.
