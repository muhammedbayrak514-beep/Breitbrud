# BREİT BRUT 5 AI — P4.1 implementation record

Date: 2026-10-29

## Delivered in source

- Added `LocalVectorEmbedder` so the RAG store depends on a small interface rather than the native model adapter.
- Added `LiteRtLocalTextEmbedder`, using LiteRT-LM Kotlin `EmbeddingEngine` with the EmbeddingGemma 2 Text 270M `.litertlm` artifact. Native calls are serialized through one dedicated worker thread.
- Uses the asymmetric official task prefixes for indexed text (`task: search result | text:`) and questions (`task: search query | text:`).
- Added a separate app-private `files/embedding_models` model location so this artifact never gets mixed with the chat/generation model.
- The in-app model manager provides download progress, cancel support, size/free-storage checks, a RAM warning/block threshold, load/disable/remove controls, and error status. Model download is not bundled in the APK.
- The downloaded file is checked against the published SHA-256 before installation. A private marker avoids hashing the whole file on every later startup; a missing or stale marker triggers verification on first load.
- Each document index can have a binary `.vec` sidecar with model ID, stable chunk IDs, vector dimension, and finite float values. Writes use temp-file + rename, corrupt vectors are rejected, and old model IDs force re-indexing.
- Reuses current model-version vectors at startup instead of embedding all chunks again. Upsert/delete removes or replaces the related vectors. BM25 + TF-IDF continues to operate if the embedding engine, cache, or vector file fails.
- Final combined candidate score is 40% lexical rank and 60% normalized cosine similarity. Embeddings only rerank a bounded set of lexical candidates (up to 4 × requested top-K); this is not an all-document semantic recall path. Default mode remains BM25 + TF-IDF.
- Added a model-state-aware prompt description so responses do not claim EmbeddingGemma is active if it is not loaded.

## P4.1 files

- `LocalVectorEmbedder.kt`
- `LocalEmbeddingEngine.kt`
- `LocalRag.kt`
- `ChatViewModel.kt`
- `MainActivity.kt`
- `LocalRepository.kt`
- `AssistantPromptBuilder.kt`
- `LocalRagIndexTest.kt`

## Automated checks performed here

- 17 P4.1/P4.2-focused pure Kotlin regression test methods passed in a standalone `kotlinc` harness: lexical ranking, local chat scope, vector sidecar persistence/reuse, embedding-version invalidation, corrupt-vector fallback, index update/delete, source citation label audit, cosine math, and character budget.
- The combined standalone harness ran 28 tests successfully when including the existing prompt-builder and atomic-file-store regression tests. The harness uses compatible local JUnit-style assertions and is not a Gradle/JUnit execution.
- Embedding adapter source syntax compiled with API-shaped LiteRT-LM stub classes. This checks Kotlin syntax only; it does not verify the real Maven AAR/API binding.
- `./gradlew testDebugUnitTest assembleDebug --no-daemon` was attempted. The wrapper could not download Gradle because the environment cannot resolve `services.gradle.org` (`curl: (6) Could not resolve host`).

## Not yet verified / follow-up

- Real Android Gradle/JUnit compilation and tests have not run in this environment.
- The real LiteRT-LM 0.18.1 Maven API binding and a real model load are not verified until CI can resolve dependencies and execute `assembleDebug`, then a device test is performed.
- The 165 MB embedding model is not included in the ZIP; it downloads after the user chooses the optional model control.
- The model page reports about 165 MB and recommends 2 GB+ RAM. This implementation blocks activation below a detected 1.5 GB total RAM threshold and warns under the 2 GB recommendation; actual performance depends on tablet, OS and the generation model loaded alongside it.
- Retrieval remains lexical-candidate-gated: a passage with zero lexical match cannot enter the embedding reranker candidate pool. A future retrieval-accuracy phase can evaluate wider/parallel semantic candidate retrieval.
- Context budgets are character-based, not tokenizer-exact.
