# P2 — Local assistant capabilities

## Purpose

P2 moves BREİT BRUT 5 AI beyond a plain local chat screen. It adds per-conversation assistant behavior, bounded local reference documents, and easy sharing of results without sending chat or source text to a cloud model API.

## Delivered in this source stage

- Five per-thread modes: General, Coding, Study, Writing, Analysis.
- Each thread stores its own mode and local text-reference metadata; old P1 threads migrate by defaulting to General and no documents.
- Text-based local reference import from Android's document picker.
- Supported extension whitelist: `.txt`, `.md`, `.markdown`, `.csv`, `.json`, `.xml`, `.html`, `.htm`, `.css`, `.js`, `.kt`, `.kts`, `.java`, `.py`, `.sql`, `.log`, `.yaml`, `.yml`, `.toml`, `.sh`, `.properties`.
- Maximum imported file size: 1.5 MB; maximum five documents per conversation.
- Source text is copied to the app's private files directory. The app does not upload local documents.
- Prompt context is bounded to 1,800 characters across the attached documents and no more than 1,400 characters per document. Message input is limited to 1,800 characters with local documents or 3,000 without; recent history is shortened when document text is present to better fit 4k-token models.
- Source files are described to the model as reference data, not as system instructions, to reduce instruction injection from untrusted documents.
- Missing/corrupt document metadata is reconciled at startup, and orphaned app-owned document files are cleaned up.
- Copy individual assistant responses and export/share the current conversation as text.
- Unit tests cover mode instructions, untrusted-document wording, and prompt context limits.

## Deliberate limitations

- This stage does not parse PDFs, images, audio, or office documents. It imports bounded text/code only; images and scanned PDFs would require OCR/vision support.
- The document content is included in the system instruction rather than indexed into a retrieval database. It is therefore a small-context reference feature, not full RAG.
- Mode prompts influence style and workflow but do not change model weights or guarantee higher factual accuracy. A larger or better-trained local model may still be needed for harder tasks.
- The current persistence layer continues to use app-private SharedPreferences JSON. Room/SQLite migration and encrypted local storage remain future decisions.
- Android build and real-device tests are still mandatory before calling this release verified.
