# BREİT BRUT 5 AI — P4.0 implementation

## Goal

Stabilize P3.1–P3.5 before adding actual semantic embeddings. P4.0 is a reliability/data/build phase, not a model capability marketing release.

## 1. Persistence boundary

- Extracted `LocalRepository` from `AppModels.kt` into `LocalRepository.kt` so domain/UI model declarations no longer own the persistence implementation.
- Thread/message/document JSON is now stored at `files/chat_store/threads.json` using `AtomicTextFileStore`.
- Existing P2/P3 history in the `threads_json` SharedPreferences key is parsed and migrated. The preference is removed only after the file write succeeds.
- Active-chat selection and simple settings (active model, backend preference, output limit) remain in SharedPreferences; this limits migration scope and preserves compatibility.

## 2. Crash-safe writer

`AtomicTextFileStore` writes UTF-8 to a same-directory temporary file, flushes it with `FileDescriptor.sync()`, moves the previous file to a rollback backup, and renames the new file into place. If activation fails, it attempts to restore the previous file. A stale backup is restored on startup if the primary file is missing.

When JSON parsing fails, the current file is copied to a bounded `threads.corrupt-<timestamp>.json` recovery set before a new empty chat can overwrite the active store. The user receives a storage warning instead of a silent empty-history fallback.

## 3. Write scheduling and lifecycle

- Frequent updates are coalesced to the newest immutable thread-list snapshot.
- JSON serialization and normal file writes execute on a single named background executor.
- Generation counters prevent a stale queued snapshot from overwriting a newer snapshot.
- `onCleared()` cancels pending streaming/debounce jobs first, synchronously flushes the latest thread state, then shuts down the repository writer.
- Persistence failures are logged without message text and surfaced through the ViewModel's existing error panel.

## 4. Model-file safeguards

- `loadModel` and `removeModel` reject non-local filenames and non-`.litertlm` paths.
- Startup cleanup removes abandoned `.part` and `.importing` files left by a process kill; only scratch suffixes are targeted, not completed model files.
- Existing model size and runtime load checks remain in place. No cryptographic authenticity check is claimed because the catalog does not yet define trusted expected digests.

## 5. Build foundation

Added `.github/workflows/android-ci.yml` to run the wrapper syntax check, `testDebugUnitTest`, `assembleDebug`, and upload the debug APK and test reports. The workflow is configured for push to `main`, `master`, `develop`, pull requests, and manual dispatch.

## 6. Deliberate non-goals

- Room/SQLite migration is deferred to avoid mixing a database rewrite with the reliability patch; the new file repository remains a clean migration boundary.
- `ChatViewModel` is still large. Further model, download, conversation, document, and RAG services should be extracted incrementally with successful Android CI coverage.
- Actual EmbeddingGemma or another embedding model is not activated in P4.0. That belongs to P4.1.
- No APK or tablet run is claimed.
