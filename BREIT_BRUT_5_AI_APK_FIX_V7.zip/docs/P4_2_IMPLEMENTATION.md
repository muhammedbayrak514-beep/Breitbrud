# P4.2 implementation record

Date: 2026-10-29

## Integrated into source

- Expanded `SourceCitationValidator` to validate cited labels, unknown labels, uncited retrieved sources, missing retrieval and source document IDs outside the active chat scope.
- Fenced code blocks are removed before extracting citation labels to prevent example code from being counted as a citation.
- Added `ClaimEvidenceVerifier`, which separates substantive answer sentences, checks whether they contain source labels, and compares meaningful tokens with the excerpts referenced by those labels.
- Added explicit statuses: `LEXICAL_MATCH`, `WEAK_LEXICAL_MATCH`, `NO_LEXICAL_MATCH`, `UNCITED`, `UNKNOWN_SOURCE`, `UNSUPPORTED_NUMERIC`.
- Added conservative numeric-expression matching. Numeric/year expressions found in a claim but not found exactly in its cited excerpts are surfaced for review.
- `CitationAudit` and `ClaimEvidenceFinding` are serialized into the existing local chat JSON. Parsing is backward-compatible when older messages lack the new fields.
- Message UI exposes an expandable claim-audit panel with excerpts, labels, token-overlap percentage and unsupported numeric values.
- `AssistantPromptBuilder` now asks the model to cite each important factual sentence, avoid blanket citations, avoid inventing labels/dates/numbers and explicitly say when the attached sources do not verify a claim.
- Corrected the conversation prompt wiring so the prompt describes embedding reranking only when the caller says it is actually active.

## Limits that remain explicit

- Lexical overlap is not semantic entailment or factual verification.
- Numeric checking requires the same numeric text (with comma/dot canonicalization) in a cited excerpt. It may flag a number expressed with a different unit or date format.
- There is not yet an automatic second-pass rewriting/repair pipeline; current behavior warns without replacing the model answer.
- No PDF page refs or OCR span coordinates because these source types are not yet imported.

## Tests added

- Added claim-evidence tests for matched, mismatched, uncited and code-block-only citations; current-chat document scope; unsupported numeric claims; numeric values present in evidence.
- Source `@Test` methods: 43 in total at this source revision, including new P4.2/P4.3 tests. Full Gradle/JUnit suite could not run because `services.gradle.org` DNS could not be resolved in this environment.
- A focused standalone `kotlinc` harness passed 9 targeted code-path checks across the evidence verifier, citation validator, model advisor and local telemetry. This does not replace Android/Compose compilation or full unit tests.
