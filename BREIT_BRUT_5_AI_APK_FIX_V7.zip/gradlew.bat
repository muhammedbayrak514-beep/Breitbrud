@echo off
setlocal EnableExtensions EnableDelayedExpansion
set GRADLE_VERSION=8.13
if not defined GRADLE_USER_HOME set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set GRADLE_HOME=%GRADLE_USER_HOME%\wrapper\dists\breit-brut-bootstrap\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  set ZIP=%GRADLE_USER_HOME%\wrapper\dists\breit-brut-bootstrap\gradle-%GRADLE_VERSION%-bin.zip
  if not exist "!ZIP!" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; New-Item -Force -ItemType Directory -Path (Split-Path '!ZIP!') | Out-Null; Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '!ZIP!'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $d='%GRADLE_USER_HOME%\wrapper\dists\breit-brut-bootstrap'; $tmp=Join-Path $d 'unpack'; if(Test-Path $tmp){Remove-Item -Recurse -Force $tmp}; Expand-Archive -Force '!ZIP!' $tmp; if(Test-Path '%GRADLE_HOME%'){Remove-Item -Recurse -Force '%GRADLE_HOME%'}; Move-Item (Join-Path $tmp 'gradle-%GRADLE_VERSION%') '%GRADLE_HOME%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" -p "%~dp0" %*
exit /b %ERRORLEVEL%
